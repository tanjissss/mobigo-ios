#!/usr/bin/env python3
"""Create BusMind's 27-second, three-wave wake-up sound."""

import array
import math
import wave

RATE = 22_050
DURATION = 27
PEAK_BY_CYCLE = (0.22, 0.50, 0.88)
OUTPUT = "/tmp/BusMindWake.wav"


def envelope(local_time: float, peak: float) -> float:
    # Each 9-second wave rises gently, holds briefly, then fades back down.
    if local_time < 0.6:
        return 0.006 + (peak * 0.30 - 0.006) * local_time / 0.6
    if local_time < 3.4:
        return peak * (0.30 + 0.70 * (local_time - 0.6) / 2.8)
    if local_time < 4.8:
        return peak
    if local_time < 7.2:
        return peak * (1.0 - 0.94 * (local_time - 4.8) / 2.4)
    if local_time < 8.2:
        return peak * 0.06
    return 0.0


samples = array.array("h")
for frame in range(RATE * DURATION):
    time = frame / RATE
    cycle = min(2, int(time // 9))
    local_time = time - cycle * 9
    gain = envelope(local_time, PEAK_BY_CYCLE[cycle])
    # A soft two-note chime with a light pulse so the sound remains easy to
    # distinguish at the start of the cycle without an abrupt volume jump.
    pulse = 0.78 + 0.22 * math.sin(2 * math.pi * 1.6 * local_time)
    tone = (
        math.sin(2 * math.pi * 523.25 * time)
        + 0.34 * math.sin(2 * math.pi * 659.25 * time)
        + 0.12 * math.sin(2 * math.pi * 1046.5 * time)
    ) / 1.46
    sample = max(-1.0, min(1.0, gain * pulse * tone))
    samples.append(round(sample * 32767))

with wave.open(OUTPUT, "wb") as output:
    output.setnchannels(1)
    output.setsampwidth(2)
    output.setframerate(RATE)
    output.writeframes(samples.tobytes())
