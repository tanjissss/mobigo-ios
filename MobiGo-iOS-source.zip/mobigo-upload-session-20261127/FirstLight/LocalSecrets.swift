enum LocalSecrets {
    // Personal development build. Replace locally if this key is rotated.
    static let deLijnAPIKey = "aef06fa7a0ea4a1ba5aa4761b3dc1225"
    static let bmcAPIKey = "8cb17a78e0ea40789b846fcaaf2a4fb2"
}
