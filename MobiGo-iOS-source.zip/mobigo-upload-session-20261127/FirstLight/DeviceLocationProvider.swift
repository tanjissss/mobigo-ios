import CoreLocation
import Combine

@MainActor
final class DeviceLocationProvider: NSObject, ObservableObject, @preconcurrency CLLocationManagerDelegate {
    static let shared = DeviceLocationProvider()

    @Published private(set) var latestLocation: CLLocation?
    @Published private(set) var locationUpdateID = 0
    @Published private(set) var isTripTracking = false
    @Published private(set) var isBackgroundTracking = false

    private let manager = CLLocationManager()
    private var continuation: CheckedContinuation<CLLocation, Error>?
    private var trackingContinuation: CheckedContinuation<Void, Error>?

    private override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
    }

    func currentLocation() async throws -> CLLocation {
        try await withCheckedThrowingContinuation { continuation in
            self.continuation = continuation
            switch manager.authorizationStatus {
            case .authorizedAlways, .authorizedWhenInUse:
                manager.requestLocation()
            case .notDetermined:
                manager.requestWhenInUseAuthorization()
            case .denied, .restricted:
                finish(throwing: LocationError.permissionDenied)
            @unknown default:
                finish(throwing: LocationError.unavailable)
            }
        }
    }

    func startTripTracking() async throws {
        if isTripTracking { return }
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            beginTripTracking()
        case .notDetermined:
            try await withCheckedThrowingContinuation { continuation in
                trackingContinuation = continuation
                manager.requestWhenInUseAuthorization()
            }
        case .denied, .restricted:
            throw LocationError.backgroundPermissionDenied
        @unknown default:
            throw LocationError.unavailable
        }
    }

    func stopTripTracking() {
        manager.stopUpdatingLocation()
        manager.allowsBackgroundLocationUpdates = false
        manager.showsBackgroundLocationIndicator = false
        isTripTracking = false
        isBackgroundTracking = false
        if let pending = trackingContinuation {
            trackingContinuation = nil
            pending.resume(throwing: LocationError.unavailable)
        }
    }

    private func beginTripTracking() {
        manager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        manager.distanceFilter = 25
        manager.activityType = .otherNavigation
        manager.pausesLocationUpdatesAutomatically = false
        manager.allowsBackgroundLocationUpdates = true
        manager.showsBackgroundLocationIndicator = true
        manager.startUpdatingLocation()
        isTripTracking = true
        isBackgroundTracking = true
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if let pending = trackingContinuation {
            switch manager.authorizationStatus {
            case .authorizedAlways, .authorizedWhenInUse:
                trackingContinuation = nil
                beginTripTracking()
                pending.resume()
            case .denied, .restricted:
                trackingContinuation = nil
                pending.resume(throwing: LocationError.backgroundPermissionDenied)
            case .notDetermined:
                break
            @unknown default:
                trackingContinuation = nil
                pending.resume(throwing: LocationError.unavailable)
            }
            return
        }
        guard continuation != nil else { return }
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            manager.requestLocation()
        case .denied, .restricted:
            finish(throwing: LocationError.permissionDenied)
        case .notDetermined:
            break
        @unknown default:
            finish(throwing: LocationError.unavailable)
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else {
            if continuation != nil { finish(throwing: LocationError.unavailable) }
            return
        }
        latestLocation = location
        locationUpdateID += 1
        if continuation != nil { finish(returning: location) }
    }

    func locationManager(_ manager: CLLocationManager, didVisit visit: CLVisit) {
        // Visit events are intentionally unused; live trip tracking uses precise
        // location updates while the user has explicitly enabled it.
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        if continuation != nil { finish(throwing: error) }
    }

    private func finish(returning location: CLLocation) {
        let pending = continuation
        continuation = nil
        pending?.resume(returning: location)
    }

    private func finish(throwing error: Error) {
        let pending = continuation
        continuation = nil
        pending?.resume(throwing: error)
    }
}

private enum LocationError: LocalizedError {
    case permissionDenied
    case backgroundPermissionDenied
    case positionNeededFirst
    case unavailable

    var errorDescription: String? {
        switch self {
        case .permissionDenied:
            return "Autorise la position pour trouver l’arrêt le plus proche, ou cherche-le par son nom."
        case .backgroundPermissionDenied:
            return "Autorise la position quand MobiGo est ouverte pour suivre ton trajet."
        case .positionNeededFirst:
            return "Utilise d’abord ta position pour choisir un arrêt de départ."
        case .unavailable:
            return "Position indisponible pour le moment. Réessaie ou cherche un arrêt par son nom."
        }
    }
}
