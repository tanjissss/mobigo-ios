import Foundation

struct StopSearchResponse: Decodable {
    let aantalHits: Int
    let haltes: [StopSearchHit]
}

struct StopSearchHit: Decodable {
    let entiteitnummer: String
    let haltenummer: String
    let omschrijving: String
    let omschrijvingGemeente: String?
    let omschrijvingLang: String?
}

struct StopFeature: Identifiable, Sendable {
    let id: String
    let properties: StopProperties
}

struct NearbyDeLijnStop: Identifiable, Sendable {
    let stop: StopFeature
    let latitude: Double
    let longitude: Double
    let distanceMeters: Double
    var id: String { stop.id }
    var walkMinutes: Int { max(1, Int(ceil(distanceMeters * 1.25 / 75))) }
}

private struct NearbyStopsResponse: Decodable { let haltes: [NearbyStopHit] }
private struct NearbyStopHit: Decodable {
    let type: String
    let id: String
    let naam: String
    let afstand: Int
    let geoCoordinaat: StopCoordinate
    let links: [NearbyStopLink]?
}
private struct StopCoordinate: Decodable { let latitude: Double; let longitude: Double }
private struct NearbyStopLink: Decodable { let rel: String; let url: String }

struct StopProperties: Decodable, Sendable {
    let ENTITEITNUMMER: String
    let STOPID: String
    let NAAMHALTE: String
    let NAAMGEM: String
}

struct DeLijnStopPassage: Decodable, Identifiable {
    let id: String
    let lineNumber: String
    let destination: String
    var scheduledTime: Date
    let realtimeTime: Date
    let hasRealtimePrediction: Bool
    var hasScheduledTime: Bool = true
    var vehicleMode: String? = nil
    var entityID: String? = nil
    var minutesAway: Int { max(0, Int(realtimeTime.timeIntervalSinceNow / 60)) }
}

struct JourneyStopCoordinate: Codable, Hashable, Sendable {
    let entityID: String
    let stopID: String
    let latitude: Double
    let longitude: Double
}

struct DeLijnJourney: Identifiable, Sendable, Codable {
    let id: String
    let line: String
    let destination: String
    let lineDirection: String
    let departure: Date
    let arrival: Date
    let delayMinutes: Int
    let hasRealtimePrediction: Bool
    let transferStop: String?
    let transferStopID: String?
    let transferArrival: Date?
    let secondLine: String?
    let secondLineDirection: String?
    let secondDeparture: Date?
    let secondTransferStop: String?
    let secondTransferStopID: String?
    let secondTransferArrival: Date?
    let thirdLine: String?
    let thirdLineDirection: String?
    let thirdDeparture: Date?
    var firstLegStopIDs: [String] = []
    var secondLegStopIDs: [String] = []
    var thirdLegStopIDs: [String] = []
    var firstLegEntityID: String? = nil
    var secondLegEntityID: String? = nil
    var thirdLegEntityID: String? = nil
    var firstLegMode: String? = nil
    var secondLegMode: String? = nil
    var thirdLegMode: String? = nil
    var firstBoardStopName: String? = nil
    var firstBoardStopID: String? = nil
    var secondBoardStopName: String? = nil
    var secondBoardStopID: String? = nil
    var thirdBoardStopName: String? = nil
    var thirdBoardStopID: String? = nil
    var firstLegCoordinates: [JourneyStopCoordinate]? = nil
    var secondLegCoordinates: [JourneyStopCoordinate]? = nil
    var thirdLegCoordinates: [JourneyStopCoordinate]? = nil
    var durationMinutes: Int { max(0, Int(arrival.timeIntervalSince(departure) / 60)) }
}

struct CachedDeLijnJourney: Codable {
    let journey: DeLijnJourney
    let originStopID: String
    let originStopName: String
    let homeWalkMinutes: Int
    let destinationStopID: String
    let destinationEntityID: String
    let destinationName: String
    let targetArrival: Date
    let homeLatitude: Double
    let homeLongitude: Double
    let destinationLatitude: Double
    let destinationLongitude: Double
}

enum DeLijnJourneyCache {
    private static let storageKey = "busmind.cached-journey.v1"

    static func clear() { UserDefaults.standard.removeObject(forKey: storageKey) }

    static func load(originStopID: String, destinationStopID: String, targetArrival: Date,
                     homeLatitude: Double, homeLongitude: Double,
                     destinationLatitude: Double, destinationLongitude: Double) -> CachedDeLijnJourney? {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let record = try? JSONDecoder().decode(CachedDeLijnJourney.self, from: data),
              Calendar.current.isDate(record.targetArrival, equalTo: targetArrival, toGranularity: .minute),
              record.journey.departure > .now else { return nil }

        if homeLatitude != 0, homeLongitude != 0,
           record.homeLatitude != 0, record.homeLongitude != 0 {
            guard distanceMeters(record.homeLatitude, record.homeLongitude, homeLatitude, homeLongitude) <= 100 else { return nil }
        } else if record.originStopID != originStopID {
            return nil
        }

        if destinationLatitude != 0, destinationLongitude != 0,
           record.destinationLatitude != 0, record.destinationLongitude != 0 {
            guard distanceMeters(record.destinationLatitude, record.destinationLongitude,
                                  destinationLatitude, destinationLongitude) <= 100 else { return nil }
        } else if record.destinationStopID != destinationStopID {
            return nil
        }
        return record
    }

    static func save(_ journey: DeLijnJourney, originStopID: String, originStopName: String,
                     homeWalkMinutes: Int, destinationStopID: String,
                     destinationEntityID: String, destinationName: String,
                     targetArrival: Date, homeLatitude: Double, homeLongitude: Double,
                     destinationLatitude: Double, destinationLongitude: Double) {
        let record = CachedDeLijnJourney(journey: journey, originStopID: originStopID,
            originStopName: originStopName, homeWalkMinutes: homeWalkMinutes,
            destinationStopID: destinationStopID, destinationEntityID: destinationEntityID,
            destinationName: destinationName, targetArrival: targetArrival,
            homeLatitude: homeLatitude, homeLongitude: homeLongitude,
            destinationLatitude: destinationLatitude, destinationLongitude: destinationLongitude)
        guard let data = try? JSONEncoder().encode(record) else { return }
        UserDefaults.standard.set(data, forKey: storageKey)
    }

    private static func distanceMeters(_ latitude1: Double, _ longitude1: Double,
                                       _ latitude2: Double, _ longitude2: Double) -> Double {
        let radians = Double.pi / 180
        let dLat = (latitude2 - latitude1) * radians
        let dLon = (longitude2 - longitude1) * radians
        let a = sin(dLat / 2) * sin(dLat / 2)
            + cos(latitude1 * radians) * cos(latitude2 * radians)
                * sin(dLon / 2) * sin(dLon / 2)
        return 6_371_000 * 2 * atan2(sqrt(a), sqrt(1 - a))
    }
}

private struct ScheduleStop {
    let id: String
    let time: Date?
}

private struct ScheduleTrip {
    let number: String
    let line: String
    let destination: String
    let stops: [ScheduleStop]
}

private struct TransferCandidate {
    let trip: ScheduleTrip
    let transferIndex: Int
    let arrival: Date
    let departure: Date
    let hasRealtimePrediction: Bool
}

private struct TwoTransferCandidate {
    let first: TransferCandidate
    let firstTransferID: String
    let secondTrip: ScheduleTrip
    let secondDeparture: Date
    let secondArrival: Date
}

private struct RawPassages: Decodable { let halteDoorkomsten: [RawStop] }
private struct RawStop: Decodable { let doorkomsten: [RawPassage] }
private struct RawPassage: Decodable {
    let doorkomstId: String
    let entiteitnummer: String?
    let lijnnummer: Int
    let bestemming: String
    let dienstregelingTijdstip: String
    let realTimeTijdstip: String?
    let predictionStatussen: [String]?

    private enum CodingKeys: String, CodingKey {
        case doorkomstId, entiteitnummer, lijnnummer, bestemming, dienstregelingTijdstip, realTimeTijdstip, predictionStatussen
        case realTimeTijdstipDash = "real-timeTijdstip"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        doorkomstId = try values.decode(String.self, forKey: .doorkomstId)
        if let value = try? values.decode(String.self, forKey: .entiteitnummer) {
            entiteitnummer = value
        } else if let value = try? values.decode(Int.self, forKey: .entiteitnummer) {
            entiteitnummer = String(value)
        } else {
            entiteitnummer = nil
        }
        lijnnummer = try values.decode(Int.self, forKey: .lijnnummer)
        bestemming = try values.decode(String.self, forKey: .bestemming)
        dienstregelingTijdstip = try values.decode(String.self, forKey: .dienstregelingTijdstip)
        realTimeTijdstip = try values.decodeIfPresent(String.self, forKey: .realTimeTijdstip)
            ?? values.decodeIfPresent(String.self, forKey: .realTimeTijdstipDash)
        predictionStatussen = try values.decodeIfPresent([String].self, forKey: .predictionStatussen)
    }
}

private struct RawLineDetails: Decodable {
    let vervoertype: String?
}

private struct BMCRealtimeFeed: Decodable, Sendable {
    let entity: [BMCRealtimeEntity]
}

private struct BMCRealtimeEntity: Decodable, Sendable {
    let tripUpdate: BMCTripUpdate?
}

private struct BMCTripUpdate: Decodable, Sendable {
    let stopTimeUpdate: [BMCStopTimeUpdate]?
}

private struct BMCStopTimeUpdate: Decodable, Sendable {
    let stopId: String?
    let arrival: BMCEventTime?
    let departure: BMCEventTime?
}

private struct BMCEventTime: Decodable, Sendable {
    let time: BMCInt64?
    let delay: Int?
}

private struct BMCInt64: Decodable, Sendable {
    let value: Int64

    private enum CodingKeys: String, CodingKey { case low, high }

    init(from decoder: Decoder) throws {
        if let scalar = try? decoder.singleValueContainer(),
           let value = try? scalar.decode(Int64.self) {
            self.value = value
            return
        }

        let parts = try decoder.container(keyedBy: CodingKeys.self)
        let low = try parts.decode(Int64.self, forKey: .low)
        let high = try parts.decode(Int64.self, forKey: .high)
        let bits = (UInt64(truncatingIfNeeded: high) << 32) | UInt64(truncatingIfNeeded: low)
        value = Int64(bitPattern: bits)
    }
}

final class DeLijnClient: @unchecked Sendable {
    static let shared = DeLijnClient()
    private let defaults = UserDefaults.standard
    private let cacheLock = NSLock()
    private var responseCache: [String: (expires: Date, data: Data)] = [:]
    private var nearbyStopCache: [String: (expires: Date, stops: [NearbyDeLijnStop])] = [:]
    private static let dateParsingLock = NSLock()
    private static let isoFractionalFormatter = ISO8601DateFormatter()
    private static let isoFormatter = ISO8601DateFormatter()
    private static let localFractionalFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "Europe/Brussels")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
        return formatter
    }()
    private static let localFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "Europe/Brussels")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        return formatter
    }()
    private init() {}

    var apiKey: String {
        get { defaults.string(forKey: "deLijnApiKey") ?? LocalSecrets.deLijnAPIKey }
        set { defaults.set(newValue, forKey: "deLijnApiKey") }
    }

    func departures(stopID: String, entityID: String = "2", count: Int = 6) async throws -> [DeLijnStopPassage] {
        guard !apiKey.isEmpty else { throw DeLijnError.missingKey }
        if let live = try? await stopPassages(stopID: stopID, entityID: entityID, count: count), !live.isEmpty {
            return await addingVehicleModes(to: live, fallbackEntityID: entityID)
        }
        let scheduled = try await scheduledStopPassages(stopID: stopID, entityID: entityID, count: count)
        return await addingVehicleModes(to: scheduled, fallbackEntityID: entityID)
    }

    private func stopPassages(stopID: String, entityID: String, count: Int) async throws -> [DeLijnStopPassage] {
        let urlString = "https://api.delijn.be/DLKernOpenData/api/v1/haltes/\(entityID)/\(stopID)/real-time?maxAantalDoorkomsten=\(count)"
        guard let url = URL(string: urlString) else { throw DeLijnError.badStopID }
        var request = URLRequest(url: url)
        request.timeoutInterval = 12
        request.setValue(apiKey, forHTTPHeaderField: "Ocp-Apim-Subscription-Key")
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw DeLijnError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw DeLijnError.http(http.statusCode) }
        let raw = try JSONDecoder().decode(RawPassages.self, from: data)
        return raw.halteDoorkomsten.flatMap(\.doorkomsten).compactMap { passage in
            let planned = Self.parseDate(passage.dienstregelingTijdstip)
            let predicted = passage.realTimeTijdstip.flatMap(Self.parseDate)
            guard let planned else { return nil }
            let hasPrediction = predicted != nil && !(passage.predictionStatussen ?? []).contains("GEENREALTIME")
            return DeLijnStopPassage(
                id: passage.doorkomstId,
                lineNumber: String(passage.lijnnummer),
                destination: passage.bestemming,
                scheduledTime: planned,
                realtimeTime: hasPrediction ? predicted! : planned,
                hasRealtimePrediction: hasPrediction,
                hasScheduledTime: true,
                vehicleMode: nil,
                entityID: passage.entiteitnummer ?? entityID
            )
        }.filter { $0.realtimeTime >= .now }.sorted { $0.realtimeTime < $1.realtimeTime }
    }

    private func scheduledStopPassages(stopID: String, entityID: String, count: Int) async throws -> [DeLijnStopPassage] {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "Europe/Brussels") ?? .current
        let firstDay = calendar.startOfDay(for: .now)
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = calendar.timeZone
        dateFormatter.dateFormat = "yyyy-MM-dd"

        // When De Lijn's live board has no more service tonight, show the
        // next published timetable instead of leaving the widget empty.
        for dayOffset in 0..<8 {
            guard let serviceDay = calendar.date(byAdding: .day, value: dayOffset, to: firstDay),
                  let baseURL = URL(string: "https://api.delijn.be/DLKernOpenData/api/v1/haltes/\(entityID)/\(stopID)/dienstregelingen"),
                  var components = URLComponents(url: baseURL, resolvingAgainstBaseURL: false) else {
                throw DeLijnError.badStopID
            }
            components.queryItems = [URLQueryItem(name: "datum", value: dateFormatter.string(from: serviceDay))]
            guard let url = components.url else { throw DeLijnError.badStopID }
            let data = try await get(url)
            let raw = try JSONDecoder().decode(RawPassages.self, from: data)
            let passages = raw.halteDoorkomsten.flatMap(\.doorkomsten).compactMap { passage -> DeLijnStopPassage? in
                guard let scheduled = Self.parseDate(passage.dienstregelingTijdstip), scheduled > .now else { return nil }
                return DeLijnStopPassage(id: passage.doorkomstId,
                    lineNumber: String(passage.lijnnummer), destination: passage.bestemming,
                    scheduledTime: scheduled, realtimeTime: scheduled,
                    hasRealtimePrediction: false, hasScheduledTime: true,
                    vehicleMode: nil, entityID: passage.entiteitnummer ?? entityID)
            }.sorted { $0.realtimeTime < $1.realtimeTime }
            if !passages.isEmpty { return Array(passages.prefix(max(1, count))) }
        }
        return []
    }

    private func addingVehicleModes(to passages: [DeLijnStopPassage], fallbackEntityID: String) async -> [DeLijnStopPassage] {
        let keys = Set(passages.map { "\($0.entityID ?? fallbackEntityID)|\($0.lineNumber)" })
        let modes = await withTaskGroup(of: (String, String?).self) { group in
            for key in keys {
                let parts = key.split(separator: "|", maxSplits: 1).map(String.init)
                guard parts.count == 2 else { continue }
                group.addTask {
                    (key, await self.vehicleMode(entityID: parts[0], lineNumber: parts[1]))
                }
            }
            var result: [String: String] = [:]
            for await (key, mode) in group {
                if let mode { result[key] = mode }
            }
            return result
        }
        return passages.map { passage in
            var enriched = passage
            let key = "\(passage.entityID ?? fallbackEntityID)|\(passage.lineNumber)"
            enriched.vehicleMode = modes[key]
            return enriched
        }
    }

    private func vehicleMode(entityID: String, lineNumber: String) async -> String? {
        guard let url = URL(string: "https://api.delijn.be/DLKernOpenData/api/v1/lijnen/\(entityID)/\(lineNumber)"),
              let data = try? await get(url),
              let details = try? JSONDecoder().decode(RawLineDetails.self, from: data),
              let mode = details.vervoertype?.trimmingCharacters(in: .whitespacesAndNewlines), !mode.isEmpty else { return nil }
        return mode.uppercased()
    }

    func realtimeDelay(stopID: String, entityID: String = "2", line: String, scheduledTime: Date) async throws -> Int? {
        if ["tec", "letec", "nmbs", "sncb"].contains(entityID.lowercased()) {
            return await bmcRealtimeDelay(stopID: stopID, entityID: entityID, scheduledTime: scheduledTime)
        }
        let passages: [DeLijnStopPassage]
        do {
            passages = try await departures(stopID: stopID, entityID: entityID, count: 30)
        } catch {
            return await bmcRealtimeDelay(stopID: stopID, entityID: entityID, scheduledTime: scheduledTime)
        }
        let matching = passages.filter {
            $0.lineNumber == line && abs($0.scheduledTime.timeIntervalSince(scheduledTime)) <= 180 && $0.hasRealtimePrediction
        }.min { abs($0.scheduledTime.timeIntervalSince(scheduledTime)) < abs($1.scheduledTime.timeIntervalSince(scheduledTime)) }
        if let matching {
            return Int((matching.realtimeTime.timeIntervalSince(matching.scheduledTime) / 60).rounded())
        }
        return await bmcRealtimeDelay(stopID: stopID, entityID: entityID, scheduledTime: scheduledTime)
    }

    private func bmcRealtimeDelay(stopID: String, entityID: String, scheduledTime: Date) async -> Int? {
        guard !LocalSecrets.bmcAPIKey.isEmpty else { return nil }
        let agencyID: String
        switch entityID.lowercased() {
        case "tec", "letec": agencyID = "tec"
        case "nmbs", "sncb": agencyID = "nmbssncb"
        default: agencyID = "delijn"
        }
        var components = URLComponents(string: "https://api-management-opendata-production.azure-api.net/api/gtfs/feed/\(agencyID)/rt/trip-update/")
        components?.queryItems = [
            URLQueryItem(name: "format", value: "json"),
            URLQueryItem(name: "unroll", value: "false")
        ]
        guard let url = components?.url else { return nil }
        let cacheKey = "bmc-gtfs-rt-\(agencyID)-trip-update"
        let data: Data
        if let cached = cachedResponse(for: cacheKey) {
            data = cached
        } else {
            var request = URLRequest(url: url)
            request.timeoutInterval = 15
            request.setValue(LocalSecrets.bmcAPIKey, forHTTPHeaderField: "bmc-partner-key")
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            do {
                let (responseData, response) = try await URLSession.shared.data(for: request)
                guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { return nil }
                data = responseData
                storeResponse(responseData, for: cacheKey, lifetime: 45)
            } catch {
                return nil
            }
        }

        guard let feed = try? JSONDecoder().decode(BMCRealtimeFeed.self, from: data) else { return nil }
        let expectedStopID = "gs:\(agencyID):\(stopID)"
        let matches: [(delay: Int, offset: TimeInterval)] = feed.entity.flatMap { entity in
            (entity.tripUpdate?.stopTimeUpdate ?? []).compactMap { update in
                guard update.stopId == expectedStopID else { return nil }
                let event = [update.departure, update.arrival].compactMap { $0 }
                    .first { $0.time?.value != nil && $0.delay != nil }
                guard let epoch = event?.time?.value, let delaySeconds = event?.delay else { return nil }
                let predicted = Date(timeIntervalSince1970: TimeInterval(epoch))
                let planned = predicted.addingTimeInterval(TimeInterval(-delaySeconds))
                let offset = abs(planned.timeIntervalSince(scheduledTime))
                guard offset <= 180 else { return nil }
                return (delay: delaySeconds, offset: offset)
            }
        }
        guard let closest = matches.min(by: { $0.offset < $1.offset }) else { return nil }
        // A stop can have multiple lines departing at the same minute. If the
        // feed cannot distinguish those predictions from the requested trip,
        // leave the existing timetable untouched instead of showing a false delay.
        if matches.contains(where: { abs($0.offset - closest.offset) < 30 }) {
            return nil
        }
        return Int((Double(closest.delay) / 60).rounded())
    }

    private static func parseDate(_ value: String) -> Date? {
        dateParsingLock.lock()
        defer { dateParsingLock.unlock() }
        let timePart = value.split(separator: "T", maxSplits: 1).last.map(String.init) ?? ""
        let hasTimezone = timePart.contains("Z") || timePart.contains("+") || timePart.contains("-")
        if !hasTimezone {
            // Most scheduled stop times use Brussels local time without an offset.
            return (value.contains(".") ? localFractionalFormatter : localFormatter).date(from: value)
        }
        isoFractionalFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = isoFractionalFormatter.date(from: value) { return date }
        isoFormatter.formatOptions = [.withInternetDateTime]
        return isoFormatter.date(from: value)
    }

    func searchStops(_ term: String) async throws -> [StopFeature] {
        guard !apiKey.isEmpty else { throw DeLijnError.missingKey }
        var pathAllowed = CharacterSet.urlPathAllowed
        pathAllowed.remove(charactersIn: "/?#")
        guard let encodedTerm = term.addingPercentEncoding(withAllowedCharacters: pathAllowed),
              let url = URL(string: "https://api.delijn.be/DLZoekOpenData/v1/zoek/haltes/\(encodedTerm)?maxAantalHits=20") else {
            throw DeLijnError.invalidResponse
        }
        var request = URLRequest(url: url)
        request.timeoutInterval = 12
        request.setValue(apiKey, forHTTPHeaderField: "Ocp-Apim-Subscription-Key")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw DeLijnError.invalidResponse
        }
        let result = try JSONDecoder().decode(StopSearchResponse.self, from: data)
        let matches = result.haltes.map { hit in
            StopFeature(
                id: "\(hit.entiteitnummer)-\(hit.haltenummer)",
                properties: StopProperties(
                    ENTITEITNUMMER: hit.entiteitnummer,
                    STOPID: hit.haltenummer,
                    NAAMHALTE: hit.omschrijving,
                    NAAMGEM: hit.omschrijvingGemeente ?? hit.omschrijvingLang ?? "De Lijn"
                )
            )
        }
        let searchText = term.trimmingCharacters(in: .whitespacesAndNewlines)
        return matches.sorted { lhs, rhs in
            let lhsMatches = lhs.properties.NAAMHALTE.range(of: searchText, options: [.caseInsensitive, .diacriticInsensitive]) != nil
            let rhsMatches = rhs.properties.NAAMHALTE.range(of: searchText, options: [.caseInsensitive, .diacriticInsensitive]) != nil
            if lhsMatches != rhsMatches { return lhsMatches }
            return lhs.properties.NAAMHALTE.localizedStandardCompare(rhs.properties.NAAMHALTE) == .orderedAscending
        }
    }

    func stopCoordinate(stopID: String, entityID: String = "2") async throws -> (latitude: Double, longitude: Double) {
        let url = URL(string: "https://api.delijn.be/DLKernOpenData/api/v1/haltes/\(entityID)/\(stopID)")!
        let data = try await get(url)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let coordinate = root["geoCoordinaat"] as? [String: Any],
              let latitude = coordinate["latitude"] as? Double,
              let longitude = coordinate["longitude"] as? Double else { throw DeLijnError.invalidResponse }
        return (latitude, longitude)
    }

    func nearbyStops(latitude: Double, longitude: Double, limit: Int = 8, radiusMeters: Int = 3000) async throws -> [NearbyDeLijnStop] {
        guard !apiKey.isEmpty else { throw DeLijnError.missingKey }
        let count = min(50, max(1, limit * 2))
        let radius = min(3000, max(100, radiusMeters))
        let urlString = "https://api.delijn.be/DLKernOpenData/api/v1/haltes/indebuurt/\(latitude),\(longitude)?maxAantalHaltes=\(count)&radius=\(radius)"
        guard let url = URL(string: urlString) else { throw DeLijnError.invalidResponse }
        let cacheKey = url.absoluteString
        if let cached = cachedNearbyStops(for: cacheKey) { return cached }
        var request = URLRequest(url: url)
        request.timeoutInterval = 10
        request.setValue(apiKey, forHTTPHeaderField: "Ocp-Apim-Subscription-Key")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw DeLijnError.invalidResponse
        }
        let nearby = try JSONDecoder().decode(NearbyStopsResponse.self, from: data)
        let result = Array(nearby.haltes.compactMap { item -> NearbyDeLijnStop? in
            guard item.type == "DELIJN",
                  let href = item.links?.first(where: { $0.rel == "lijnrichtingen" })?.url,
                  let components = URLComponents(string: href) else { return nil }
            let path = components.path.split(separator: "/").map(String.init)
            guard let haltesIndex = path.firstIndex(of: "haltes"),
                  path.indices.contains(haltesIndex + 2) else { return nil }
            let entityID = path[haltesIndex + 1]
            let stopID = item.id
            let stop = StopFeature(id: "\(entityID)-\(stopID)", properties: StopProperties(
                ENTITEITNUMMER: entityID, STOPID: stopID, NAAMHALTE: item.naam, NAAMGEM: ""))
            return NearbyDeLijnStop(stop: stop, latitude: item.geoCoordinaat.latitude,
                longitude: item.geoCoordinaat.longitude, distanceMeters: Double(item.afstand))
        }.sorted { $0.distanceMeters < $1.distanceMeters }.prefix(limit))
        storeNearbyStops(result, for: cacheKey)
        return result
    }

    private static func distanceMeters(_ latitude1: Double, _ longitude1: Double, _ latitude2: Double, _ longitude2: Double) -> Double {
        let radians = Double.pi / 180
        let dLat = (latitude2 - latitude1) * radians
        let dLon = (longitude2 - longitude1) * radians
        let a = sin(dLat / 2) * sin(dLat / 2)
            + cos(latitude1 * radians) * cos(latitude2 * radians) * sin(dLon / 2) * sin(dLon / 2)
        return 6_371_000 * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    func planJourneys(from origin: StopFeature, to destination: StopFeature, after date: Date = .now,
                      arrivingBy: Date? = nil, finalWalkMinutes: Int = 0,
                      fallbackArrivalBy: Date? = nil) async throws -> [DeLijnJourney] {
        try await withTimeout(seconds: 18) {
            let walk = TimeInterval(max(0, finalWalkMinutes) * 60)
            let calendar = Calendar(identifier: .gregorian)
            let serviceDay = arrivingBy.map { calendar.startOfDay(for: $0) } ?? date
            let earliestDeparture = max(date, serviceDay)
            let todayDeadline = arrivingBy?.addingTimeInterval(-walk)
            let today = try await self.planJourneys(from: origin, to: destination, after: earliestDeparture,
                serviceDay: serviceDay, latestArrival: todayDeadline)
            guard today.isEmpty else { return today }
            let nextDay = fallbackArrivalBy.map { calendar.startOfDay(for: $0) }
                ?? calendar.date(byAdding: .day, value: 1, to: serviceDay) ?? serviceDay
            let nextArrivalDay = arrivingBy.flatMap { calendar.date(byAdding: .day, value: 1, to: $0) }
            let tomorrowDeadline = fallbackArrivalBy?.addingTimeInterval(-walk)
                ?? nextArrivalDay?.addingTimeInterval(-walk)
            return try await self.planJourneys(from: origin, to: destination, after: max(date, nextDay),
                serviceDay: nextDay, latestArrival: tomorrowDeadline)
        }
    }

    private func withTimeout<T: Sendable>(seconds: UInt64, operation: @escaping @Sendable () async throws -> T) async throws -> T {
        try await withThrowingTaskGroup(of: T.self) { group in
            group.addTask { try await operation() }
            group.addTask {
                try await Task.sleep(nanoseconds: seconds * 1_000_000_000)
                throw DeLijnError.timeout
            }
            defer { group.cancelAll() }
            guard let first = try await group.next() else { throw CancellationError() }
            return first
        }
    }

    private func planJourneys(from origin: StopFeature, to destination: StopFeature, after date: Date,
                              serviceDay: Date, latestArrival: Date? = nil) async throws -> [DeLijnJourney] {
        guard !apiKey.isEmpty else { throw DeLijnError.missingKey }
        let entity = origin.properties.ENTITEITNUMMER
        let directionsURL = URL(string: "https://api.delijn.be/DLKernOpenData/api/v1/haltes/\(entity)/\(origin.properties.STOPID)/lijnrichtingen")!
        let directionsData = try await get(directionsURL)
        let directionsJSON = try JSONSerialization.jsonObject(with: directionsData) as? [String: Any]
        let directions = directionsJSON?["lijnrichtingen"] as? [[String: Any]] ?? []
        let liveDepartures = (try? await departures(stopID: origin.properties.STOPID, entityID: entity, count: 30)) ?? []
        var journeys: [DeLijnJourney] = []

        // Fetch a bounded set of actual service patterns from De Lijn.
        let firstDirections = Array(directions.prefix(6)).compactMap { direction -> (String, String)? in
            guard let line = direction["lijnnummer"] as? String, let way = direction["richting"] as? String else { return nil }
            return (line, way)
        }
        let firstSchedules = try await fetchSchedules(firstDirections, entity: entity, serviceDay: serviceDay)
        let allFirstTrips = firstSchedules.flatMap { $0.2 }
        var transferCandidates: [TransferCandidate] = []

        for trip in allFirstTrips {
            guard let originIndex = trip.stops.firstIndex(where: { $0.id == origin.properties.STOPID }),
                  originIndex + 1 < trip.stops.count,
                  let scheduledDeparture = trip.stops[originIndex].time,
                  scheduledDeparture >= date else { continue }
            let liveDelay = Self.delay(for: trip.line, scheduledDeparture: scheduledDeparture, live: liveDepartures)
            let delay = liveDelay.minutes
            let actualDeparture = scheduledDeparture.addingTimeInterval(TimeInterval(delay * 60))
            guard actualDeparture >= date else { continue }
            let downstream = trip.stops.indices.filter { $0 > originIndex }
            if let destinationIndex = downstream.first(where: { trip.stops[$0].id == destination.properties.STOPID }),
               let scheduledArrival = trip.stops[destinationIndex].time {
                let actualArrival = scheduledArrival.addingTimeInterval(TimeInterval(delay * 60))
                journeys.append(DeLijnJourney(id: "direct-\(trip.line)-\(trip.number)-\(scheduledDeparture.timeIntervalSince1970)", line: trip.line,
                    destination: destination.properties.NAAMHALTE, lineDirection: trip.destination, departure: actualDeparture, arrival: actualArrival, delayMinutes: delay,
                    hasRealtimePrediction: liveDelay.hasPrediction,
                    transferStop: nil, transferStopID: nil, transferArrival: nil,
                    secondLine: nil, secondLineDirection: nil, secondDeparture: nil,
                    secondTransferStop: nil, secondTransferStopID: nil, secondTransferArrival: nil,
                    thirdLine: nil, thirdLineDirection: nil, thirdDeparture: nil,
                    firstLegStopIDs: trip.stops[originIndex...destinationIndex].map(\.id),
                    firstLegEntityID: entity, firstLegMode: "BUS",
                    firstBoardStopName: origin.properties.NAAMHALTE, firstBoardStopID: origin.properties.STOPID))
            }
            for index in downstream.prefix(12) where trip.stops[index].id != destination.properties.STOPID {
                guard let scheduledArrival = trip.stops[index].time,
                      scheduledArrival.addingTimeInterval(TimeInterval(delay * 60)) > actualDeparture else { continue }
                    transferCandidates.append(TransferCandidate(trip: trip, transferIndex: index,
                    arrival: scheduledArrival.addingTimeInterval(TimeInterval(delay * 60)), departure: actualDeparture,
                    hasRealtimePrediction: liveDelay.hasPrediction))
            }
        }

        // Score a handful of downstream stops by interchange richness; only query
        // their real line directions and today's schedules, never invent a route.
        var candidatesByStop: [String: [TransferCandidate]] = [:]
        for candidate in transferCandidates {
            let stopID = candidate.trip.stops[candidate.transferIndex].id
            candidatesByStop[stopID, default: []].append(candidate)
        }
        // Start with the earliest real transfer points. A large interchange
        // later in the route can otherwise crowd out a nearby usable platform,
        // while probing every candidate multiplies cold-start API latency.
        let candidateIDs = Array(candidatesByStop.keys.sorted { lhs, rhs in
            let lhsTime = candidatesByStop[lhs, default: []].map(\.arrival).min() ?? .distantFuture
            let rhsTime = candidatesByStop[rhs, default: []].map(\.arrival).min() ?? .distantFuture
            if lhsTime != rhsTime { return lhsTime < rhsTime }
            return lhs < rhs
        }.prefix(3))
        let destinationDirectionsURL = URL(string: "https://api.delijn.be/DLKernOpenData/api/v1/haltes/\(destination.properties.ENTITEITNUMMER)/\(destination.properties.STOPID)/lijnrichtingen")!
        let destinationDirectionsData = try? await get(destinationDirectionsURL)
        let destinationDirectionsJSON = destinationDirectionsData.flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] } ?? nil
        let destinationDirectionKeys = Set((destinationDirectionsJSON?["lijnrichtingen"] as? [[String: Any]] ?? []).compactMap { item -> String? in
            guard let line = item["lijnnummer"] as? String, let way = item["richting"] as? String else { return nil }
            return "\(line)|\(way)"
        })

        // A transfer often uses opposite platforms with different stop IDs.
        // Let riders walk between platforms within 250 m, then board only a
        // direction that actually serves the selected destination stop.
        var boardStopToArrivalStop = Dictionary(uniqueKeysWithValues: candidateIDs.map { ($0, $0) })
        var boardStopWalkMinutes: [String: Int] = [:]
        var boardStopNames: [String: String] = [:]
        let nearbyPlatforms = await withTaskGroup(of: (String, [NearbyDeLijnStop]).self) { group in
            for stopID in candidateIDs {
                group.addTask {
                    guard let coordinate = try? await self.stopCoordinate(stopID: stopID, entityID: entity) else {
                        return (stopID, [])
                    }
                    let stops = (try? await self.nearbyStops(latitude: coordinate.latitude,
                        longitude: coordinate.longitude, limit: 4, radiusMeters: 350)) ?? []
                    return (stopID, stops)
                }
            }
            var result: [(String, [NearbyDeLijnStop])] = []
            for await item in group { result.append(item) }
            return result
        }
        let adjacentPlatforms = nearbyPlatforms.flatMap { arrivalStopID, stops in
            stops.filter { $0.stop.properties.STOPID != arrivalStopID && $0.distanceMeters <= 250 }
                .prefix(4)
                .map { (arrivalStopID, $0) }
        }
        let adjacentDirections = await withTaskGroup(of: (String, String, NearbyDeLijnStop, Data?).self) { group in
            for (arrivalStopID, platform) in adjacentPlatforms {
                let boardID = platform.stop.properties.STOPID
                group.addTask {
                    let url = URL(string: "https://api.delijn.be/DLKernOpenData/api/v1/haltes/\(entity)/\(boardID)/lijnrichtingen")!
                    return (arrivalStopID, boardID, platform, try? await self.get(url))
                }
            }
            var result: [(String, String, NearbyDeLijnStop, Data?)] = []
            for await item in group { result.append(item) }
            return result
        }
        let interchangeData = await withTaskGroup(of: (String, Data?).self) { group in
            for stopID in candidateIDs {
                group.addTask {
                    let url = URL(string: "https://api.delijn.be/DLKernOpenData/api/v1/haltes/\(entity)/\(stopID)/lijnrichtingen")!
                    return (stopID, try? await self.get(url))
                }
            }
            var result: [(String, Data?)] = []
            for await item in group { result.append(item) }
            return result
        }
        var secondDirections: [(String, String, String)] = []
        var secondDirectionsByStop: [String: Set<String>] = [:]
        var relayDirections: [(String, String, String)] = []
        for (stopID, maybeData) in interchangeData {
            guard let data = maybeData else { continue }
            guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let items = root["lijnrichtingen"] as? [[String: Any]] else { continue }
            let parsed = items.compactMap { item -> (String, String)? in
                guard let line = item["lijnnummer"] as? String, let way = item["richting"] as? String else { return nil }
                return (line, way)
            }
            for (line, way) in parsed {
                let key = "\(line)|\(way)"
                if destinationDirectionKeys.contains(key) {
                    secondDirections.append((stopID, line, way))
                    secondDirectionsByStop[stopID, default: []].insert(key)
                } else if !candidatesByStop[stopID, default: []].contains(where: { $0.trip.line == line }) {
                    relayDirections.append((stopID, line, way))
                }
            }
        }
        for (arrivalStopID, boardStopID, platform, maybeData) in adjacentDirections {
            guard let data = maybeData,
                  let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let items = root["lijnrichtingen"] as? [[String: Any]] else { continue }
            for item in items {
                guard let line = item["lijnnummer"] as? String, let way = item["richting"] as? String,
                      destinationDirectionKeys.contains("\(line)|\(way)") else { continue }
                boardStopToArrivalStop[boardStopID] = arrivalStopID
                boardStopWalkMinutes[boardStopID] = platform.walkMinutes
                boardStopNames[boardStopID] = platform.stop.properties.NAAMHALTE
                secondDirections.append((boardStopID, line, way))
                secondDirectionsByStop[boardStopID, default: []].insert("\(line)|\(way)")
            }
        }
        let secondSchedules = try await fetchSchedules(secondDirections.map { ($0.1, $0.2) }, entity: entity, serviceDay: serviceDay)
        for (line, way, trips) in secondSchedules {
            let directionKey = "\(line)|\(way)"
            let stopIDs = secondDirectionsByStop.compactMap { $0.value.contains(directionKey) ? $0.key : nil }
            for boardStopID in stopIDs {
                let arrivalStopID = boardStopToArrivalStop[boardStopID] ?? boardStopID
                let walkMinutes = boardStopWalkMinutes[boardStopID] ?? 0
                guard let firstOptions = candidatesByStop[arrivalStopID] else { continue }
                for first in firstOptions {
                    let earliestConnection = first.arrival.addingTimeInterval(TimeInterval((4 + walkMinutes) * 60))
                    for secondTrip in trips {
                    guard let fromIndex = secondTrip.stops.firstIndex(where: { $0.id == boardStopID }),
                          fromIndex + 1 < secondTrip.stops.count,
                          let secondDeparture = secondTrip.stops[fromIndex].time,
                          secondDeparture >= earliestConnection,
                          secondDeparture.timeIntervalSince(first.arrival) <= 35 * 60,
                          let toIndex = secondTrip.stops.indices.first(where: { $0 > fromIndex && secondTrip.stops[$0].id == destination.properties.STOPID }),
                          let secondArrival = secondTrip.stops[toIndex].time, secondArrival > secondDeparture else { continue }
                    let firstTrip = first.trip
                    guard let originIndex = firstTrip.stops.firstIndex(where: { $0.id == origin.properties.STOPID }),
                          let firstScheduledDeparture = firstTrip.stops[originIndex].time,
                          let firstScheduledArrival = firstTrip.stops[first.transferIndex].time else { continue }
                    let delay = Int(first.arrival.timeIntervalSince(firstScheduledArrival) / 60)
                    let firstDeparture = firstScheduledDeparture.addingTimeInterval(TimeInterval(delay * 60))
                    let transferLabel = walkMinutes > 0
                        ? "Marche \(walkMinutes) min → \(boardStopNames[boardStopID] ?? "quai voisin")"
                        : first.trip.stops[first.transferIndex].id
                    journeys.append(DeLijnJourney(id: "transfer-\(firstTrip.number)-\(secondTrip.number)-\(boardStopID)", line: firstTrip.line,
                        destination: destination.properties.NAAMHALTE, lineDirection: firstTrip.destination, departure: firstDeparture, arrival: secondArrival, delayMinutes: delay,
                        hasRealtimePrediction: first.hasRealtimePrediction,
                        transferStop: transferLabel, transferStopID: arrivalStopID, transferArrival: first.arrival,
                        secondLine: line, secondLineDirection: secondTrip.destination, secondDeparture: secondDeparture,
                        secondTransferStop: nil, secondTransferStopID: nil, secondTransferArrival: nil,
                        thirdLine: nil, thirdLineDirection: nil, thirdDeparture: nil,
                        firstLegStopIDs: firstTrip.stops[firstTrip.stops.firstIndex(where: { $0.id == origin.properties.STOPID })!...first.transferIndex].map(\.id),
                        secondLegStopIDs: secondTrip.stops[fromIndex...toIndex].map(\.id),
                        firstLegEntityID: entity, secondLegEntityID: entity,
                        firstLegMode: "BUS", secondLegMode: "BUS",
                        firstBoardStopName: origin.properties.NAAMHALTE, firstBoardStopID: origin.properties.STOPID,
                        secondBoardStopName: boardStopNames[boardStopID] ?? transferLabel, secondBoardStopID: boardStopID))
                    }
                }
            }
        }

        // A two-change search is a fallback. One valid direct or one-change
        // route is enough to avoid expanding the graph and delaying the result.
        if journeys.isEmpty {
        // Keep the fallback graph small: up to six relay directions, four second
        // change stops, and eight final directions that actually serve the target.
        var relayByStop: [String: Set<String>] = [:]
        for (stopID, line, way) in relayDirections { relayByStop[stopID, default: []].insert("\(line)|\(way)") }
        let relayKeys = Set(relayDirections.map { "\($0.1)|\($0.2)" }).sorted { lhs, rhs in
            let lhsCount = relayDirections.filter { "\($0.1)|\($0.2)" == lhs }.count
            let rhsCount = relayDirections.filter { "\($0.1)|\($0.2)" == rhs }.count
            if lhsCount != rhsCount { return lhsCount > rhsCount }
            return lhs < rhs
        }
        let relaySchedules = try await fetchSchedules(relayKeys.compactMap { value -> (String, String)? in
            let parts = value.split(separator: "|", omittingEmptySubsequences: false)
            guard parts.count == 2 else { return nil }
            return (String(parts[0]), String(parts[1]))
        }.prefix(6).map { $0 }, entity: entity, serviceDay: serviceDay)
        var twoTransferCandidates: [String: [TwoTransferCandidate]] = [:]
        for (line, way, trips) in relaySchedules {
            let key = "\(line)|\(way)"
            let startStops = relayByStop.compactMap { $0.value.contains(key) ? $0.key : nil }
            for firstTransferID in startStops {
                guard let firstOptions = candidatesByStop[firstTransferID] else { continue }
                for first in firstOptions {
                    let earliest = first.arrival.addingTimeInterval(4 * 60)
                    for trip in trips {
                        guard let boardIndex = trip.stops.firstIndex(where: { $0.id == firstTransferID }),
                              boardIndex + 1 < trip.stops.count,
                              let secondDeparture = trip.stops[boardIndex].time,
                              secondDeparture >= earliest,
                              secondDeparture.timeIntervalSince(first.arrival) <= 35 * 60 else { continue }
                        for index in trip.stops.indices.filter({ $0 > boardIndex }).prefix(10) {
                            let secondTransferID = trip.stops[index].id
                            guard secondTransferID != destination.properties.STOPID,
                                  let secondArrival = trip.stops[index].time, secondArrival > secondDeparture else { continue }
                            twoTransferCandidates[secondTransferID, default: []].append(TwoTransferCandidate(
                                first: first, firstTransferID: firstTransferID, secondTrip: trip,
                                secondDeparture: secondDeparture, secondArrival: secondArrival))
                        }
                    }
                }
            }
        }
        let secondChangeIDs = twoTransferCandidates.keys.sorted { lhs, rhs in
            let lhsScore = Set(twoTransferCandidates[lhs, default: []].map { $0.secondTrip.line }).count
            let rhsScore = Set(twoTransferCandidates[rhs, default: []].map { $0.secondTrip.line }).count
            if lhsScore != rhsScore { return lhsScore > rhsScore }
            let lhsTime = twoTransferCandidates[lhs, default: []].map(\.secondArrival).min() ?? .distantFuture
            let rhsTime = twoTransferCandidates[rhs, default: []].map(\.secondArrival).min() ?? .distantFuture
            if lhsTime != rhsTime { return lhsTime < rhsTime }
            return lhs < rhs
        }.prefix(4).map { $0 }
        let secondChangeDirections = await withTaskGroup(of: (String, Data?).self) { group in
            for stopID in secondChangeIDs {
                group.addTask {
                    let url = URL(string: "https://api.delijn.be/DLKernOpenData/api/v1/haltes/\(entity)/\(stopID)/lijnrichtingen")!
                    return (stopID, try? await self.get(url))
                }
            }
            var result: [(String, Data?)] = []
            for await item in group { result.append(item) }
            return result
        }
        var finalDirections: [(String, String, String)] = []
        var finalDirectionsByStop: [String: Set<String>] = [:]
        for (stopID, maybeData) in secondChangeDirections {
            guard let data = maybeData else { continue }
            let root = try JSONSerialization.jsonObject(with: data) as? [String: Any]
            let items = root?["lijnrichtingen"] as? [[String: Any]] ?? []
            for item in items {
                guard let line = item["lijnnummer"] as? String, let way = item["richting"] as? String else { continue }
                let key = "\(line)|\(way)"
                if destinationDirectionKeys.contains(key) {
                    finalDirections.append((stopID, line, way))
                    finalDirectionsByStop[stopID, default: []].insert(key)
                }
            }
        }
        let selectedFinalKeys = Set(finalDirections.map { "\($0.1)|\($0.2)" }).sorted { lhs, rhs in
            let lhsCount = finalDirections.filter { "\($0.1)|\($0.2)" == lhs }.count
            let rhsCount = finalDirections.filter { "\($0.1)|\($0.2)" == rhs }.count
            if lhsCount != rhsCount { return lhsCount > rhsCount }
            return lhs < rhs
        }.prefix(8)
        let finalSchedules = try await fetchSchedules(selectedFinalKeys.compactMap { value -> (String, String)? in
            let parts = value.split(separator: "|", omittingEmptySubsequences: false)
            guard parts.count == 2 else { return nil }
            return (String(parts[0]), String(parts[1]))
        }, entity: entity, serviceDay: serviceDay)
        for (line, way, trips) in finalSchedules {
            let key = "\(line)|\(way)"
            let stopIDs = finalDirectionsByStop.compactMap { $0.value.contains(key) ? $0.key : nil }
            for stopID in stopIDs {
                for candidate in twoTransferCandidates[stopID, default: []] {
                    let earliest = candidate.secondArrival.addingTimeInterval(4 * 60)
                    for trip in trips {
                        guard let boardIndex = trip.stops.firstIndex(where: { $0.id == stopID }),
                              boardIndex + 1 < trip.stops.count,
                              let thirdDeparture = trip.stops[boardIndex].time,
                              thirdDeparture >= earliest,
                              thirdDeparture.timeIntervalSince(candidate.secondArrival) <= 35 * 60,
                              let arrivalIndex = trip.stops.indices.first(where: { $0 > boardIndex && trip.stops[$0].id == destination.properties.STOPID }),
                              let arrival = trip.stops[arrivalIndex].time, arrival > thirdDeparture else { continue }
                        let first = candidate.first
                        let firstTrip = first.trip
                        guard let originIndex = firstTrip.stops.firstIndex(where: { $0.id == origin.properties.STOPID }),
                              let scheduledDeparture = firstTrip.stops[originIndex].time,
                              let firstScheduledArrival = firstTrip.stops[first.transferIndex].time else { continue }
                        let delay = Int(first.arrival.timeIntervalSince(firstScheduledArrival) / 60)
                        let departure = scheduledDeparture.addingTimeInterval(TimeInterval(delay * 60))
                        journeys.append(DeLijnJourney(id: "two-\(firstTrip.number)-\(candidate.secondTrip.number)-\(trip.number)-\(stopID)",
                            line: firstTrip.line, destination: destination.properties.NAAMHALTE, lineDirection: firstTrip.destination, departure: departure, arrival: arrival, delayMinutes: delay,
                            hasRealtimePrediction: candidate.first.hasRealtimePrediction,
                            transferStop: "Arrêt \(candidate.firstTransferID)", transferStopID: candidate.firstTransferID, transferArrival: candidate.first.arrival,
                            secondLine: candidate.secondTrip.line, secondLineDirection: candidate.secondTrip.destination, secondDeparture: candidate.secondDeparture,
                            secondTransferStop: "Arrêt \(stopID)", secondTransferStopID: stopID, secondTransferArrival: candidate.secondArrival,
                            thirdLine: line, thirdLineDirection: trip.destination, thirdDeparture: thirdDeparture,
                            firstLegStopIDs: firstTrip.stops[firstTrip.stops.firstIndex(where: { $0.id == origin.properties.STOPID })!...first.transferIndex].map(\.id),
                            secondLegStopIDs: candidate.secondTrip.stops[candidate.secondTrip.stops.firstIndex(where: { $0.id == candidate.firstTransferID })!...candidate.secondTrip.stops.firstIndex(where: { $0.id == stopID })!].map(\.id),
                            thirdLegStopIDs: trip.stops[boardIndex...arrivalIndex].map(\.id),
                            firstLegEntityID: entity, secondLegEntityID: entity, thirdLegEntityID: entity,
                            firstLegMode: "BUS", secondLegMode: "BUS", thirdLegMode: "BUS",
                            firstBoardStopName: origin.properties.NAAMHALTE, firstBoardStopID: origin.properties.STOPID,
                            secondBoardStopName: "Arrêt \(candidate.firstTransferID)", secondBoardStopID: candidate.firstTransferID,
                            thirdBoardStopName: boardStopNames[stopID] ?? "Arrêt \(stopID)", thirdBoardStopID: stopID))
                    }
                }
            }
        }
        }
        let unique = Dictionary(journeys.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first }).values
        let eligible = unique.filter { journey in
            latestArrival.map { journey.arrival <= $0 } ?? true
        }
        let sorted = eligible.sorted { lhs, rhs in
            if latestArrival != nil { return lhs.arrival > rhs.arrival }
            return lhs.arrival < rhs.arrival
        }
        let best = Array(sorted.prefix(8))
        let transferIDs = Set(best.flatMap { [$0.transferStopID, $0.secondTransferStopID].compactMap { $0 } })
        let transferNames = await withTaskGroup(of: (String, String).self) { group in
            for stopID in transferIDs {
                group.addTask { (stopID, (try? await self.stopName(entity: entity, stopID: stopID)) ?? "Arrêt \(stopID)") }
            }
            var names: [String: String] = [:]
            for await (stopID, name) in group { names[stopID] = name }
            return names
        }
        let namedBest = best.map { journey in
            guard let stopID = journey.transferStopID else { return journey }
            return DeLijnJourney(id: journey.id, line: journey.line, destination: journey.destination, lineDirection: journey.lineDirection,
                departure: journey.departure, arrival: journey.arrival, delayMinutes: journey.delayMinutes,
                hasRealtimePrediction: journey.hasRealtimePrediction,
                transferStop: journey.transferStop?.hasPrefix("Marche ") == true ? journey.transferStop : transferNames[stopID] ?? journey.transferStop,
                transferStopID: stopID, transferArrival: journey.transferArrival,
                secondLine: journey.secondLine, secondLineDirection: journey.secondLineDirection, secondDeparture: journey.secondDeparture,
                secondTransferStop: journey.secondTransferStopID.flatMap { transferNames[$0] } ?? journey.secondTransferStop,
                secondTransferStopID: journey.secondTransferStopID, secondTransferArrival: journey.secondTransferArrival,
                thirdLine: journey.thirdLine, thirdLineDirection: journey.thirdLineDirection, thirdDeparture: journey.thirdDeparture,
                firstLegStopIDs: journey.firstLegStopIDs, secondLegStopIDs: journey.secondLegStopIDs,
                thirdLegStopIDs: journey.thirdLegStopIDs,
                firstLegEntityID: journey.firstLegEntityID ?? entity,
                secondLegEntityID: journey.secondLegEntityID ?? (journey.secondLine == nil ? nil : entity),
                thirdLegEntityID: journey.thirdLegEntityID ?? (journey.thirdLine == nil ? nil : entity),
                firstLegMode: journey.firstLegMode, secondLegMode: journey.secondLegMode, thirdLegMode: journey.thirdLegMode,
                firstBoardStopName: journey.firstBoardStopName, firstBoardStopID: journey.firstBoardStopID,
                secondBoardStopName: journey.secondBoardStopName, secondBoardStopID: journey.secondBoardStopID,
                thirdBoardStopName: journey.thirdBoardStopName, thirdBoardStopID: journey.thirdBoardStopID)
        }
        return await addingVehicleModes(to: namedBest, fallbackEntityID: entity)
    }

    private func addingVehicleModes(to journeys: [DeLijnJourney], fallbackEntityID: String) async -> [DeLijnJourney] {
        let keys = Set(journeys.flatMap { journey -> [String] in
            var result = ["\(journey.firstLegEntityID ?? fallbackEntityID)|\(journey.line)"]
            if let line = journey.secondLine {
                result.append("\(journey.secondLegEntityID ?? fallbackEntityID)|\(line)")
            }
            if let line = journey.thirdLine {
                result.append("\(journey.thirdLegEntityID ?? fallbackEntityID)|\(line)")
            }
            return result
        })
        let modes = await withTaskGroup(of: (String, String?).self) { group in
            for key in keys {
                let parts = key.split(separator: "|", maxSplits: 1).map(String.init)
                guard parts.count == 2 else { continue }
                group.addTask { (key, await self.vehicleMode(entityID: parts[0], lineNumber: parts[1])) }
            }
            var result: [String: String] = [:]
            for await (key, mode) in group {
                if let mode { result[key] = mode }
            }
            return result
        }
        return journeys.map { journey in
            var enriched = journey
            enriched.firstLegMode = modes["\(journey.firstLegEntityID ?? fallbackEntityID)|\(journey.line)"]
            if let line = journey.secondLine {
                enriched.secondLegMode = modes["\(journey.secondLegEntityID ?? fallbackEntityID)|\(line)"]
            }
            if let line = journey.thirdLine {
                enriched.thirdLegMode = modes["\(journey.thirdLegEntityID ?? fallbackEntityID)|\(line)"]
            }
            return enriched
        }
    }

    private func fetchSchedules(_ directions: [(String, String)], entity: String, serviceDay: Date) async throws -> [(String, String, [ScheduleTrip])] {
        let uniqueDirections = Array(Set(directions.map { "\($0.0)|\($0.1)" })).compactMap { value -> (String, String)? in
            let parts = value.split(separator: "|", omittingEmptySubsequences: false)
            guard parts.count == 2 else { return nil }
            return (String(parts[0]), String(parts[1]))
        }
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = TimeZone(identifier: "Europe/Brussels")
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateQuery = dateFormatter.string(from: serviceDay)
        return await withTaskGroup(of: (String, String, [ScheduleTrip]).self) { group in
            for (line, way) in uniqueDirections {
                group.addTask {
                    let url = URL(string: "https://api.delijn.be/DLKernOpenData/api/v1/lijnen/\(entity)/\(line)/lijnrichtingen/\(way)/dienstregelingen?datum=\(dateQuery)")!
                    guard let data = try? await self.get(url),
                          let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                        return (line, way, [])
                    }
                    let rawTrips = root["ritDoorkomsten"] as? [[String: Any]] ?? []
                    let trips = rawTrips.compactMap { raw -> ScheduleTrip? in
                        guard let number = raw["ritnummer"] as? String,
                              let rawStops = raw["doorkomsten"] as? [[String: Any]] else { return nil }
                        let stops = rawStops.compactMap { stop -> ScheduleStop? in
                            guard let id = stop["haltenummer"] as? String else { return nil }
                            let time = (stop["dienstregelingTijdstip"] as? String).flatMap(Self.parseDate)
                            return ScheduleStop(id: id, time: time)
                        }
                        return ScheduleTrip(number: number, line: line, destination: raw["bestemming"] as? String ?? "", stops: stops)
                    }
                    return (line, way, trips)
                }
            }
            var result: [(String, String, [ScheduleTrip])] = []
            for await item in group { result.append(item) }
            return result
        }
    }

    private func stopName(entity: String, stopID: String) async throws -> String {
        let url = URL(string: "https://api.delijn.be/DLKernOpenData/api/v1/haltes/\(entity)/\(stopID)")!
        let data = try await get(url)
        let root = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        return root?["omschrijvingLang"] as? String ?? root?["omschrijving"] as? String ?? "Arrêt \(stopID)"
    }

    private static func delay(for line: String, scheduledDeparture: Date, live: [DeLijnStopPassage]) -> (minutes: Int, hasPrediction: Bool) {
        let match = live.filter { $0.lineNumber == line && abs($0.scheduledTime.timeIntervalSince(scheduledDeparture)) <= 180 }
            .min { abs($0.scheduledTime.timeIntervalSince(scheduledDeparture)) < abs($1.scheduledTime.timeIntervalSince(scheduledDeparture)) }
        return (match.map { Int(($0.realtimeTime.timeIntervalSince($0.scheduledTime) / 60).rounded()) } ?? 0, match?.hasRealtimePrediction == true)
    }

    private func get(_ url: URL) async throws -> Data {
        let cacheKey = url.absoluteString
        let cacheLifetime: TimeInterval? = {
            if url.path.contains("/dienstregelingen") { return 1800 }
            if url.path.contains("/lijnrichtingen") || url.path.contains("/haltes/") { return 3600 }
            if url.path.contains("/lijnen/") { return 3600 }
            return nil
        }()
        if cacheLifetime != nil, let cached = cachedResponse(for: cacheKey) { return cached }
        var request = URLRequest(url: url)
        request.timeoutInterval = 10
        request.setValue(apiKey, forHTTPHeaderField: "Ocp-Apim-Subscription-Key")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw DeLijnError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw DeLijnError.http(http.statusCode) }
        if let cacheLifetime {
            storeResponse(data, for: cacheKey, lifetime: cacheLifetime)
        }
        return data
    }

    private func cachedNearbyStops(for key: String) -> [NearbyDeLijnStop]? {
        cacheLock.lock()
        defer { cacheLock.unlock() }
        guard let entry = nearbyStopCache[key], entry.expires > .now else { return nil }
        return entry.stops
    }

    private func storeNearbyStops(_ stops: [NearbyDeLijnStop], for key: String) {
        cacheLock.lock()
        nearbyStopCache[key] = (.now.addingTimeInterval(600), stops)
        cacheLock.unlock()
    }

    private func cachedResponse(for key: String) -> Data? {
        cacheLock.lock()
        defer { cacheLock.unlock() }
        guard let entry = responseCache[key], entry.expires > .now else { return nil }
        return entry.data
    }

    private func storeResponse(_ data: Data, for key: String, lifetime: TimeInterval) {
        cacheLock.lock()
        responseCache[key] = (.now.addingTimeInterval(lifetime), data)
        cacheLock.unlock()
    }
}

enum DeLijnError: LocalizedError, Sendable {
    case missingKey, badStopID, invalidResponse, timeout, http(Int)
    var errorDescription: String? {
        switch self {
        case .missingKey: return "Ajoute ta clé API De Lijn dans Profil."
        case .badStopID: return "Le numéro d’arrêt n’est pas valide."
        case .invalidResponse: return "Réponse invalide du service De Lijn."
        case .timeout: return "La recherche prend trop de temps. Réessaie dans un instant."
        case .http(let code): return "De Lijn a répondu avec l’erreur HTTP \(code)."
        }
    }
}
