import Foundation
import UserNotifications
#if canImport(AlarmKit)
import ActivityKit
import AlarmKit
import AppIntents
import SwiftUI
#endif

struct BusMindTransferReminder {
    let id: String
    let arrivalAtStop: Date
    let stopName: String
    let nextLine: String
    let nextDirection: String
    let nextDeparture: Date
}

final class AlarmScheduler: NSObject, UNUserNotificationCenterDelegate {
    static let shared = AlarmScheduler()
    private let alarmKitIDKey = "busmind-system-alarm-id"
    private let alarmKitTestIDKey = "busmind-system-alarm-test-id"
    private let wakeNotificationPrefix = "busmind-wake-"
    private let wakeTestNotificationID = "busmind-wake-test"
    private override init() { super.init() }

    static var supportsSystemAlarm: Bool {
#if canImport(AlarmKit)
        if #available(iOS 26.0, *) { return true }
#endif
        return false
    }

    static func snoozeMinutes(for difficulty: Int) -> Int {
        switch difficulty {
        case 0: return 9
        case 2...: return 2
        default: return 5
        }
    }

    func prepare() {
        UNUserNotificationCenter.current().delegate = self
    }

    func stopAlertingAlarmWhenAppOpens() async {
        let center = UNUserNotificationCenter.current()
        let pending = await center.pendingNotificationRequests()
        let wakeIDs = pending.map(\.identifier).filter {
            $0.hasPrefix(wakeNotificationPrefix) || $0 == wakeTestNotificationID
        }
        let delivered = await center.deliveredNotifications()
        let deliveredWakeIDs = delivered.map { $0.request.identifier }.filter {
            $0.hasPrefix(wakeNotificationPrefix) || $0 == wakeTestNotificationID
        }
        center.removePendingNotificationRequests(withIdentifiers: wakeIDs)
        center.removeDeliveredNotifications(withIdentifiers: deliveredWakeIDs)
#if canImport(AlarmKit)
        if #available(iOS 26.0, *) {
            let manager = AlarmManager.shared
            let ids = [alarmKitIDKey, alarmKitTestIDKey].compactMap { key in
                guard let value = UserDefaults.standard.string(forKey: key) else { return nil }
                return UUID(uuidString: value)
            }
            for id in ids {
                let isAlerting = (try? manager.alarms.contains { alarm in
                    alarm.id == id && alarm.state == .alerting
                }) ?? false
                if isAlerting { try? manager.stop(id: id) }
            }
        }
#endif
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification) async -> UNNotificationPresentationOptions {
        [.banner, .sound, .list]
    }

    func schedule(commuteHour: Int, commuteMinute: Int, minutesBefore: Int, difficulty: Int, weekdays: Set<Int>) async throws {
#if canImport(AlarmKit)
        if #available(iOS 26.0, *) {
            try await scheduleSystemAlarm(commuteHour: commuteHour, commuteMinute: commuteMinute,
                minutesBefore: minutesBefore, difficulty: difficulty, weekdays: weekdays, test: false)
            return
        }
#endif
        try await scheduleNotificationWake(commuteHour: commuteHour, commuteMinute: commuteMinute,
            minutesBefore: minutesBefore, weekdays: weekdays)
    }

    func cancel() async {
        let center = UNUserNotificationCenter.current()
        let pendingNotifications = await center.pendingNotificationRequests()
        let wakeIDs = pendingNotifications.map(\.identifier).filter {
            $0.hasPrefix(wakeNotificationPrefix) || $0 == wakeTestNotificationID
        }
        center.removePendingNotificationRequests(withIdentifiers: wakeIDs)
        center.removeDeliveredNotifications(withIdentifiers: wakeIDs)
#if canImport(AlarmKit)
        if #available(iOS 26.0, *) {
            let defaults = UserDefaults.standard
            for key in [alarmKitIDKey, alarmKitTestIDKey] {
                if let value = defaults.string(forKey: key), let id = UUID(uuidString: value) {
                    try? AlarmManager.shared.cancel(id: id)
                }
                defaults.removeObject(forKey: key)
            }
        }
#endif
    }

    func testNow() async throws {
#if canImport(AlarmKit)
        if #available(iOS 26.0, *) {
            try await scheduleSystemAlarm(commuteHour: 0, commuteMinute: 0, minutesBefore: 0,
                difficulty: 1, weekdays: [], test: true)
            return
        }
#endif
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        if settings.authorizationStatus == .notDetermined {
            let granted = try await center.requestAuthorization(options: [.alert, .sound, .badge])
            guard granted else { throw AlarmError.permissionDenied }
        } else if settings.authorizationStatus == .denied {
            throw AlarmError.permissionDenied
        }
        let pending = await center.pendingNotificationRequests().map(\.identifier).filter {
            $0.hasPrefix(wakeTestNotificationID)
        }
        let delivered = await center.deliveredNotifications().map { $0.request.identifier }.filter {
            $0.hasPrefix(wakeTestNotificationID)
        }
        center.removePendingNotificationRequests(withIdentifiers: pending)
        center.removeDeliveredNotifications(withIdentifiers: delivered)
        let regularRingCount = 20
        let escalationRingCount = 3
        let ringCount = regularRingCount + escalationRingCount
        for ring in 0..<ringCount {
            let offset = ring < regularRingCount ? 5 + ring * 5 : 105 + (ring - regularRingCount) * 32
            let fireDate = Date.now.addingTimeInterval(TimeInterval(offset))
            var components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: fireDate)
            components.calendar = Calendar.current
            let content = UNMutableNotificationContent()
            content.title = "MobiGo · Test du réveil"
            content.body = ring >= regularRingCount
                ? "Rappel long \(ring - regularRingCount + 1)/\(escalationRingCount) · ouvre MobiGo pour arrêter."
                : ring == 0 ? "20 rappels, puis 3 sons longs." : "Rappel \(ring + 1)/20 · ouvre MobiGo pour arrêter."
            content.sound = UNNotificationSound(named: UNNotificationSoundName(ring >= regularRingCount ? "BusMindWake.caf" : "BusMindWakeShort.caf"))
            content.interruptionLevel = .timeSensitive
            let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
            try await center.add(UNNotificationRequest(
                identifier: "\(wakeTestNotificationID)-\(ring)", content: content, trigger: trigger))
        }
    }

    private func scheduleNotificationWake(commuteHour: Int, commuteMinute: Int,
                                          minutesBefore: Int, weekdays: Set<Int>) async throws {
        guard !weekdays.isEmpty else { throw AlarmError.noWeekdaysSelected }
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        if settings.authorizationStatus == .notDetermined {
            let granted = try await center.requestAuthorization(options: [.alert, .sound, .badge])
            guard granted else { throw AlarmError.permissionDenied }
        } else if settings.authorizationStatus == .denied {
            throw AlarmError.permissionDenied
        }

        let oldRequests = await center.pendingNotificationRequests()
        let oldIDs = oldRequests.map(\.identifier).filter { $0.hasPrefix(wakeNotificationPrefix) }
        center.removePendingNotificationRequests(withIdentifiers: oldIDs)
        center.removeDeliveredNotifications(withIdentifiers: oldIDs)

        // iOS local notifications cannot loop one sound. Play twenty short alerts, then three
        // longer alerts with five seconds of silence between the long sounds.
        let alarmTotalMinutes = commuteHour * 60 + commuteMinute - minutesBefore
        let dayOffset = Int(floor(Double(alarmTotalMinutes) / 1440.0))
        let minuteOfDay = (alarmTotalMinutes % 1440 + 1440) % 1440
        let alarmWeekdays = Set(weekdays.map { day in ((day - 1 + dayOffset) % 7 + 7) % 7 + 1 })
        // Two mornings × 23 alerts stays below iOS's 64 pending notification limit.
        let calendar = Calendar.current
        var alarmDates: [Date] = []
        for offset in 0..<14 {
            guard let date = calendar.date(byAdding: .day, value: offset, to: calendar.startOfDay(for: .now)) else { continue }
            let weekday = calendar.component(.weekday, from: date)
            guard alarmWeekdays.contains(weekday),
                  let alarmDate = calendar.date(bySettingHour: minuteOfDay / 60, minute: minuteOfDay % 60,
                                                second: 0, of: date), alarmDate > .now else { continue }
            alarmDates.append(alarmDate)
            if alarmDates.count == 2 { break }
        }
        let regularRingCount = 20
        let escalationRingCount = 3
        let ringCount = regularRingCount + escalationRingCount
        for alarmDate in alarmDates {
            for ring in 0..<ringCount {
                let offset = ring < regularRingCount ? ring * 5 : 100 + (ring - regularRingCount) * 32
                let fireDate = alarmDate.addingTimeInterval(TimeInterval(offset))
                var components = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: fireDate)
                components.calendar = calendar
                let content = UNMutableNotificationContent()
                content.title = "MobiGo · Réveil"
                content.body = ring >= regularRingCount
                    ? "Rappel long \(ring - regularRingCount + 1)/\(escalationRingCount) · ouvre MobiGo pour arrêter."
                    : ring == 0
                        ? "C’est l’heure · bus à \(String(format: "%02d:%02d", commuteHour, commuteMinute))."
                        : "Rappel \(ring + 1)/20 · ouvre MobiGo pour arrêter."
                content.sound = UNNotificationSound(named: UNNotificationSoundName(ring >= regularRingCount ? "BusMindWake.caf" : "BusMindWakeShort.caf"))
                content.interruptionLevel = .timeSensitive
                let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
                let request = UNNotificationRequest(identifier: "\(wakeNotificationPrefix)\(Int(fireDate.timeIntervalSince1970))", content: content, trigger: trigger)
                try await center.add(request)
            }
        }
    }

    func scheduleTransferReminders(_ reminders: [BusMindTransferReminder]) async throws {
        let center = UNUserNotificationCenter.current()
        let pending = await center.pendingNotificationRequests()
        let oldIDs = pending.map(\.identifier).filter { $0.hasPrefix("busmind-transfer-") }
        center.removePendingNotificationRequests(withIdentifiers: oldIDs)
        center.removeDeliveredNotifications(withIdentifiers: oldIDs)
        guard !reminders.isEmpty else { return }

        let settings = await center.notificationSettings()
        if settings.authorizationStatus == .notDetermined {
            let granted = try await center.requestAuthorization(options: [.alert, .sound, .badge])
            guard granted else { throw AlarmError.permissionDenied }
        } else if settings.authorizationStatus == .denied {
            throw AlarmError.permissionDenied
        }
        for reminder in reminders {
            let alertDate = reminder.arrivalAtStop.addingTimeInterval(-2 * 60)
            guard alertDate > .now else { continue }
            let content = UNMutableNotificationContent()
            content.title = "MobiGo · Correspondance bientôt"
            content.body = "Dans environ 2 min : descends à \(reminder.stopName), puis bus \(reminder.nextLine) vers \(reminder.nextDirection) · départ prévu \(reminder.nextDeparture.formatted(date: .omitted, time: .shortened))."
            content.sound = .default
            content.interruptionLevel = .timeSensitive
            var components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: alertDate)
            components.calendar = Calendar.current
            let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
            try await center.add(UNNotificationRequest(identifier: "busmind-transfer-\(reminder.id)", content: content, trigger: trigger))
        }
    }

    func notifyTransferApproaching(stopName: String, nextLine: String, direction: String, departure: Date) async {
        let content = UNMutableNotificationContent()
        content.title = "MobiGo · Correspondance"
        content.body = "Tu approches de \(stopName). Prépare-toi pour le bus \(nextLine) vers \(direction), prévu à \(departure.formatted(date: .omitted, time: .shortened))."
        content.sound = .default
        content.interruptionLevel = .timeSensitive
        try? await UNUserNotificationCenter.current().add(
            UNNotificationRequest(identifier: "busmind-near-transfer-\(UUID().uuidString)", content: content, trigger: nil)
        )
    }

    func notifyTripArrived(destinationName: String) async {
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        if settings.authorizationStatus == .notDetermined {
            guard (try? await center.requestAuthorization(options: [.alert, .sound, .badge])) == true else { return }
        } else if settings.authorizationStatus == .denied {
            return
        }
        let content = UNMutableNotificationContent()
        content.title = "MobiGo · Bien arrivé·e 🎉"
        content.body = "Tu es près de \(destinationName). Le suivi du trajet est arrêté."
        content.sound = .default
        content.interruptionLevel = .timeSensitive
        try? await center.add(UNNotificationRequest(
            identifier: "busmind-arrival-\(UUID().uuidString)", content: content, trigger: nil))
    }

    func notifyServiceChange(line: String, direction: String, delayMinutes: Int, departure: Date) async {
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        if settings.authorizationStatus == .notDetermined {
            guard (try? await center.requestAuthorization(options: [.alert, .sound, .badge])) == true else { return }
        } else if settings.authorizationStatus == .denied { return }

        let isEarly = delayMinutes < -1
        let amount = abs(delayMinutes)
        let content = UNMutableNotificationContent()
        content.title = isEarly ? "MobiGo · transport en avance" : "MobiGo · retard détecté"
        content.body = "Bus \(line) → \(direction) · \(isEarly ? "\(amount) min plus tôt" : "+\(amount) min") · départ estimé \(departure.formatted(date: .omitted, time: .shortened))."
        content.sound = .default
        content.interruptionLevel = .timeSensitive
        try? await center.add(UNNotificationRequest(identifier: "busmind-live-change-\(UUID().uuidString)", content: content, trigger: nil))
    }

    func hasPendingAlarm() async -> Bool {
#if canImport(AlarmKit)
        if #available(iOS 26.0, *) {
            guard let value = UserDefaults.standard.string(forKey: alarmKitIDKey),
                  let id = UUID(uuidString: value) else { return false }
            return (try? AlarmManager.shared.alarms.contains { alarm in
                alarm.id == id && (alarm.state == .scheduled || alarm.state == .countdown
                    || alarm.state == .paused || alarm.state == .alerting)
            }) ?? false
        }
#endif
        let center = UNUserNotificationCenter.current()
        let pending = await center.pendingNotificationRequests().contains {
            $0.identifier.hasPrefix(wakeNotificationPrefix) && !$0.identifier.hasPrefix(wakeTestNotificationID)
        }
        if pending { return true }
        return await center.deliveredNotifications().contains {
            $0.request.identifier.hasPrefix(wakeNotificationPrefix)
                && !$0.request.identifier.hasPrefix(wakeTestNotificationID)
        }
    }

#if canImport(AlarmKit)
    @available(iOS 26.0, *)
    private func scheduleSystemAlarm(commuteHour: Int, commuteMinute: Int, minutesBefore: Int,
                                     difficulty: Int, weekdays: Set<Int>, test: Bool) async throws {
        let manager = AlarmManager.shared
        let authorization = try await manager.requestAuthorization()
        guard authorization == .authorized else { throw AlarmError.permissionDenied }

        let defaults = UserDefaults.standard
        let key = test ? alarmKitTestIDKey : alarmKitIDKey
        if let oldValue = defaults.string(forKey: key), let oldID = UUID(uuidString: oldValue) {
            try? manager.cancel(id: oldID)
        }

        let id = UUID()
        let schedule: Alarm.Schedule
        if test {
            schedule = .fixed(Date.now.addingTimeInterval(5))
        } else {
            guard !weekdays.isEmpty else { throw AlarmError.noWeekdaysSelected }
            let alarmTotalMinutes = commuteHour * 60 + commuteMinute - minutesBefore
            let dayOffset = Int(floor(Double(alarmTotalMinutes) / 1440.0))
            let minuteOfDay = (alarmTotalMinutes % 1440 + 1440) % 1440
            let alarmWeekdays = Set(weekdays.compactMap { commuteDay -> Locale.Weekday? in
                let adjustedDay = ((commuteDay - 1 + dayOffset) % 7 + 7) % 7 + 1
                return Self.localeWeekday(adjustedDay)
            })
            let time = Alarm.Schedule.Relative.Time(hour: minuteOfDay / 60, minute: minuteOfDay % 60)
            let recurrence = Alarm.Schedule.Relative.Recurrence.weekly(Array(alarmWeekdays))
            schedule = .relative(Alarm.Schedule.Relative(time: time, repeats: recurrence))
        }

        let snoozeMinutes = Self.snoozeMinutes(for: difficulty)
        let stopButton = AlarmButton(text: "Je suis réveillé", textColor: .white, systemImageName: "checkmark.circle.fill")
        let repeatButton = AlarmButton(text: "Répéter \(snoozeMinutes) min", textColor: .white, systemImageName: "repeat")
        let alert = AlarmPresentation.Alert(title: test ? "MobiGo · Test du réveil" : "MobiGo · Réveil",
            stopButton: stopButton, secondaryButton: repeatButton, secondaryButtonBehavior: .countdown)
        let countdown = AlarmPresentation.Countdown(
            title: "MobiGo · Réveil dans \(snoozeMinutes) min",
            pauseButton: nil)
        let attributes = AlarmAttributes<BusMindWakeMetadata>(
            presentation: AlarmPresentation(alert: alert, countdown: countdown),
            metadata: BusMindWakeMetadata(), tintColor: Color(red: 0.55, green: 0.24, blue: 0.97))
        let configuration = AlarmManager.AlarmConfiguration<BusMindWakeMetadata>(
            countdownDuration: Alarm.CountdownDuration(preAlert: nil, postAlert: TimeInterval(snoozeMinutes * 60)),
            schedule: schedule, attributes: attributes, stopIntent: OpenBusMindFromAlarmIntent(),
            secondaryIntent: nil, sound: AlertConfiguration.AlertSound.named("BusMindWake"))
        try await manager.schedule(id: id, configuration: configuration)
        defaults.set(id.uuidString, forKey: key)
    }

    @available(iOS 26.0, *)
    private static func localeWeekday(_ day: Int) -> Locale.Weekday? {
        switch day {
        case 1: return .sunday
        case 2: return .monday
        case 3: return .tuesday
        case 4: return .wednesday
        case 5: return .thursday
        case 6: return .friday
        case 7: return .saturday
        default: return nil
        }
    }
#endif
}

#if canImport(AlarmKit)
@available(iOS 26.0, *)
private struct OpenBusMindFromAlarmIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Je suis réveillé"
    static var description = IntentDescription("Arrête le réveil et ouvre MobiGo.")
    static let supportedModes: IntentModes = [.foreground(.immediate)]
    func perform() async throws -> some IntentResult { .result() }
}
#endif

enum AlarmError: LocalizedError {
    case permissionDenied, noWeekdaysSelected, systemAlarmUnavailable
    var errorDescription: String? {
        switch self {
        case .permissionDenied: return "Autorise les alarmes MobiGo dans Réglages pour programmer le réveil."
        case .noWeekdaysSelected: return "Choisis au moins un jour pour programmer le réveil."
        case .systemAlarmUnavailable: return "Cette version de MobiGo ne peut pas créer une vraie alarme sur cet appareil. Il faut iOS 26 et une version de Xcode compatible avec AlarmKit."
        }
    }
}
