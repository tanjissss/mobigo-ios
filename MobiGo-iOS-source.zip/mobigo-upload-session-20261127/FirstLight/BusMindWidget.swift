import SwiftUI
import WidgetKit
import AppIntents
#if canImport(AlarmKit)
import AlarmKit
import ActivityKit
#endif

struct BusMindEntry: TimelineEntry {
    let date: Date
    let departure: WidgetDeparture?
    let refreshedAt: Date
    let selectedStop: WidgetSavedStop?
}

struct BusMindProvider: AppIntentTimelineProvider {
    typealias Intent = MobiGoWidgetConfiguration

    func placeholder(in context: Context) -> BusMindEntry {
        BusMindEntry(date: .now, departure: nil, refreshedAt: .now, selectedStop: nil)
    }

    func snapshot(for configuration: MobiGoWidgetConfiguration, in context: Context) async -> BusMindEntry {
        let now = Date.now
        let stop = WidgetDataStore.savedWidgetStop(id: configuration.stop?.id)
        let cached = stop.map(WidgetDataStore.cachedDepartures(for:)) ?? WidgetDataStore.load()
        let nextDeparture = cached.filter { $0.time > now }.min { $0.time < $1.time }
        let refreshedAt = stop.flatMap(WidgetDataStore.lastUpdated(for:)) ?? WidgetDataStore.lastUpdated() ?? now
        return BusMindEntry(date: now, departure: nextDeparture, refreshedAt: refreshedAt, selectedStop: stop)
    }

    func timeline(for configuration: MobiGoWidgetConfiguration, in context: Context) async -> Timeline<BusMindEntry> {
        let now = Date()
        let stop = WidgetDataStore.savedWidgetStop(id: configuration.stop?.id)
        var departures = stop.map(WidgetDataStore.cachedDepartures(for:)) ?? WidgetDataStore.load()

        if let stop,
           let live = try? await TransitDataClient.departures(
                stopID: stop.stopID, entityID: stop.entityID, count: 20),
           !live.isEmpty {
            departures = live.map { WidgetDeparture(line: $0.lineNumber,
                destination: $0.destination, time: $0.realtimeTime, stop: stop.name,
                scheduledTime: $0.hasScheduledTime ? $0.scheduledTime : nil,
                vehicleMode: $0.vehicleMode,
                hasRealtimePrediction: $0.hasRealtimePrediction) }
            WidgetDataStore.save(departures, for: stop)
        }

        departures = departures.filter { $0.time > now }.sorted { $0.time < $1.time }
        let refreshedAt = stop.flatMap(WidgetDataStore.lastUpdated(for:)) ?? WidgetDataStore.lastUpdated() ?? now
        var entries = [BusMindEntry(date: now, departure: departures.first, refreshedAt: refreshedAt, selectedStop: stop)]
        for index in departures.indices {
            let nextIndex = index + 1
            let upcoming = nextIndex < departures.count ? departures[nextIndex] : nil
            entries.append(BusMindEntry(date: departures[index].time.addingTimeInterval(5),
                                        departure: upcoming, refreshedAt: refreshedAt, selectedStop: stop))
        }
        let staleAt = refreshedAt.addingTimeInterval(15 * 60)
        if staleAt > now {
            entries.append(BusMindEntry(date: staleAt,
                departure: departures.first(where: { $0.time > staleAt }), refreshedAt: refreshedAt,
                selectedStop: stop))
        }
        entries.sort { $0.date < $1.date }
        return Timeline(entries: entries, policy: .after(now.addingTimeInterval(15 * 60)))
    }
}

struct BusMindWidgetView: View {
    let entry: BusMindEntry
    @Environment(\.widgetFamily) private var family
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage(WidgetDataStore.themeKey, store: UserDefaults(suiteName: WidgetDataStore.suite))
    private var appTheme = "dark"
    private let purple = Color(red: 0.6745, green: 0.4824, blue: 1.0)
    private var background: Color {
        appTheme == "light"
            ? Color(red: 0.9569, green: 0.9647, blue: 0.9843)
            : Color(red: 0.0353, green: 0.0431, blue: 0.0863)
    }
    private var textColor: Color {
        appTheme == "light" ? Color(red: 0.0941, green: 0.1373, blue: 0.2314) : .white
    }
    private var mutedColor: Color {
        appTheme == "light" ? Color(red: 0.4118, green: 0.4588, blue: 0.549) : Color(red: 0.6039, green: 0.6471, blue: 0.7373)
    }
    private var accentColor: Color {
        appTheme == "light" ? Color(red: 0.098, green: 0.7216, blue: 0.9529) : purple
    }

    @ViewBuilder var body: some View {
        let renderedWidget = Group {
            switch family {
            case .accessoryInline: lockScreenInline
            case .accessoryCircular: lockScreenCircular
            case .accessoryRectangular: lockScreenRectangular
            default: widgetContent
            }
        }
        if #available(iOSApplicationExtension 17.0, *) {
            renderedWidget
                .containerBackground(for: .widget) {
                    isLockScreenFamily ? Color.clear : background
                }
                .widgetURL(URL(string: "busmind://open"))
        } else {
            renderedWidget
                .background(isLockScreenFamily ? Color.clear : background)
                .widgetURL(URL(string: "busmind://open"))
        }
    }

    private var isLockScreenFamily: Bool {
        switch family {
        case .accessoryInline, .accessoryCircular, .accessoryRectangular: return true
        default: return false
        }
    }

    @ViewBuilder private var lockScreenInline: some View {
        if let departure = entry.departure {
            Text("\(vehicleEmoji(departure.vehicleMode)) \(departure.line) · \(departure.time, style: .time) · \(compactStatusText(for: departure))")
                .accessibilityLabel(accessibleDepartureLabel(for: departure))
        } else {
            if let stop = entry.selectedStop {
                Label("\(stop.name) · aucun départ", systemImage: "clock")
            } else {
                Label("MobiGo · choisis un arrêt", systemImage: "bus.fill")
            }
        }
    }

    @ViewBuilder private var lockScreenCircular: some View {
        if let departure = entry.departure {
            VStack(spacing: 1) {
                Text(departure.line).font(.system(.caption2, design: .rounded, weight: .bold))
                    .foregroundStyle(lineColor(for: departure)).lineLimit(1)
                Text(departure.time, style: .time).font(.system(size: 8, weight: .semibold, design: .rounded))
                    .monospacedDigit().lineLimit(1).minimumScaleFactor(0.7)
                    .contentTransition(reduceMotion ? .identity : .numericText())
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(accessibleDepartureLabel(for: departure))
        } else {
            Image(systemName: entry.selectedStop == nil ? "bus.fill" : "clock")
        }
    }

    @ViewBuilder private var lockScreenRectangular: some View {
        if let departure = entry.departure {
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 4) {
                    Text(vehicleEmoji(departure.vehicleMode))
                    Text(departure.line).foregroundStyle(lineColor(for: departure)).fontWeight(.heavy)
                    Text("→ \(departure.destination)").fontWeight(.semibold)
                }
                .font(.system(size: 11, weight: .bold)).lineLimit(1).minimumScaleFactor(0.7)
                Text(departure.time, style: .timer)
                    .font(.system(size: 13, weight: .bold, design: .rounded)).monospacedDigit()
                    .lineLimit(1).minimumScaleFactor(0.65)
                    .contentTransition(reduceMotion ? .identity : .numericText())
                HStack(spacing: 3) {
                    Text("Départ \(departure.time, style: .time)")
                    Text("· \(departure.stop)")
                }
                .font(.system(size: 9, weight: .medium)).lineLimit(1).minimumScaleFactor(0.65)
                statusBadge(for: departure, compact: true)
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(accessibleDepartureLabel(for: departure))
        } else {
            if let stop = entry.selectedStop {
                Label("\(stop.name) · aucun départ", systemImage: "clock")
                    .font(.system(size: 11, weight: .semibold))
            } else {
                Label("MobiGo · choisis un arrêt", systemImage: "bus.fill")
                    .font(.system(size: 11, weight: .semibold))
            }
        }
    }

    @ViewBuilder private var widgetContent: some View {
        let small = family == .systemSmall
        let stopName = entry.selectedStop?.name ?? entry.departure?.stop ?? "Arrêt à choisir"
        let content = VStack(alignment: .leading, spacing: small ? 9 : 12) {
            HStack(spacing: 8) {
                Image(systemName: vehicleIcon(entry.departure?.vehicleMode))
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(entry.departure.map { lineForeground(for: $0) } ?? .white)
                    .frame(width: 28, height: 28)
                    .background((entry.departure.map { lineColor(for: $0) } ?? accentColor).gradient,
                                in: RoundedRectangle(cornerRadius: 9))
                VStack(alignment: .leading, spacing: 2) {
                    Text("PROCHAIN PASSAGE")
                        .font(.system(size: small ? 8 : 9, weight: .heavy)).tracking(0.5)
                        .foregroundStyle(mutedColor).lineLimit(1)
                    Text(stopName).font(.system(size: small ? 10 : 11, weight: .bold))
                        .foregroundStyle(textColor).lineLimit(1).minimumScaleFactor(0.75)
                }
                Spacer(minLength: 0)
                Image(systemName: "arrow.up.right").font(.system(size: 9, weight: .bold)).foregroundStyle(mutedColor)
            }

            if let departure = entry.departure {
                HStack(alignment: .center, spacing: small ? 7 : 11) {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack(spacing: 5) {
                            Image(systemName: vehicleIcon(departure.vehicleMode))
                                .font(.system(size: 10, weight: .bold))
                            Text(departure.line).font(.system(size: small ? 12 : 14, weight: .heavy, design: .rounded))
                                .lineLimit(1).minimumScaleFactor(0.7)
                        }
                        .foregroundStyle(lineForeground(for: departure))
                        .padding(.horizontal, small ? 8 : 10).padding(.vertical, small ? 6 : 7)
                        .background(lineColor(for: departure), in: RoundedRectangle(cornerRadius: 9))
                        Text("vers \(departure.destination)")
                            .font(.system(size: small ? 10 : 12, weight: .semibold))
                            .foregroundStyle(textColor).lineLimit(2).minimumScaleFactor(0.75)
                            .fixedSize(horizontal: false, vertical: true).layoutPriority(1)
                    }

                    Spacer(minLength: 0)

                    VStack(alignment: .trailing, spacing: 4) {
                        Text(departure.time, style: .time)
                            .font(.system(size: small ? 23 : 30, weight: .heavy, design: .rounded))
                            .monospacedDigit().foregroundStyle(textColor).lineLimit(1).minimumScaleFactor(0.7)
                            .contentTransition(reduceMotion ? .identity : .numericText())
                            .animation(reduceMotion ? nil : .easeOut(duration: 0.22), value: departure.time)
                        Text(departure.time, style: .relative)
                            .font(.system(size: small ? 9 : 10, weight: .bold))
                            .foregroundStyle(mutedColor).lineLimit(1)
                            .contentTransition(reduceMotion ? .identity : .numericText())
                        statusBadge(for: departure)
                    }
                }

                HStack(spacing: 5) {
                    Image(systemName: "arrow.clockwise")
                    Text("MAJ \(entry.refreshedAt, style: .time)")
                }
                .font(.system(size: 7, weight: .bold)).tracking(0.2)
                .foregroundStyle(mutedColor).lineLimit(1)
            } else {
                Spacer(minLength: 3)
                Label(entry.selectedStop.map { "Aucun départ · \($0.name)" } ?? "Choisis un arrêt",
                      systemImage: entry.selectedStop == nil ? "bus.fill" : "clock")
                    .font(.system(size: 11, weight: .semibold)).foregroundStyle(mutedColor)
                    .lineLimit(2).minimumScaleFactor(0.8)
                Spacer(minLength: 3)
            }
        }
        content.foregroundStyle(textColor).padding(small ? 12 : 15)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(entry.departure.map(accessibleDepartureLabel(for:))
                ?? emptyStateAccessibilityLabel(for: stopName))
            .accessibilityHint("Ouvre MobiGo pour le détail des départs.")
    }

    private func accessibleDepartureLabel(for departure: WidgetDeparture) -> String {
        let mode: String
        switch (departure.vehicleMode ?? "").uppercased() {
        case "BUS", "BUS_SERVICE", "BUSSERVICE": mode = "Bus"
        case "TRAM", "TRAMWAY": mode = "Tram"
        case "SUBWAY", "METRO", "METRO_SERVICE": mode = "Métro"
        case "RAIL", "TRAIN", "TRAIN_SERVICE": mode = "Train"
        default: mode = "Transport en commun"
        }
        return "Prochain départ, \(mode) ligne \(departure.line), direction \(departure.destination), à \(departure.time.formatted(date: .omitted, time: .shortened)), \(statusText(for: departure)), arrêt \(departure.stop)."
    }

    private func emptyStateAccessibilityLabel(for stopName: String) -> String {
        entry.selectedStop == nil ? "Choisis un arrêt dans les réglages du widget MobiGo." : "Aucun départ affiché pour l’arrêt \(stopName)."
    }

    private func delayMinutes(for departure: WidgetDeparture) -> Int? {
        guard let scheduled = departure.scheduledTime else { return nil }
        return Int((departure.time.timeIntervalSince(scheduled) / 60).rounded())
    }

    private func statusText(for departure: WidgetDeparture) -> String {
        guard departure.isRealtime else { return "Horaire prévu" }
        guard entry.date.timeIntervalSince(entry.refreshedAt) < 15 * 60 else { return "Données anciennes" }
        guard let delay = delayMinutes(for: departure) else { return "En direct" }
        if delay >= 2 { return "Retard +\(delay) min" }
        if delay <= -2 { return "En avance \(-delay) min" }
        return "À l’heure"
    }

    private func statusColor(for departure: WidgetDeparture) -> Color {
        guard departure.isRealtime else { return .orange }
        guard entry.date.timeIntervalSince(entry.refreshedAt) < 15 * 60 else { return .orange }
        if let delay = delayMinutes(for: departure), delay >= 2 { return .red }
        if let delay = delayMinutes(for: departure), delay <= -2 { return .blue }
        return .green
    }

    private func compactStatusText(for departure: WidgetDeparture) -> String {
        guard departure.isRealtime else { return "Horaire" }
        guard entry.date.timeIntervalSince(entry.refreshedAt) < 15 * 60 else { return "Données anciennes" }
        guard let delay = delayMinutes(for: departure) else { return "En direct" }
        if delay >= 2 { return "Retard +\(delay)m" }
        if delay <= -2 { return "Avance \(-delay)m" }
        return "À l’heure"
    }

    private func lineColor(for departure: WidgetDeparture) -> Color {
        let identity = "\(entry.selectedStop?.entityID ?? "2")-\((departure.vehicleMode ?? "UNKNOWN").uppercased())-\(departure.line.uppercased())"
        let hash = identity.unicodeScalars.reduce(UInt64(5381)) { ($0 &* 33) ^ UInt64($1.value) }
        return Color(hue: Double(hash % 360) / 360,
                     saturation: 0.78, brightness: appTheme == "light" ? 0.9 : 0.76)
    }

    private func lineForeground(for departure: WidgetDeparture) -> Color {
        let identity = "\(entry.selectedStop?.entityID ?? "2")-\((departure.vehicleMode ?? "UNKNOWN").uppercased())-\(departure.line.uppercased())"
        let hash = identity.unicodeScalars.reduce(UInt64(5381)) { ($0 &* 33) ^ UInt64($1.value) }
        let hue = Double(hash % 360) / 360 * 360
        let saturation = 0.78
        let brightness = appTheme == "light" ? 0.9 : 0.76
        let chroma = brightness * saturation
        let secondary = chroma * (1 - abs((hue / 60).truncatingRemainder(dividingBy: 2) - 1))
        let offset = brightness - chroma
        let rgb: (Double, Double, Double)
        switch hue {
        case 0..<60: rgb = (chroma, secondary, 0)
        case 60..<120: rgb = (secondary, chroma, 0)
        case 120..<180: rgb = (0, chroma, secondary)
        case 180..<240: rgb = (0, secondary, chroma)
        case 240..<300: rgb = (secondary, 0, chroma)
        default: rgb = (chroma, 0, secondary)
        }
        func linear(_ channel: Double) -> Double {
            let value = channel + offset
            return value <= 0.04045 ? value / 12.92 : pow((value + 0.055) / 1.055, 2.4)
        }
        let luminance = 0.2126 * linear(rgb.0) + 0.7152 * linear(rgb.1) + 0.0722 * linear(rgb.2)
        return (luminance + 0.05) / 0.05 >= 1.05 / (luminance + 0.05) ? .black : .white
    }

    @ViewBuilder
    private func statusBadge(for departure: WidgetDeparture, compact: Bool = false) -> some View {
        HStack(spacing: compact ? 3 : 4) {
            Image(systemName: statusSymbol(for: departure))
                .font(.system(size: compact ? 7 : 8, weight: .heavy))
            Text(statusText(for: departure, compact: compact))
                .font(.system(size: compact ? 8 : 9, weight: .bold)).lineLimit(1).minimumScaleFactor(0.7)
                .contentTransition(reduceMotion ? .identity : .opacity)
        }
        .foregroundStyle(statusColor(for: departure))
        .padding(.horizontal, compact ? 6 : 8).padding(.vertical, compact ? 3 : 5)
        .background(statusColor(for: departure).opacity(0.14), in: Capsule())
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: statusText(for: departure))
    }

    private func statusSymbol(for departure: WidgetDeparture) -> String {
        guard departure.isRealtime else { return "clock" }
        guard entry.date.timeIntervalSince(entry.refreshedAt) < 15 * 60 else { return "exclamationmark.triangle.fill" }
        guard let delay = delayMinutes(for: departure) else { return "dot.radiowaves.left.and.right" }
        if delay >= 2 { return "exclamationmark.circle.fill" }
        if delay <= -2 { return "arrow.up.circle.fill" }
        return "checkmark.circle.fill"
    }

    private func statusText(for departure: WidgetDeparture, compact: Bool = false) -> String {
        guard departure.isRealtime else { return compact ? "Horaire" : "Horaire prévu" }
        guard entry.date.timeIntervalSince(entry.refreshedAt) < 15 * 60 else { return compact ? "Ancien" : "Données anciennes" }
        guard let delay = delayMinutes(for: departure) else { return "En direct" }
        if delay >= 2 { return compact ? "Retard +\(delay)m" : "Retard +\(delay) min" }
        if delay <= -2 { return compact ? "Avance \(-delay)m" : "En avance \(-delay) min" }
        return "À l’heure"
    }

    private func vehicleIcon(_ mode: String?) -> String {
        switch (mode ?? "").trimmingCharacters(in: .whitespacesAndNewlines).uppercased() {
        case "TRAM", "TRAMWAY": return "tram.fill"
        case "SUBWAY", "METRO", "METRO_SERVICE": return "tram.tunnel.fill"
        case "RAIL", "TRAIN", "TRAIN_SERVICE": return "train.side.front.car"
        case "BUS", "BUS_SERVICE", "BUSSERVICE": return "bus.fill"
        default: return "arrow.triangle.swap"
        }
    }

    private func vehicleEmoji(_ mode: String?) -> String {
        switch (mode ?? "").trimmingCharacters(in: .whitespacesAndNewlines).uppercased() {
        case "TRAM", "TRAMWAY": return "🚊"
        case "SUBWAY", "METRO", "METRO_SERVICE": return "🚇"
        case "RAIL", "TRAIN", "TRAIN_SERVICE": return "🚆"
        case "BUS", "BUS_SERVICE", "BUSSERVICE": return "🚌"
        default: return "🚏"
        }
    }
}

struct BusMindWidget: Widget {
    // A new kind forces WidgetKit to register the MobiGo widget as a fresh
    // configuration instead of reusing the stale BusMind widget cache.
    let kind = "MobiGoStopDeparture"
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: kind, intent: MobiGoWidgetConfiguration.self, provider: BusMindProvider()) { entry in
            BusMindWidgetView(entry: entry)
        }
        .configurationDisplayName("MobiGo · Prochain passage")
        .description("Choisis l’arrêt à afficher. Chaque widget peut montrer un arrêt différent.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryInline, .accessoryCircular, .accessoryRectangular])
    }
}

#if canImport(AlarmKit)
@available(iOSApplicationExtension 26.0, *)
struct BusMindAlarmLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: AlarmAttributes<BusMindWakeMetadata>.self) { context in
            switch context.state.mode {
            case .countdown(let countdown):
                VStack(alignment: .leading, spacing: 8) {
                    Label("MobiGo · Répétition", systemImage: "alarm.fill")
                        .font(.headline).foregroundStyle(Color.purple)
                    Text(timerInterval: countdown.startDate...countdown.fireDate, countsDown: true)
                        .font(.system(size: 30, weight: .bold, design: .rounded)).monospacedDigit()
                    Text("Le réveil va ressonner").font(.caption).foregroundStyle(.secondary)
                }
                .padding()
                .activityBackgroundTint(Color(red: 0.0353, green: 0.0431, blue: 0.0863))
                .activitySystemActionForegroundColor(.white)
            case .paused:
                Label("Réveil en pause", systemImage: "pause.circle.fill")
                    .font(.headline).padding().activityBackgroundTint(Color(red: 0.0353, green: 0.0431, blue: 0.0863))
            case .alert:
                Label("MobiGo · Réveil", systemImage: "alarm.fill")
                    .font(.headline).padding().activityBackgroundTint(Color(red: 0.0353, green: 0.0431, blue: 0.0863))
            @unknown default:
                Label("MobiGo · Réveil", systemImage: "alarm.fill").padding()
            }
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Image(systemName: "alarm.fill").foregroundStyle(.purple)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    switch context.state.mode {
                    case .countdown(let countdown):
                        Text(timerInterval: countdown.startDate...countdown.fireDate, countsDown: true).monospacedDigit()
                    case .paused: Text("Pause")
                    case .alert: Text("Debout !")
                    @unknown default: Text("Réveil")
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text("MobiGo · ton réveil de trajet").font(.caption)
                }
            } compactLeading: {
                Image(systemName: "alarm.fill")
            } compactTrailing: {
                if case .countdown(let countdown) = context.state.mode {
                    Text(timerInterval: countdown.startDate...countdown.fireDate, countsDown: true).monospacedDigit()
                } else {
                    Text("⏰")
                }
            } minimal: {
                Image(systemName: "alarm.fill")
            }
            .keylineTint(.purple)
        }
    }
}
#endif

@main
struct BusMindWidgetBundle: WidgetBundle {
    var body: some Widget {
        BusMindWidget()
#if canImport(AlarmKit)
        if #available(iOSApplicationExtension 26.0, *) {
            BusMindAlarmLiveActivity()
        }
#endif
    }
}
