import Foundation
#if canImport(AppIntents)
import AppIntents
#endif
#if canImport(AlarmKit)
import AlarmKit

@available(iOS 26.0, *)
struct BusMindWakeMetadata: AlarmMetadata, Codable, Hashable {}
#endif

struct WidgetDeparture: Codable, Equatable {
    let line: String
    let destination: String
    let time: Date
    let stop: String
    var scheduledTime: Date? = nil
    var vehicleMode: String? = nil
    // Optional so cached widget entries created by older app versions still decode.
    var hasRealtimePrediction: Bool? = nil

    var isRealtime: Bool { hasRealtimePrediction == true }
}

struct WidgetSavedStop: Codable, Equatable, Identifiable, Hashable {
    let stopID: String
    let entityID: String
    let name: String
    let municipality: String

    var id: String { "\(entityID.lowercased())|\(stopID)" }
}

#if canImport(AppIntents)
@available(iOS 17.0, *)
struct WidgetStopEntity: AppEntity, Identifiable {
    let id: String
    let stopID: String
    let entityID: String
    let name: String
    let municipality: String

    static var typeDisplayRepresentation = TypeDisplayRepresentation(name: "Arrêt")
    static var defaultQuery = WidgetStopEntityQuery()

    var displayRepresentation: DisplayRepresentation {
        let subtitle = municipality.isEmpty ? networkName : "\(networkName) · \(municipality)"
        return DisplayRepresentation(title: "\(name)", subtitle: "\(subtitle)")
    }

    var savedStop: WidgetSavedStop {
        WidgetSavedStop(stopID: stopID, entityID: entityID, name: name, municipality: municipality)
    }

    var networkName: String {
        switch entityID.lowercased() {
        case "stib", "mivb": return "STIB"
        case "tec", "letec": return "TEC"
        case "nmbs", "sncb": return "SNCB"
        default: return "De Lijn"
        }
    }

    init(_ stop: WidgetSavedStop) {
        id = stop.id
        stopID = stop.stopID
        entityID = stop.entityID
        name = stop.name
        municipality = stop.municipality
    }
}

@available(iOS 17.0, *)
struct WidgetStopEntityQuery: EntityStringQuery {
    func entities(for identifiers: [String]) async throws -> [WidgetStopEntity] {
        return identifiers.compactMap { identifier in
            WidgetDataStore.widgetStop(id: identifier).map(WidgetStopEntity.init)
        }
    }

    func suggestedEntities() async throws -> [WidgetStopEntity] {
        WidgetDataStore.savedWidgetStops().map(WidgetStopEntity.init)
    }

    func entities(matching string: String) async throws -> [WidgetStopEntity] {
        let term = string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard term.count >= 2 else { return try await suggestedEntities() }

        async let deLijn = DeLijnClient.shared.searchStops(term)
        async let stib = StibClient.shared.searchStops(term)
        let matches = ((try? await deLijn) ?? []) + ((try? await stib) ?? [])
            + BelgianStopCatalog.searchStops(term)

        var seen = Set<String>()
        let saved = WidgetDataStore.savedWidgetStops()
        let results = matches.compactMap { feature -> WidgetSavedStop? in
            let stop = WidgetSavedStop(stopID: String(feature.properties.STOPID),
                entityID: feature.properties.ENTITEITNUMMER,
                name: feature.properties.NAAMHALTE,
                municipality: feature.properties.NAAMGEM)
            guard seen.insert(stop.id).inserted else { return nil }
            return stop
        }
        // Keep manually saved choices at the top, then allow searching the full
        // Belgian stop catalogue right in the Lock Screen widget editor.
        let ordered = saved + results.filter { candidate in
            !saved.contains(where: { $0.id == candidate.id })
        }
        WidgetDataStore.cacheWidgetStops(results)
        return Array(ordered.prefix(40)).map(WidgetStopEntity.init)
    }
}

@available(iOS 17.0, *)
struct MobiGoWidgetConfiguration: WidgetConfigurationIntent {
    static var title: LocalizedStringResource = "Arrêt du widget"
    static var description = IntentDescription("Choisis quel arrêt ce widget affiche.")

    @Parameter(title: "Arrêt") var stop: WidgetStopEntity?

    init() {}
}
#endif

enum WidgetDataStore {
    static let suite = "group.com.adam.busmind"
    static let itemsKey = "widgetDepartures"
    static let stopIDKey = "widgetStopID"
    static let entityIDKey = "widgetEntityID"
    static let stopNameKey = "widgetStopName"
    static let updatedAtKey = "widgetUpdatedAt"
    static let themeKey = "widgetAppTheme"
    static let savedStopsKey = "widgetSavedStops.v1"
    static let discoveredStopsKey = "widgetDiscoveredStops.v1"

    static func configure(stopID: String, entityID: String, stopName: String) {
        let defaults = UserDefaults(suiteName: suite)
        defaults?.set(stopID, forKey: stopIDKey)
        defaults?.set(entityID, forKey: entityIDKey)
        defaults?.set(stopName, forKey: stopNameKey)
        addWidgetStop(WidgetSavedStop(stopID: stopID, entityID: entityID, name: stopName, municipality: ""))
    }

    static func addWidgetStop(_ stop: WidgetSavedStop) {
        guard !stop.stopID.isEmpty, !stop.name.isEmpty,
              let defaults = UserDefaults(suiteName: suite) else { return }
        var stops = savedWidgetStops()
        if let index = stops.firstIndex(where: { $0.id == stop.id }) {
            let existing = stops[index]
            stops[index] = WidgetSavedStop(stopID: stop.stopID, entityID: stop.entityID,
                name: stop.name, municipality: stop.municipality.isEmpty ? existing.municipality : stop.municipality)
        } else {
            stops.append(stop)
        }
        if let data = try? JSONEncoder().encode(stops) { defaults.set(data, forKey: savedStopsKey) }
    }

    static func removeWidgetStop(id: String) {
        guard let defaults = UserDefaults(suiteName: suite) else { return }
        let stops = savedWidgetStops().filter { $0.id != id }
        if let data = try? JSONEncoder().encode(stops) { defaults.set(data, forKey: savedStopsKey) }
    }

    static func savedWidgetStops() -> [WidgetSavedStop] {
        guard let data = UserDefaults(suiteName: suite)?.data(forKey: savedStopsKey) else {
            if let stop = selectedStop() {
                return [WidgetSavedStop(stopID: stop.id, entityID: stop.entityID, name: stop.name, municipality: "")]
            }
            return []
        }
        return (try? JSONDecoder().decode([WidgetSavedStop].self, from: data)) ?? []
    }

    static func cacheWidgetStops(_ newStops: [WidgetSavedStop]) {
        guard let defaults = UserDefaults(suiteName: suite) else { return }
        let oldData = defaults.data(forKey: discoveredStopsKey)
        var discovered = oldData.flatMap { try? JSONDecoder().decode([WidgetSavedStop].self, from: $0) } ?? []
        for stop in newStops {
            if let index = discovered.firstIndex(where: { $0.id == stop.id }) {
                discovered[index] = stop
            } else {
                discovered.append(stop)
            }
        }
        if discovered.count > 300 { discovered.removeFirst(discovered.count - 300) }
        if let data = try? JSONEncoder().encode(discovered) { defaults.set(data, forKey: discoveredStopsKey) }
    }

    static func widgetStop(id: String) -> WidgetSavedStop? {
        if let saved = savedWidgetStops().first(where: { $0.id == id }) { return saved }
        guard let data = UserDefaults(suiteName: suite)?.data(forKey: discoveredStopsKey),
              let discovered = try? JSONDecoder().decode([WidgetSavedStop].self, from: data) else { return nil }
        return discovered.first(where: { $0.id == id })
    }

    static func savedWidgetStop(id: String?) -> WidgetSavedStop? {
        if let id { return widgetStop(id: id) }
        return selectedStop().map {
            WidgetSavedStop(stopID: $0.id, entityID: $0.entityID, name: $0.name, municipality: "")
        }
    }

    static func cachedDepartures(for stop: WidgetSavedStop) -> [WidgetDeparture] {
        let defaults = UserDefaults(suiteName: suite)
        let key = "\(itemsKey).\(stop.id)"
        guard let data = defaults?.data(forKey: key) else { return [] }
        return (try? JSONDecoder().decode([WidgetDeparture].self, from: data)) ?? []
    }

    static func lastUpdated(for stop: WidgetSavedStop) -> Date? {
        UserDefaults(suiteName: suite)?.object(forKey: "\(updatedAtKey).\(stop.id)") as? Date
    }

    static func save(_ items: [WidgetDeparture], for stop: WidgetSavedStop) {
        guard let data = try? JSONEncoder().encode(items),
              let defaults = UserDefaults(suiteName: suite) else { return }
        defaults.set(data, forKey: "\(itemsKey).\(stop.id)")
        defaults.set(Date(), forKey: "\(updatedAtKey).\(stop.id)")
        if selectedStop()?.id == stop.stopID, selectedStop()?.entityID == stop.entityID {
            defaults.set(data, forKey: itemsKey)
            defaults.set(Date(), forKey: updatedAtKey)
        }
    }

    static func selectedStop() -> (id: String, entityID: String, name: String)? {
        guard let defaults = UserDefaults(suiteName: suite),
              let id = defaults.string(forKey: stopIDKey), !id.isEmpty,
              let name = defaults.string(forKey: stopNameKey) else { return nil }
        return (id, defaults.string(forKey: entityIDKey) ?? "2", name)
    }

    static func save(_ items: [WidgetDeparture]) {
        let defaults = UserDefaults(suiteName: suite)
        if let data = try? JSONEncoder().encode(items) {
            let refreshedAt = Date()
            defaults?.set(data, forKey: itemsKey)
            defaults?.set(refreshedAt, forKey: updatedAtKey)
            if let current = selectedStop() {
                let stop = WidgetSavedStop(stopID: current.id, entityID: current.entityID,
                    name: current.name, municipality: "")
                defaults?.set(data, forKey: "\(itemsKey).\(stop.id)")
                defaults?.set(refreshedAt, forKey: "\(updatedAtKey).\(stop.id)")
            }
        } else {
            defaults?.removeObject(forKey: itemsKey)
            defaults?.removeObject(forKey: updatedAtKey)
        }
    }

    static func lastUpdated() -> Date? {
        UserDefaults(suiteName: suite)?.object(forKey: updatedAtKey) as? Date
    }

    static func saveTheme(_ theme: String) {
        UserDefaults(suiteName: suite)?.set(theme, forKey: themeKey)
    }

    static func loadTheme() -> String {
        UserDefaults(suiteName: suite)?.string(forKey: themeKey) ?? "dark"
    }

    static func load() -> [WidgetDeparture] {
        guard let data = UserDefaults(suiteName: suite)?.data(forKey: itemsKey) else { return [] }
        return (try? JSONDecoder().decode([WidgetDeparture].self, from: data)) ?? []
    }
}
