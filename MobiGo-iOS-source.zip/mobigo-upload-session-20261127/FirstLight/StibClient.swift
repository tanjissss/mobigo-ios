import Foundation
import Compression

private struct StibEnvelope: Decodable {
    let results: [StibRecord]
}

private struct StibRecord: Decodable {
    let id: String?
    let name: String?
    let gpscoordinates: String?
    let pointid: String?
    let lineid: String?
    let passingtimes: String?
}

private struct StibCoordinates: Decodable {
    let latitude: Double
    let longitude: Double
}

private struct StibLocalizedName: Decodable {
    let fr: String?
    let nl: String?
}

private struct StibWaitingTime: Decodable {
    let destination: StibLocalizedName?
    let expectedArrivalTime: String
    let lineId: String?
}

/// Belgian Mobility Company data for STIB-MIVB. This is deliberately separate
/// from De Lijn's API because the identifiers and response formats differ.
actor StibClient {
    static let shared = StibClient()
    private var stopsCache: (expires: Date, stops: [NearbyDeLijnStop])?

    private let baseURL = "https://api-management-discovery-production.azure-api.net/api/datasets/stibmivb"

    private init() {}

    func nearbyStops(latitude: Double, longitude: Double, limit: Int = 8,
                     radiusMeters: Int = 3000) async throws -> [NearbyDeLijnStop] {
        let stops = try await allStops()
        return Array(stops.compactMap { stop -> NearbyDeLijnStop? in
            let distance = Self.distanceMeters(latitude, longitude, stop.latitude, stop.longitude)
            guard distance <= Double(radiusMeters) else { return nil }
            return NearbyDeLijnStop(stop: stop.stop, latitude: stop.latitude,
                                    longitude: stop.longitude, distanceMeters: distance)
        }.sorted { $0.distanceMeters < $1.distanceMeters }.prefix(limit))
    }

    func searchStops(_ term: String, limit: Int = 30) async throws -> [StopFeature] {
        let normalizedTerm = Self.normalize(term)
        guard !normalizedTerm.isEmpty else { return [] }
        let stops = try await allStops()
        return Array(stops.map(\.stop).filter {
            Self.normalize($0.properties.NAAMHALTE).contains(normalizedTerm)
        }.prefix(limit))
    }

    func departures(stopID: String, count: Int = 8) async throws -> [DeLijnStopPassage] {
        let response = try await get("rt/WaitingTimes")
        let matching = response.results.filter { $0.pointid == stopID }
        let passages = matching.flatMap { record -> [DeLijnStopPassage] in
            guard let rawTimes = record.passingtimes,
                  let data = rawTimes.data(using: .utf8),
                  let times = try? JSONDecoder().decode([StibWaitingTime].self, from: data) else { return [] }
            return times.compactMap { value in
                guard let date = Self.parseDate(value.expectedArrivalTime), date >= .now.addingTimeInterval(-30) else { return nil }
                return DeLijnStopPassage(
                    id: "stib-\(stopID)-\(value.lineId ?? record.lineid ?? "")-\(date.timeIntervalSince1970)",
                    lineNumber: value.lineId ?? record.lineid ?? "?",
                    destination: value.destination?.fr ?? value.destination?.nl ?? "",
                    scheduledTime: date, realtimeTime: date, hasRealtimePrediction: true)
            }
        }
        let nextPassages = Array(passages.sorted { $0.realtimeTime < $1.realtimeTime }.prefix(count))
        var enriched: [DeLijnStopPassage] = []
        for passage in nextPassages {
            let metadata = await StibSchedulePlanner.shared.departureMetadata(
                stopID: stopID, lineNumber: passage.lineNumber, near: passage.realtimeTime)
            enriched.append(DeLijnStopPassage(
                id: passage.id, lineNumber: passage.lineNumber, destination: passage.destination,
                scheduledTime: metadata.scheduledTime ?? passage.scheduledTime,
                realtimeTime: passage.realtimeTime, hasRealtimePrediction: true,
                hasScheduledTime: metadata.scheduledTime != nil, vehicleMode: metadata.mode))
        }
        return enriched
    }

    private func allStops() async throws -> [NearbyDeLijnStop] {
        if let cache = stopsCache, cache.expires > .now { return cache.stops }

        let envelope = try await get("static/StopDetails")
        let stops: [NearbyDeLijnStop] = envelope.results.compactMap { record in
            guard let id = record.id, let rawName = record.name, let nameData = rawName.data(using: .utf8),
                  let localized = try? JSONDecoder().decode(StibLocalizedName.self, from: nameData),
                  let rawCoordinates = record.gpscoordinates, let coordinateData = rawCoordinates.data(using: .utf8),
                  let coordinates = try? JSONDecoder().decode(StibCoordinates.self, from: coordinateData) else { return nil }
            let name = localized.fr ?? localized.nl ?? "Arrêt STIB"
            let properties = StopProperties(ENTITEITNUMMER: "stib", STOPID: id,
                                            NAAMHALTE: name, NAAMGEM: "Bruxelles")
            let stop = StopFeature(id: "stib-\(id)", properties: properties)
            return NearbyDeLijnStop(stop: stop, latitude: coordinates.latitude,
                                    longitude: coordinates.longitude, distanceMeters: 0)
        }
        stopsCache = (Date.now.addingTimeInterval(6 * 60 * 60), stops)
        return stops
    }

    private func get(_ path: String) async throws -> StibEnvelope {
        guard !LocalSecrets.bmcAPIKey.isEmpty,
              let url = URL(string: "\(baseURL)/\(path)") else { throw DeLijnError.missingKey }
        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        request.setValue(LocalSecrets.bmcAPIKey, forHTTPHeaderField: "bmc-partner-key")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw DeLijnError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw DeLijnError.http(http.statusCode) }
        return try JSONDecoder().decode(StibEnvelope.self, from: data)
    }

    private static func parseDate(_ value: String) -> Date? {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = fractional.date(from: value) { return date }
        let standard = ISO8601DateFormatter()
        standard.formatOptions = [.withInternetDateTime]
        return standard.date(from: value)
    }

    private static func normalize(_ value: String) -> String {
        value.trimmingCharacters(in: .whitespacesAndNewlines)
            .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "fr_BE"))
    }

    private static func distanceMeters(_ latitude1: Double, _ longitude1: Double,
                                       _ latitude2: Double, _ longitude2: Double) -> Double {
        let radians = Double.pi / 180
        let dLat = (latitude2 - latitude1) * radians
        let dLon = (longitude2 - longitude1) * radians
        let a = sin(dLat / 2) * sin(dLat / 2)
            + cos(latitude1 * radians) * cos(latitude2 * radians)
                * sin(dLon / 2) * sin(dLon / 2)
        return 6_371_000 * 2 * atan2(sqrt(a), sqrt(1 - a))
    }
}

enum TransitDataClient {
    static func departures(stopID: String, entityID: String, count: Int = 8) async throws -> [DeLijnStopPassage] {
        switch entityID.lowercased() {
        case "stib":
            return try await StibClient.shared.departures(stopID: stopID, count: count)
        case "2":
            return try await DeLijnClient.shared.departures(stopID: stopID, entityID: entityID, count: count)
        case "tec", "letec", "nmbs", "sncb":
            return try await SiriRealtimeClient.shared.departures(
                stopID: stopID, entityID: entityID, count: count)
        default:
            return try await DeLijnClient.shared.departures(stopID: stopID, entityID: entityID, count: count)
        }
    }
}

private enum BelgianRealtimeError: LocalizedError {
    case unavailable(String)

    var errorDescription: String? {
        switch self {
        case .unavailable(let agency): return "Horaires \(agency) indisponibles pour le moment. Réessaie plus tard."
        }
    }
}

private struct BelgianRouteCatalog: Decodable {
    let routes: [String: BelgianRouteLabel]
}

private struct BelgianRouteLabel: Decodable {
    let shortName: String
    let longName: String
    let routeType: Int
}

private struct BelgianStopRows: Decodable {
    let tec: [BelgianStopRow]
    let nmbs: [BelgianStopRow]
}

private struct BelgianStopRow: Decodable {
    let stopID: String
    let name: String
    let latitude: Double
    let longitude: Double
    let parentID: String
    let locationType: Int
    let platform: String

    init(from decoder: Decoder) throws {
        var values = try decoder.unkeyedContainer()
        stopID = try values.decode(String.self)
        name = try values.decode(String.self)
        latitude = try values.decode(Double.self)
        longitude = try values.decode(Double.self)
        parentID = try values.decode(String.self)
        locationType = try values.decode(Int.self)
        platform = try values.decode(String.self)
    }
}

enum BelgianStopCatalog {
    private static let rows: BelgianStopRows? = loadRows()

    static func searchStops(_ term: String, limit: Int = 24) -> [StopFeature] {
        let query = term.trimmingCharacters(in: .whitespacesAndNewlines)
        guard query.count >= 2, let rows else { return [] }
        return (rows.tec.map { feature($0, agency: "tec") }
            + rows.nmbs.map { feature($0, agency: "nmbs") })
            .filter { $0.properties.NAAMHALTE.range(of: query,
                options: [.caseInsensitive, .diacriticInsensitive]) != nil }
            .prefix(limit).map { $0 }
    }

    static func nearbyStops(latitude: Double, longitude: Double, limitPerAgency: Int = 1,
                            radiusMeters: Double = 3_000) -> [NearbyDeLijnStop] {
        guard let rows else { return [] }
        let candidates = rows.tec.map { ($0, "tec") } + rows.nmbs.map { ($0, "nmbs") }
        return candidates.compactMap { row, agency -> NearbyDeLijnStop? in
            // GTFS parent stations are useful search results but are not boarding
            // points; use their individual platforms for walking and live boards.
            guard row.locationType == 0, !row.name.isEmpty else { return nil }
            let distance = distanceMeters(latitude, longitude, row.latitude, row.longitude)
            guard distance <= radiusMeters else { return nil }
            return NearbyDeLijnStop(stop: feature(row, agency: agency),
                latitude: row.latitude, longitude: row.longitude, distanceMeters: distance)
        }
        .sorted { $0.distanceMeters < $1.distanceMeters }
        .reduce(into: [NearbyDeLijnStop]()) { result, stop in
            let agency = stop.stop.properties.ENTITEITNUMMER
            guard result.filter({ $0.stop.properties.ENTITEITNUMMER == agency }).count < limitPerAgency else { return }
            result.append(stop)
        }
    }

    static func coordinate(stopID: String, entityID: String) -> (latitude: Double, longitude: Double)? {
        guard let rows else { return nil }
        let agency = normalizedAgency(entityID)
        let values = agency == "tec" ? rows.tec : agency == "nmbssncb" ? rows.nmbs : []
        guard let stop = values.first(where: { $0.stopID == cleanStopID(stopID, agency: agency) }) else { return nil }
        return (stop.latitude, stop.longitude)
    }

    static func stopName(stopID: String, entityID: String) -> String? {
        guard let rows else { return nil }
        let agency = normalizedAgency(entityID)
        let values = agency == "tec" ? rows.tec : agency == "nmbssncb" ? rows.nmbs : []
        let cleanedID = cleanStopID(stopID, agency: agency)
        return values.first(where: { cleanStopID($0.stopID, agency: agency) == cleanedID })?.name
    }

    static func boardingStopIDs(stopID: String, entityID: String) -> [String] {
        guard let rows else { return [stopID] }
        let agency = normalizedAgency(entityID)
        let values = agency == "tec" ? rows.tec : agency == "nmbssncb" ? rows.nmbs : []
        let cleanedID = cleanStopID(stopID, agency: agency)
        guard agency == "nmbssncb",
              let selected = values.first(where: { cleanStopID($0.stopID, agency: agency) == cleanedID }),
              !selected.parentID.isEmpty else { return [cleanedID] }
        let platforms = values.filter { $0.locationType == 0 && $0.parentID == selected.parentID }
            .map { cleanStopID($0.stopID, agency: agency) }
        return Array(Set(platforms + [cleanedID])).sorted()
    }

    private static func feature(_ row: BelgianStopRow, agency: String) -> StopFeature {
        let stopID = cleanStopID(row.stopID, agency: agency)
        let name = row.platform.isEmpty ? row.name : "\(row.name) · quai \(row.platform)"
        let label = agency == "tec" ? "TEC" : "SNCB"
        return StopFeature(id: "\(agency)-\(stopID)", properties: StopProperties(
            ENTITEITNUMMER: agency, STOPID: stopID,
            NAAMHALTE: name, NAAMGEM: label))
    }

    private static func loadRows() -> BelgianStopRows? {
        guard let url = Bundle.main.url(forResource: "BelgianStops", withExtension: "json.deflate"),
              let compressed = try? Data(contentsOf: url) else { return nil }
        let capacity = 16 * 1024 * 1024
        let destination = UnsafeMutablePointer<UInt8>.allocate(capacity: capacity)
        defer { destination.deallocate() }
        let decodedSize = compressed.withUnsafeBytes { source -> Int in
            guard let sourceBytes = source.bindMemory(to: UInt8.self).baseAddress else { return 0 }
            return compression_decode_buffer(destination, capacity, sourceBytes, compressed.count,
                                             nil, COMPRESSION_ZLIB)
        }
        guard decodedSize > 0 else { return nil }
        return try? JSONDecoder().decode(BelgianStopRows.self,
                                         from: Data(bytes: destination, count: decodedSize))
    }

    private static func normalizedAgency(_ value: String) -> String {
        switch value.lowercased() {
        case "tec", "letec": return "tec"
        case "nmbs", "sncb": return "nmbssncb"
        default: return value.lowercased()
        }
    }

    private static func cleanStopID(_ value: String, agency: String) -> String {
        let prefixes = ["gs:\(agency):", "gs_\(agency)_"]
        for prefix in prefixes where value.hasPrefix(prefix) { return String(value.dropFirst(prefix.count)) }
        return value
    }

    private static func distanceMeters(_ latitude1: Double, _ longitude1: Double,
                                       _ latitude2: Double, _ longitude2: Double) -> Double {
        let radians = Double.pi / 180
        let dLat = (latitude2 - latitude1) * radians
        let dLon = (longitude2 - longitude1) * radians
        let a = sin(dLat / 2) * sin(dLat / 2)
            + cos(latitude1 * radians) * cos(latitude2 * radians)
                * sin(dLon / 2) * sin(dLon / 2)
        return 6_371_000 * 2 * atan2(sqrt(a), sqrt(1 - a))
    }
}

private struct SIRIResponse: Decodable {
    let serviceDelivery: SIRIServiceDelivery?
    enum CodingKeys: String, CodingKey { case serviceDelivery = "ServiceDelivery" }
}

private struct SIRIServiceDelivery: Decodable {
    let deliveries: [SIRIETDelivery]?
    enum CodingKeys: String, CodingKey { case deliveries = "EstimatedTimetableDelivery" }
}

private struct SIRIETDelivery: Decodable {
    let frames: [SIRIJourneyFrame]?
    enum CodingKeys: String, CodingKey { case frames = "EstimatedJourneyVersionFrame" }
}

private struct SIRIJourneyFrame: Decodable {
    let journeys: [SIRIEstimatedJourney]?
    enum CodingKeys: String, CodingKey { case journeys = "EstimatedVehicleJourney" }
}

private struct SIRIEstimatedJourney: Decodable {
    let lineRef: String?
    let directionRef: String?
    let calls: [SIRIEstimatedCall]?
    enum CodingKeys: String, CodingKey {
        case lineRef = "LineRef"
        case directionRef = "DirectionRef"
        case calls = "EstimatedCalls"
    }
}

private struct SIRIEstimatedCall: Decodable {
    let stopPointRef: String?
    let stopPointName: String?
    let order: Int?
    let aimedDepartureTime: String?
    let expectedDepartureTime: String?
    let aimedArrivalTime: String?
    let expectedArrivalTime: String?
    let cancellation: SIRIBool?
    enum CodingKeys: String, CodingKey {
        case stopPointRef = "StopPointRef"
        case stopPointName = "StopPointName"
        case order = "Order"
        case aimedDepartureTime = "AimedDepartureTime"
        case expectedDepartureTime = "ExpectedDepartureTime"
        case aimedArrivalTime = "AimedArrivalTime"
        case expectedArrivalTime = "ExpectedArrivalTime"
        case cancellation = "Cancellation"
    }
}

private struct SIRIBool: Decodable {
    let value: Bool
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let value = try? container.decode(Bool.self) { self.value = value; return }
        if let value = try? container.decode(Int.self) { self.value = value != 0; return }
        if let value = try? container.decode(String.self) {
            self.value = ["true", "1", "yes"].contains(value.lowercased()); return
        }
        self.value = false
    }
}

private enum BelgianTransitRouteMap {
    static let routes: [String: BelgianRouteLabel] = {
        guard let url = Bundle.main.url(forResource: "BelgianRoutes", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let catalog = try? JSONDecoder().decode(BelgianRouteCatalog.self, from: data) else { return [:] }
        return catalog.routes
    }()
}

private struct GTFSRealtimeFeed: Decodable {
    let entity: [GTFSRealtimeEntity]?
}

private struct GTFSRealtimeEntity: Decodable {
    let id: String?
    let tripUpdate: GTFSRealtimeTripUpdate?
}

private struct GTFSRealtimeTripUpdate: Decodable {
    let trip: GTFSRealtimeTrip?
    let stopTimeUpdate: [GTFSRealtimeStopUpdate]?
}

private struct GTFSRealtimeTrip: Decodable {
    let tripId: String?
    let routeId: String?
    let scheduleRelationship: Int?
}

private struct GTFSRealtimeStopUpdate: Decodable {
    let stopId: String?
    let stopSequence: Int?
    let scheduleRelationship: Int?
    let arrival: GTFSRealtimeStopTime?
    let departure: GTFSRealtimeStopTime?
}

private struct GTFSRealtimeStopTime: Decodable {
    let time: Int64?
    let delay: Int?
}

actor SiriRealtimeClient {
    static let shared = SiriRealtimeClient()
    private var cachedPassages: [String: (expires: Date, passages: [DeLijnStopPassage])] = [:]
    private var cachedFeeds: [String: (expires: Date, feed: GTFSRealtimeFeed)] = [:]

    func departures(stopID: String, entityID: String, count: Int) async throws -> [DeLijnStopPassage] {
        let agency = ["tec", "letec"].contains(entityID.lowercased()) ? "tec" : "nmbssncb"
        let cacheKey = "\(agency)-\(stopID)"
        if let cached = cachedPassages[cacheKey], cached.expires > .now {
            return Array(cached.passages.prefix(count))
        }
        do {
            let live = try await gtfsRealtimeDepartures(stopID: stopID, agency: agency, count: count)
            if !live.isEmpty {
                cachedPassages[cacheKey] = (Date.now.addingTimeInterval(30), live)
                return Array(live.prefix(count))
            }
        } catch {
            // SIRI also carries the aimed timetable, so use it when the smaller
            // GTFS-RT trip-update feed is temporarily unavailable.
        }
        let passages = try await siriDepartures(stopID: stopID, agency: agency, count: count)
        cachedPassages[cacheKey] = (Date.now.addingTimeInterval(45), passages)
        return passages
    }

    private func gtfsRealtimeDepartures(stopID: String, agency: String, count: Int) async throws -> [DeLijnStopPassage] {
        let stopAgency = agency
        let feed: GTFSRealtimeFeed
        if let cached = cachedFeeds[agency], cached.expires > .now {
            feed = cached.feed
        } else {
            guard let url = URL(string: "https://api-management-discovery-production.azure-api.net/api/gtfs/feed/\(agency)/rt/trip-update?format=json") else {
                throw DeLijnError.invalidResponse
            }
            var request = URLRequest(url: url)
            request.timeoutInterval = 18
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue(LocalSecrets.bmcAPIKey, forHTTPHeaderField: "bmc-partner-key")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else { throw DeLijnError.invalidResponse }
            guard (200..<300).contains(http.statusCode) else { throw DeLijnError.http(http.statusCode) }
            feed = try JSONDecoder().decode(GTFSRealtimeFeed.self, from: data)
            cachedFeeds[agency] = (Date.now.addingTimeInterval(30), feed)
        }
        let targetStopID = cleanStopID(stopID, agency: stopAgency)
        let targetRefs = Set(BelgianStopCatalog.boardingStopIDs(stopID: targetStopID, entityID: stopAgency)
            .flatMap { ["gs:\(stopAgency):\($0)", "gs_\(stopAgency)_\($0)"] })
        let now = Date.now.addingTimeInterval(-30)
        var passages: [DeLijnStopPassage] = []

        for entity in feed.entity ?? [] {
            guard let update = entity.tripUpdate, let trip = update.trip,
                  trip.scheduleRelationship != 3 else { continue }
            let updates = (update.stopTimeUpdate ?? []).sorted {
                ($0.stopSequence ?? Int.max) < ($1.stopSequence ?? Int.max)
            }
            guard let index = updates.firstIndex(where: { update in
                guard let stopID = update.stopId else { return false }
                return targetRefs.contains(stopID)
            }) else {
                continue
            }
            let current = updates[index]
            guard current.scheduleRelationship != 1 else { continue }
            let event = current.departure ?? current.arrival
            guard let timestamp = event?.time else { continue }
            let time = Date(timeIntervalSince1970: TimeInterval(timestamp))
            guard time >= now else { continue }

            let finalStopName = updates.reversed().compactMap { stop -> String? in
                guard let finalStopID = stop.stopId else { return nil }
                return BelgianStopCatalog.stopName(stopID: finalStopID, entityID: agency)
            }.first
            let endStopName = tripEndStopName(trip.tripId, agency: agency)
            let destination = endStopName ?? finalStopName ?? (agency == "tec" ? "Réseau TEC" : "Destination SNCB")
            let routeKey = (trip.routeId ?? "").replacingOccurrences(of: ":", with: "_")
                .replacingOccurrences(of: "-", with: "_")
            let route = BelgianTransitRouteMap.routes[routeKey]
            let trainNumber = trip.tripId?.split(separator: ":")
                .map(String.init).last(where: { $0.count == 4 && $0.allSatisfy(\.isNumber) })
            let line = route?.shortName ?? trainNumber ?? (agency == "tec" ? "TEC" : "Train")
            let mode: String
            switch route?.routeType {
            case 0: mode = "TRAM"
            case 1: mode = "SUBWAY"
            case 2: mode = "RAIL"
            default: mode = agency == "nmbssncb" ? "RAIL" : "BUS"
            }
            let id = "gtfsrt-\(agency)-\(targetStopID)-\(trip.tripId ?? entity.id ?? UUID().uuidString)-\(timestamp)"
            passages.append(DeLijnStopPassage(id: id, lineNumber: line, destination: destination,
                scheduledTime: time, realtimeTime: time, hasRealtimePrediction: true,
                hasScheduledTime: false, vehicleMode: mode))
        }
        return Array(passages.sorted { $0.realtimeTime < $1.realtimeTime }.prefix(max(count, 20)))
    }

    private func siriDepartures(stopID: String, agency: String, count: Int) async throws -> [DeLijnStopPassage] {
        let stopAgency = agency
        guard let url = URL(string: "https://api-management-discovery-production.azure-api.net/api/siri/feed/\(agency)/estimated-timetable?format=json") else {
            throw DeLijnError.invalidResponse
        }
        var request = URLRequest(url: url)
        request.timeoutInterval = 35
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(LocalSecrets.bmcAPIKey, forHTTPHeaderField: "bmc-partner-key")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode),
              http.mimeType?.localizedCaseInsensitiveContains("json") == true else {
            throw BelgianRealtimeError.unavailable(agency == "tec" ? "TEC" : "SNCB")
        }
        let feed: SIRIResponse
        do {
            feed = try JSONDecoder().decode(SIRIResponse.self, from: data)
        } catch {
            throw BelgianRealtimeError.unavailable(agency == "tec" ? "TEC" : "SNCB")
        }
        let targetStopID = cleanStopID(stopID, agency: stopAgency)
        let targetRefs = Set(BelgianStopCatalog.boardingStopIDs(stopID: targetStopID, entityID: stopAgency)
            .flatMap { ["gs_\(stopAgency)_\($0)", "gs:\(stopAgency):\($0)"] })
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let standardFormatter = ISO8601DateFormatter()
        standardFormatter.formatOptions = [.withInternetDateTime]
        func parsed(_ value: String?) -> Date? {
            guard let value else { return nil }
            return formatter.date(from: value) ?? standardFormatter.date(from: value)
        }

        var passages: [DeLijnStopPassage] = []
        for journey in feed.serviceDelivery?.deliveries?.flatMap({ $0.frames ?? [] })
            .flatMap({ $0.journeys ?? [] }) ?? [] {
            guard let calls = journey.calls, !calls.isEmpty else { continue }
            guard let callIndex = calls.firstIndex(where: { call in
                guard let ref = call.stopPointRef else { return false }
                let normalized = ref.replacingOccurrences(of: "BE:BMC:ScheduledStopPoint:", with: "")
                    .trimmingCharacters(in: CharacterSet(charactersIn: ":"))
                return targetRefs.contains(normalized) || targetRefs.contains(normalized.replacingOccurrences(of: ":", with: "_"))
            }) else { continue }
            let call = calls[callIndex]
            if call.cancellation?.value == true { continue }
            let scheduled = parsed(call.aimedDepartureTime) ?? parsed(call.aimedArrivalTime)
            let prediction = parsed(call.expectedDepartureTime) ?? parsed(call.expectedArrivalTime)
            guard let time = prediction ?? scheduled, time >= .now.addingTimeInterval(-30) else { continue }

            let key = (journey.lineRef ?? "").replacingOccurrences(of: "BE:BMC:Line:", with: "")
                .trimmingCharacters(in: CharacterSet(charactersIn: ":"))
            let route = BelgianTransitRouteMap.routes[key]
            let line = route?.shortName.isEmpty == false ? route!.shortName : (agency == "tec" ? "TEC" : "SNCB")
            let destination = calls.dropFirst(callIndex + 1).reversed()
                .compactMap(\.stopPointName).first(where: { !$0.isEmpty })
                ?? directionName(journey.directionRef) ?? (agency == "tec" ? "Réseau TEC" : "Réseau SNCB")
            let mode: String
            switch route?.routeType {
            case 0: mode = "TRAM"
            case 1: mode = "SUBWAY"
            case 2: mode = "RAIL"
            default: mode = agency == "nmbssncb" ? "RAIL" : "BUS"
            }
            let id = "siri-\(agency)-\(targetStopID)-\(key)-\(Int(time.timeIntervalSince1970))-\(call.order ?? 0)"
            passages.append(DeLijnStopPassage(id: id, lineNumber: line, destination: destination,
                scheduledTime: scheduled ?? time, realtimeTime: time,
                hasRealtimePrediction: prediction != nil, hasScheduledTime: scheduled != nil,
                vehicleMode: mode))
        }
        return Array(passages.sorted { $0.realtimeTime < $1.realtimeTime }.prefix(max(count, 20)))
    }

    private func tripEndStopName(_ tripID: String?, agency: String) -> String? {
        guard let tripID else { return nil }
        let stationIDs = tripID.split(separator: ":").map(String.init)
            .filter { $0.count == 7 && $0.allSatisfy(\.isNumber) }
        guard stationIDs.count >= 2 else { return nil }
        // A trip ID carries its origin and terminal station; the terminal
        // remains the direction for any intermediate boarding stop.
        let destinationID = stationIDs.last!
        return BelgianStopCatalog.stopName(stopID: destinationID, entityID: agency)
    }

    private func cleanStopID(_ value: String, agency: String) -> String {
        for prefix in ["gs:\(agency):", "gs_\(agency)_"] where value.hasPrefix(prefix) {
            return String(value.dropFirst(prefix.count))
        }
        return value
    }

    private func directionName(_ value: String?) -> String? {
        guard let value else { return nil }
        let trimmed = value.trimmingCharacters(in: CharacterSet(charactersIn: ":"))
        guard let last = trimmed.split(separator: ":").last.map(String.init),
              !last.isEmpty, Int(last) == nil else { return nil }
        return last.replacingOccurrences(of: "_", with: " ")
    }
}

struct BelgianUnifiedJourney: Sendable {
    let journey: DeLijnJourney
    let origin: StopFeature
    let destination: StopFeature
    let originLatitude: Double
    let originLongitude: Double
    let destinationLatitude: Double
    let destinationLongitude: Double
    let originWalkMinutes: Int
    let destinationWalkMinutes: Int
}

private struct BelgianPlannerResponse: Decodable {
    let plan: BelgianPlannerPlan?
}

private struct BelgianPlannerPlan: Decodable {
    let itineraries: [BelgianPlannerItinerary]?
}

private struct BelgianPlannerItinerary: Decodable {
    let startTime: Double?
    let endTime: Double?
    let legs: [BelgianPlannerLeg]?
}

private struct BelgianPlannerLeg: Decodable {
    let startTime: Double?
    let endTime: Double?
    let departureDelay: Double?
    let arrivalDelay: Double?
    let realTime: Bool?
    let mode: String?
    let route: String?
    let routeShortName: String?
    let agencyId: String?
    let headsign: String?
    let from: BelgianPlannerStop?
    let to: BelgianPlannerStop?
    let intermediateStops: [BelgianPlannerStop]?
}

private struct BelgianPlannerStop: Decodable {
    let name: String?
    let stopId: String?
    let stopCode: String?
    let lat: Double?
    let lon: Double?
}

enum BelgianTransitPlanner {
    private static let endpoint = URL(string:
        "https://trip-planner.api.production.belgianmobility.io/planner-multiengine/recipe/main")!

    static func plan(from origin: (latitude: Double, longitude: Double),
                     to destination: (latitude: Double, longitude: Double),
                     originName: String, destinationName: String,
                     arrivingBy target: Date, onlySTIB: Bool = false,
                     networkFilter: String? = nil,
                     allowedNetworks: Set<String>? = nil,
                     allowedModes: Set<String>? = nil) async throws -> [BelgianUnifiedJourney] {
        var components = URLComponents(url: endpoint, resolvingAgainstBaseURL: false)!
        let calendar = brusselsCalendar
        let apiDateFormatter = DateFormatter()
        apiDateFormatter.locale = Locale(identifier: "en_US_POSIX")
        apiDateFormatter.timeZone = calendar.timeZone
        apiDateFormatter.dateFormat = "yyyy-MM-dd"
        let apiTimeFormatter = DateFormatter()
        apiTimeFormatter.locale = Locale(identifier: "en_US_POSIX")
        apiTimeFormatter.timeZone = calendar.timeZone
        apiTimeFormatter.dateFormat = "HH:mm"
        components.queryItems = [
            URLQueryItem(name: "fromPlace", value: "\(origin.latitude),\(origin.longitude)"),
            URLQueryItem(name: "toPlace", value: "\(destination.latitude),\(destination.longitude)"),
            URLQueryItem(name: "fromName", value: originName),
            URLQueryItem(name: "toName", value: destinationName),
            URLQueryItem(name: "date", value: apiDateFormatter.string(from: target)),
            URLQueryItem(name: "time", value: apiTimeFormatter.string(from: target)),
            URLQueryItem(name: "arriveBy", value: "true"),
            // Keep the planner intermodal: it can return a single journey
            // combining De Lijn, STIB, TEC and SNCB (including walking legs).
            URLQueryItem(name: "mode", value: (allowedModes ?? ["BUS", "TRAM", "SUBWAY", "RAIL"])
                .sorted().joined(separator: ",") + ",WALK"),
            URLQueryItem(name: "numItineraries", value: onlySTIB || networkFilter != nil || allowedNetworks != nil ? "20" : "8"),
            URLQueryItem(name: "maxWalkDistance", value: "3000"),
            URLQueryItem(name: "showIntermediateStops", value: "true")
        ]
        guard let url = components.url else { throw DeLijnError.invalidResponse }
        var request = URLRequest(url: url)
        request.timeoutInterval = 35
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("BusMind iOS", forHTTPHeaderField: "User-Agent")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw DeLijnError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw DeLijnError.http(http.statusCode) }
        let responseBody = try JSONDecoder().decode(BelgianPlannerResponse.self, from: data)
        let candidates = (responseBody.plan?.itineraries ?? []).filter { itinerary in
            let rides = (itinerary.legs ?? []).filter {
                ["BUS", "TRAM", "SUBWAY", "RAIL", "TRAIN"].contains(($0.mode ?? "").uppercased())
            }
            let agencies = rides.compactMap(\.agencyId)
            guard !agencies.isEmpty else { return false }
            if let allowedModes, !rides.allSatisfy({ allowedModes.contains(normalizedTransitMode($0.mode)) }) { return false }
            if onlySTIB && !agencies.allSatisfy(isSTIBAgency) { return false }
            if let networkFilter, !agencies.allSatisfy({ isAgency($0, in: networkFilter) }) { return false }
            if let allowedNetworks, !agencies.allSatisfy({ allowedNetworks.contains(networkKey(for: $0)) }) { return false }
            return true
        }.compactMap(makeJourney)
        return candidates.sorted {
            if $0.journey.departure != $1.journey.departure {
                return $0.journey.departure > $1.journey.departure
            }
            return $0.journey.arrival < $1.journey.arrival
        }
    }

    private static func makeJourney(_ itinerary: BelgianPlannerItinerary) -> BelgianUnifiedJourney? {
        let allLegs = itinerary.legs ?? []
        let rides = allLegs.filter { ["BUS", "TRAM", "SUBWAY", "RAIL", "TRAIN"].contains(($0.mode ?? "").uppercased()) }
        guard (1...3).contains(rides.count),
              let first = rides.first, let last = rides.last,
              let firstFrom = first.from, let lastTo = last.to,
              let departure = first.startTime.map(dateFromMilliseconds),
              let arrival = last.endTime.map(dateFromMilliseconds) else { return nil }

        let itineraryStart = itinerary.startTime.map(dateFromMilliseconds) ?? departure
        let itineraryEnd = itinerary.endTime.map(dateFromMilliseconds) ?? arrival
        let originWalk = max(0, Int(ceil(departure.timeIntervalSince(itineraryStart) / 60)))
        let destinationWalk = max(0, Int(ceil(itineraryEnd.timeIntervalSince(arrival) / 60)))
        let lines = rides.map { $0.routeShortName ?? $0.route ?? "?" }
        let directions = rides.map { $0.headsign ?? $0.to?.name ?? "" }
        let entities = rides.map { entityID(for: $0.agencyId) }
        let stops = rides.map { ride in
            StopFeature(id: "\(entityID(for: ride.agencyId))-\(cleanStopID(ride.from?.stopId ?? ride.from?.stopCode ?? "?"))",
                properties: StopProperties(ENTITEITNUMMER: entityID(for: ride.agencyId),
                    STOPID: cleanStopID(ride.from?.stopId ?? ride.from?.stopCode ?? "?"),
                    NAAMHALTE: ride.from?.name ?? "Arrêt", NAAMGEM: ""))
        }
        let destinationID = cleanStopID(lastTo.stopId ?? lastTo.stopCode ?? "?")
        let finalStop = StopFeature(id: "\(entities.last ?? "2")-\(destinationID)",
            properties: StopProperties(ENTITEITNUMMER: entities.last ?? "2", STOPID: destinationID,
                NAAMHALTE: lastTo.name ?? "Destination", NAAMGEM: ""))

        func pathIDs(for ride: BelgianPlannerLeg) -> [String] {
            ([ride.from].compactMap { $0 } + (ride.intermediateStops ?? []) + [ride.to].compactMap { $0 })
                .compactMap { $0.stopId ?? $0.stopCode }
                .map(cleanStopID)
        }
        func coordinates(for ride: BelgianPlannerLeg) -> [JourneyStopCoordinate] {
            let entityID = entityID(for: ride.agencyId)
            return ([ride.from].compactMap { $0 } + (ride.intermediateStops ?? []) + [ride.to].compactMap { $0 })
                .compactMap { stop in
                    guard let rawID = stop.stopId ?? stop.stopCode,
                          let latitude = stop.lat, let longitude = stop.lon,
                          latitude.isFinite, longitude.isFinite,
                          abs(latitude) > 0.01, abs(longitude) > 0.01 else { return nil }
                    return JourneyStopCoordinate(entityID: entityID, stopID: cleanStopID(rawID),
                                                latitude: latitude, longitude: longitude)
                }
        }
        func transferName(after index: Int) -> String? {
            guard rides.indices.contains(index), rides.indices.contains(index + 1),
                  let from = rides[index].to, let to = rides[index + 1].from else { return nil }
            let walk = allLegs.filter { leg in
                guard (leg.mode ?? "").uppercased() == "WALK",
                      let start = leg.startTime, let end = leg.endTime,
                      let rideEnd = rides[index].endTime, let nextStart = rides[index + 1].startTime else { return false }
                return start >= rideEnd && end <= nextStart
            }
            let walkMinutes = walk.reduce(0) { partial, leg in
                guard let start = leg.startTime, let end = leg.endTime else { return partial }
                return partial + max(0, Int(ceil((end - start) / 60_000)))
            }
            let station = from.name ?? to.name ?? "Correspondance"
            return walkMinutes > 0 ? "\(station) · marche \(walkMinutes) min" : station
        }

        let transfer1 = transferName(after: 0)
        let transfer2 = rides.count > 2 ? transferName(after: 1) : nil
        let secondStart = rides.count > 1 ? rides[1].startTime.map(dateFromMilliseconds) : nil
        let thirdStart = rides.count > 2 ? rides[2].startTime.map(dateFromMilliseconds) : nil
        let delay = Int(((first.departureDelay ?? 0) / 60).rounded())
        let id = "bmc-\(Int(departure.timeIntervalSince1970))-\(lines.joined(separator: "-"))"
        var journey = DeLijnJourney(id: id, line: lines[0], destination: directions.last ?? lastTo.name ?? "",
            lineDirection: directions[0], departure: departure, arrival: arrival, delayMinutes: delay,
            hasRealtimePrediction: first.realTime ?? false,
            transferStop: transfer1, transferStopID: rides.count > 1 ? cleanStopID(rides[0].to?.stopId ?? rides[0].to?.stopCode ?? "?") : nil,
            transferArrival: rides.count > 1 ? rides[0].endTime.map(dateFromMilliseconds) : nil,
            secondLine: lines.count > 1 ? lines[1] : nil,
            secondLineDirection: directions.count > 1 ? directions[1] : nil, secondDeparture: secondStart,
            secondTransferStop: transfer2,
            secondTransferStopID: rides.count > 2 ? cleanStopID(rides[1].to?.stopId ?? rides[1].to?.stopCode ?? "?") : nil,
            secondTransferArrival: rides.count > 2 ? rides[1].endTime.map(dateFromMilliseconds) : nil,
            thirdLine: lines.count > 2 ? lines[2] : nil,
            thirdLineDirection: directions.count > 2 ? directions[2] : nil, thirdDeparture: thirdStart,
            firstLegStopIDs: pathIDs(for: rides[0]),
            secondLegStopIDs: rides.count > 1 ? pathIDs(for: rides[1]) : [],
            thirdLegStopIDs: rides.count > 2 ? pathIDs(for: rides[2]) : [],
            firstLegEntityID: entities[0], secondLegEntityID: entities.count > 1 ? entities[1] : nil,
            thirdLegEntityID: entities.count > 2 ? entities[2] : nil)
        journey.firstLegMode = rides[0].mode
        journey.secondLegMode = rides.count > 1 ? rides[1].mode : nil
        journey.thirdLegMode = rides.count > 2 ? rides[2].mode : nil
        journey.firstBoardStopName = rides[0].from?.name
        journey.firstBoardStopID = rides[0].from?.stopId ?? rides[0].from?.stopCode
        journey.secondBoardStopName = rides.count > 1 ? rides[1].from?.name : nil
        journey.secondBoardStopID = rides.count > 1 ? rides[1].from?.stopId ?? rides[1].from?.stopCode : nil
        journey.thirdBoardStopName = rides.count > 2 ? rides[2].from?.name : nil
        journey.thirdBoardStopID = rides.count > 2 ? rides[2].from?.stopId ?? rides[2].from?.stopCode : nil
        journey.firstLegCoordinates = coordinates(for: rides[0])
        journey.secondLegCoordinates = rides.count > 1 ? coordinates(for: rides[1]) : nil
        journey.thirdLegCoordinates = rides.count > 2 ? coordinates(for: rides[2]) : nil
        return BelgianUnifiedJourney(journey: journey, origin: stops[0], destination: finalStop,
            originLatitude: firstFrom.lat ?? 0, originLongitude: firstFrom.lon ?? 0,
            destinationLatitude: lastTo.lat ?? 0, destinationLongitude: lastTo.lon ?? 0,
            originWalkMinutes: originWalk, destinationWalkMinutes: destinationWalk)
    }

    private static func entityID(for agency: String?) -> String {
        let normalized = (agency ?? "").lowercased()
        if normalized.contains("stib") || normalized.contains("mivb") { return "stib" }
        if normalized.contains("tec") || normalized.contains("letec") { return "tec" }
        if normalized.contains("sncb") || normalized.contains("nmbs") { return "nmbs" }
        return "2"
    }

    private static func isSTIBAgency(_ agency: String?) -> Bool {
        let normalized = (agency ?? "").folding(
            options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "en_US_POSIX"))
        return normalized.contains("stib") || normalized.contains("mivb")
    }

    private static func isAgency(_ agency: String?, in network: String) -> Bool {
        let normalized = (agency ?? "").folding(
            options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "en_US_POSIX"))
        switch network.lowercased() {
        case "tec": return normalized.contains("tec")
        case "nmbs", "sncb": return normalized.contains("sncb") || normalized.contains("nmbs")
        default: return false
        }
    }

    private static func networkKey(for agency: String?) -> String {
        switch entityID(for: agency) {
        case "stib": return "stib"
        case "tec": return "tec"
        case "nmbs": return "nmbs"
        default: return "delijn"
        }
    }

    private static func normalizedTransitMode(_ value: String?) -> String {
        switch (value ?? "").uppercased() {
        case "TRAM": return "TRAM"
        case "SUBWAY", "METRO": return "SUBWAY"
        case "RAIL", "TRAIN": return "RAIL"
        default: return "BUS"
        }
    }

    private static func cleanStopID(_ value: String) -> String {
        String(value.split(separator: ":").last ?? Substring(value))
    }

    private static func dateFromMilliseconds(_ milliseconds: Double) -> Date {
        Date(timeIntervalSince1970: milliseconds / 1000)
    }

    private static var brusselsCalendar: Calendar = {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "Europe/Brussels")!
        return calendar
    }()
}
