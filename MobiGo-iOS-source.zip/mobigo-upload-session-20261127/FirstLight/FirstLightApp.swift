import SwiftUI

@main
struct FirstLightApp: App {
    @StateObject private var adsConsent = AdsConsentManager()

    init() {
        AlarmScheduler.shared.prepare()
    }

    var body: some Scene {
        WindowGroup {
            HomeView()
                .environmentObject(adsConsent)
                .task { await adsConsent.updateConsentAndStartAds() }
        }
    }
}
