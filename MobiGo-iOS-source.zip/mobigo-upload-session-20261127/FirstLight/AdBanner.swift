import SwiftUI
import GoogleMobileAds
import UserMessagingPlatform

@MainActor
final class AdsConsentManager: ObservableObject {
    @Published private(set) var canRequestAds = false
    @Published private(set) var privacyOptionsRequired = false

    private var didStart = false

    func updateConsentAndStartAds() async {
        guard !didStart else { return }
        didStart = true

#if DEBUG
        // Debug builds use Google's sample test ad unit only. Bypass UMP here
        // so developers can verify the banner layout without a live consent
        // message or any production ad traffic. Release builds always run UMP.
        canRequestAds = true
        privacyOptionsRequired = false
        await MobileAds.shared.start()
        return
#else
        let consentInformation = ConsentInformation.shared
        do {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                consentInformation.requestConsentInfoUpdate(with: RequestParameters()) { error in
                    if let error {
                        continuation.resume(throwing: error)
                    } else {
                        continuation.resume(returning: ())
                    }
                }
            }
            try await ConsentForm.loadAndPresentIfRequired(from: nil)
        } catch {
            // Ads stay disabled if the current consent state cannot be confirmed.
#if DEBUG
            print("[MobiGo][UMP] Consent flow failed: \(error.localizedDescription)")
#endif
        }

        canRequestAds = consentInformation.canRequestAds
        privacyOptionsRequired = consentInformation.privacyOptionsRequirementStatus == .required
#if DEBUG
        print("[MobiGo][UMP] canRequestAds=\(canRequestAds), privacyOptionsRequired=\(privacyOptionsRequired)")
#endif
        guard canRequestAds else { return }
        await MobileAds.shared.start()
#endif
    }

    func presentPrivacyOptions() async {
        guard privacyOptionsRequired else { return }
        do {
            try await ConsentForm.presentPrivacyOptionsForm(from: nil)
        } catch {
            // Keep the rest of MobiGo available if the optional form cannot load.
        }
        canRequestAds = ConsentInformation.shared.canRequestAds
    }
}

struct BannerAdSlot: View {
    @EnvironmentObject private var consent: AdsConsentManager
    @State private var bannerHeight: CGFloat = 50

    var body: some View {
        Group {
            if consent.canRequestAds {
                BannerAdView(adSize: AdSizeBanner) { height in
                    withAnimation(.easeOut(duration: 0.2)) {
                        bannerHeight = height
                    }
                }
                .frame(width: AdSizeBanner.size.width, height: AdSizeBanner.size.height)
                .frame(maxWidth: .infinity)
                .frame(height: bannerHeight)
                .clipped()
                .accessibilityLabel("Publicité")
            }
        }
    }
}

private struct BannerAdView: UIViewRepresentable {
    let adSize: AdSize
    let onHeightChange: (CGFloat) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onHeightChange: onHeightChange)
    }

    func makeUIView(context: Context) -> BannerView {
        let banner = BannerView(adSize: adSize)
        #if DEBUG
        // Google’s iOS fixed-banner sample unit keeps simulator/development
        // traffic out of the production AdMob account.
        banner.adUnitID = "ca-app-pub-3940256099942544/2934735716"
        #else
        banner.adUnitID = "ca-app-pub-1058697729201056/6467883490"
        #endif
        banner.rootViewController = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap(\.windows)
            .first(where: \.isKeyWindow)?.rootViewController
        banner.delegate = context.coordinator
        banner.load(Request())
        return banner
    }

    func updateUIView(_ uiView: BannerView, context: Context) {
        context.coordinator.onHeightChange = onHeightChange
        if uiView.adSize.size != adSize.size {
            uiView.adSize = adSize
            uiView.load(Request())
        }
    }

    final class Coordinator: NSObject, BannerViewDelegate {
        var onHeightChange: (CGFloat) -> Void

        init(onHeightChange: @escaping (CGFloat) -> Void) {
            self.onHeightChange = onHeightChange
        }

        func bannerViewDidReceiveAd(_ bannerView: BannerView) {
#if DEBUG
            print("[MobiGo][Ads] Test banner received")
#endif
            onHeightChange(bannerView.adSize.size.height)
        }

        func bannerView(_ bannerView: BannerView, didFailToReceiveAdWithError error: Error) {
#if DEBUG
            print("[MobiGo][Ads] Banner failed: \(error.localizedDescription)")
#endif
            onHeightChange(0)
        }
    }
}
