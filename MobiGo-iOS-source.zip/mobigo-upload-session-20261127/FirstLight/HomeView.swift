import SwiftUI
import WidgetKit
import UserNotifications
import MapKit
import UIKit
import AudioToolbox

private enum Palette {
    private static func color(_ dark: UInt, _ light: UInt) -> Color {
        Color(uiColor: UIColor { traits in
            let value = traits.userInterfaceStyle == .dark ? dark : light
            return UIColor(red: CGFloat((value >> 16) & 0xff) / 255,
                           green: CGFloat((value >> 8) & 0xff) / 255,
                           blue: CGFloat(value & 0xff) / 255, alpha: 1)
        })
    }

    static let background = color(0x080B18, 0xF4F6FB)
    static let card = color(0x11172B, 0xFFFFFF)
    static let elevated = color(0x1B2239, 0xE9EDF6)
    static let muted = color(0x98A2BA, 0x69758C)
    static let text = color(0xF4F5FC, 0x1A2540)
    // BusMind's dark accent is violet; the light variant follows the cyan
    // accent from the reference design.
    static let purple = color(0xA477FF, 0x20B7F4)
    static let blue = color(0x3B8BFF, 0x20B7F4)
    static let pink = color(0xEA5C91, 0xD9436C)
    static let green = color(0x3CCB96, 0x108B69)
    static let highlightedCard = color(0x211D3A, 0xE5F8FC)

    // A stable hue derived from the line number keeps its badge color consistent.
    static func line(_ number: String) -> Color {
        let value = number.unicodeScalars.reduce(5381) { ($0 &* 33) ^ Int($1.value) }
        let hue = Double(abs(value % 360)) / 360
        return Color(hue: hue, saturation: 0.78, brightness: 0.96)
    }

    static func routeLine(_ index: Int) -> Color {
        let colors: [(UInt, UInt)] = [
            (0x3478F6, 0x1D4ED8),
            (0xA855F7, 0x7E22CE),
            (0xEC4899, 0xBE123C),
            (0x14B8A6, 0x0F766E),
            (0xF97316, 0xC2410C),
            (0x22C55E, 0x15803D),
            (0xEAB308, 0xA16207)
        ]
        let (dark, light) = colors[index % colors.count]
        return color(dark, light)
    }

    private static func transitLineHue(_ identity: String) -> Double {
        let hash = identity.unicodeScalars.reduce(UInt64(5381)) { ($0 &* 33) ^ UInt64($1.value) }
        return Double(hash % 360) / 360
    }

    static func transitLine(_ identity: String, lightMode: Bool) -> Color {
        Color(hue: transitLineHue(identity), saturation: 0.78, brightness: lightMode ? 0.9 : 0.76)
    }

    static func transitLineText(_ identity: String, lightMode: Bool) -> Color {
        let hue = transitLineHue(identity) * 360
        let saturation = 0.78
        let brightness = lightMode ? 0.9 : 0.76
        let chroma = brightness * saturation
        let secondary = chroma * (1 - abs((hue / 60).truncatingRemainder(dividingBy: 2) - 1))
        let offset = brightness - chroma
        let rgb: (Double, Double, Double)
        switch hue {
        case 0..<60: rgb = (chroma, secondary, 0)
        case 60..<120: rgb = (secondary, chroma, 0)
        case 120..<180: rgb = (0, chroma, secondary)
        case 180..<240: rgb = (0, secondary, chroma)
        case 240..<300: rgb = (secondary, 0, chroma)
        default: rgb = (chroma, 0, secondary)
        }
        func linear(_ channel: Double) -> Double {
            let value = channel + offset
            return value <= 0.04045 ? value / 12.92 : pow((value + 0.055) / 1.055, 2.4)
        }
        let luminance = 0.2126 * linear(rgb.0) + 0.7152 * linear(rgb.1) + 0.0722 * linear(rgb.2)
        let whiteContrast = 1.05 / (luminance + 0.05)
        let blackContrast = (luminance + 0.05) / 0.05
        return blackContrast >= whiteContrast ? .black : .white
    }
}

private struct MobiGoPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.975 : 1)
            .opacity(configuration.isPressed && !reduceMotion ? 0.86 : 1)
            .animation(reduceMotion ? nil : .spring(response: 0.24, dampingFraction: 0.76),
                       value: configuration.isPressed)
    }
}

@MainActor
private enum MobiGoInteractionFeedback {
    private static let selection = UISelectionFeedbackGenerator()
    private static let notification = UINotificationFeedbackGenerator()

    static func play(success: Bool) {
        if success {
            notification.prepare()
            notification.notificationOccurred(.success)
            notification.prepare()
        } else {
            selection.prepare()
            selection.selectionChanged()
            selection.prepare()
        }
    }
}

private struct RefreshPulse: View {
    let reduceMotion: Bool
    let color: Color
    @State private var isPulsing = false

    var body: some View {
        Image(systemName: "tram.fill")
            .font(.system(size: 12, weight: .bold))
            .foregroundStyle(color)
            .frame(width: 20, height: 20)
            .background(color.opacity(isPulsing ? 0.2 : 0.08), in: Circle())
            .scaleEffect(reduceMotion || !isPulsing ? 1 : 1.1)
            .opacity(reduceMotion || !isPulsing ? 0.86 : 1)
            .animation(reduceMotion ? nil : .easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: isPulsing)
            .onAppear { if !reduceMotion { isPulsing = true } }
            .onChange(of: reduceMotion) { enabled in isPulsing = !enabled }
            .accessibilityHidden(true)
    }
}

private struct PlannedJourneyCandidate: Sendable {
    let trip: DeLijnJourney
    let stop: NearbyDeLijnStop
    let origin: StopFeature
    let originWalk: Int
    let destinationWalk: WalkEstimate
}

private struct WalkEstimate: Sendable {
    let minutes: Int
    let distanceMeters: Double?
}

private enum WalkingRouteEstimator {
    static func estimate(from start: NearbyDeLijnStop, to destination: CLLocationCoordinate2D) async -> WalkEstimate {
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: MKPlacemark(
            coordinate: CLLocationCoordinate2D(latitude: start.latitude, longitude: start.longitude)))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: destination))
        request.transportType = .walking
        guard let response = try? await MKDirections(request: request).calculate(),
              let route = response.routes.min(by: { $0.expectedTravelTime < $1.expectedTravelTime }) else {
            return WalkEstimate(minutes: start.walkMinutes, distanceMeters: nil)
        }
        return WalkEstimate(minutes: max(1, Int(ceil(route.expectedTravelTime / 60))), distanceMeters: route.distance)
    }
}

struct HomeView: View {
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @EnvironmentObject private var adsConsent: AdsConsentManager
    @StateObject private var locationProvider = DeviceLocationProvider.shared
    @Namespace private var tabHighlight
    @AppStorage("wakeMinutes") private var wakeMinutes = 15
    @AppStorage("prepMinutes") private var prepMinutes = 30
    @AppStorage("wakeDifficulty") private var wakeDifficulty = 1
    @AppStorage("destinationName") private var destinationName = "Centre-ville"
    @AppStorage("stopName") private var stopName = ""
    @AppStorage("homeAddress") private var homeAddress = ""
    @AppStorage("homeLatitude") private var homeLatitude = 0.0
    @AppStorage("homeLongitude") private var homeLongitude = 0.0
    @AppStorage("homeWalkMinutes") private var homeWalkMinutes = 0
    @AppStorage("departureHour") private var departureHour = 8
    @AppStorage("departureMinute") private var departureMinute = 12
    @AppStorage("arriveByHour") private var arriveByHour = 9
    @AppStorage("arriveByMinute") private var arriveByMinute = 0
    @AppStorage("alarmWeekdays") private var alarmWeekdays = "2,3,4,5,6"
    @AppStorage("savedDestinationItems") private var savedDestinationItemsJSON = "[]"
    @AppStorage("weekdayDestinationAssignments") private var weekdayDestinationAssignmentsJSON = "{}"
    @AppStorage("deLijnStopID") private var deLijnStopID = ""
    @AppStorage("deLijnEntityID") private var deLijnEntityID = "2"
    @AppStorage("transitNetwork") private var transitNetwork = "auto"
    @AppStorage("subscribedTransitNetworks.v1") private var subscribedTransitNetworksRaw = ""
    @AppStorage("includeUnsubscribedNetworks.v1") private var includeUnsubscribedNetworks = false
    @AppStorage("subscriptionSettingsMigrated.v1") private var subscriptionSettingsMigrated = false
    @AppStorage("appTheme") private var appTheme = "dark"
    @AppStorage("interactionSoundsEnabled.v1") private var interactionSoundsEnabled = true
    @AppStorage("interactionSoundsMutedByDefaultMigration.v1") private var interactionSoundsMutedByDefaultMigration = false
    @AppStorage("interactionHapticsEnabled.v1") private var interactionHapticsEnabled = true
    @AppStorage("transitModes.v1") private var transitModesRaw = "BUS,TRAM,SUBWAY"
    @AppStorage("destinationStopID") private var destinationStopID = ""
    @AppStorage("destinationEntityID") private var destinationEntityID = "2"
    @AppStorage("destinationMunicipality") private var destinationMunicipality = ""
    @AppStorage("destinationLatitude") private var destinationLatitude = 0.0
    @AppStorage("destinationLongitude") private var destinationLongitude = 0.0
    @AppStorage("destinationWalkMinutes") private var finalWalkMinutes = 0
    @AppStorage("destinationWalkIsApproximate") private var finalWalkIsApproximate = true
    @AppStorage("alarmEnabled") private var alarmEnabled = false
    @AppStorage("tripTrackingEnabled") private var tripTrackingEnabled = false
    @AppStorage("departuresLastRefreshEpoch") private var departuresLastRefreshEpoch = 0.0
    @State private var selectedTab = 0
    @State private var tabTransitionEdge: Edge = .trailing
    @State private var destination = ""
    @State private var showingProfile = false
    @State private var showingRoutes = false
    @State private var showingInfo = false
    @State private var showingStopPicker = false
    @State private var showingWidgetHelp = false
    @State private var showingAdvancedSettings = false
    @State private var apiStatus = ""
    @State private var isLoadingDepartures = false
    @State private var stopSearchText = ""
    @State private var stopResults: [StopFeature] = []
    @State private var isSearchingStops = false
    @State private var isFindingNearbyOrigin = false
    @State private var stopSearchMessage = ""
    @State private var savedWidgetStopItems = WidgetDataStore.savedWidgetStops()
    @State private var widgetStopSearchText = ""
    @State private var widgetStopSearchResults: [StopFeature] = []
    @State private var isSearchingWidgetStops = false
    @State private var widgetStopSearchMessage = ""
    @State private var homeAddressQuery = ""
    @State private var homeAddressResults: [DestinationPlace] = []
    @State private var isSearchingHomeAddress = false
    @State private var isEditingHomeAddress = false
    @State private var isEditingDestination = false
    @State private var didInitialRefresh = false
    @State private var showTrips = false
    @State private var showAllDepartures = false
    @State private var showMap = false
    @State private var alarmMessage = ""
    @State private var departures: [DeLijnStopPassage] = []
    @State private var destinationResults: [StopFeature] = []
    @State private var destinationPlaceResults: [DestinationPlace] = []
    @State private var selectedPlace: DestinationPlace?
    @State private var nearbyDestinationStops: [NearbyDeLijnStop] = []
    @State private var mapDestinationCoordinate: CLLocationCoordinate2D?
    @State private var selectedDestination: StopFeature?
    @State private var journeys: [DeLijnJourney] = []
    @State private var mapRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 51.05, longitude: 3.72), span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
    @State private var userTrackingMode: MapUserTrackingMode = .none
    @State private var mapCoordinate: CLLocationCoordinate2D?
    @State private var mapFinalStopCoordinate: CLLocationCoordinate2D?
    @State private var walkToDeparturePolyline: MKPolyline?
    @State private var walkToDestinationPolyline: MKPolyline?
    @State private var transitMapRoutes: [(MKPolyline, UIColor, String, String)] = []
    @State private var journeyStatus = ""
    @State private var isSearchingJourneys = false
    @State private var lastRouteRefresh: Date?
    @State private var liveDelayByLeg: [String: Int] = [:]
    @State private var isRefreshingJourneyPredictions = false
    @State private var predictionRefreshDatesByJourney: [String: Date] = [:]
    @State private var scheduledReminderTripID: String?
    @State private var announcedServiceDelayByLeg: [String: Int] = [:]
    @State private var routeNotificationMessage = ""
    @State private var showingAlertsInfo = false
    @State private var trackingMessage = ""
    @State private var notifiedTransferIDs: Set<String> = []
    @State private var transferCoordinates: [String: CLLocationCoordinate2D] = [:]

    private var displayHomeAddress: String {
        let parts = homeAddress.split(separator: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        var seen = Set<String>()
        return parts.filter { seen.insert($0.lowercased()).inserted }.joined(separator: ", ")
    }

    private var departureDate: Date {
        let today = Calendar.current.date(bySettingHour: departureHour, minute: departureMinute, second: 0, of: .now) ?? .now
        return today > .now ? today : (Calendar.current.date(byAdding: .day, value: 1, to: today) ?? today)
    }

    private var arrivalTargetDate: Date {
        if let next = nextAssignedDestination(after: .now) { return next.date }
        if let next = nextCommuteDate(after: .now) { return next }
        let today = Calendar.current.date(bySettingHour: arriveByHour, minute: arriveByMinute, second: 0, of: .now) ?? .now
        return today > .now ? today : (Calendar.current.date(byAdding: .day, value: 1, to: today) ?? today)
    }

    private var savedDestinations: [SavedDestination] {
        guard let data = savedDestinationItemsJSON.data(using: .utf8),
              let places = try? JSONDecoder().decode([SavedDestination].self, from: data) else { return [] }
        return places
    }

    private var subscribedTransitNetworks: Set<String> {
        Set(subscribedTransitNetworksRaw.split(separator: ",").map(String.init))
    }

    private var enabledTransitModes: Set<String> {
        Set(transitModesRaw.split(separator: ",").map { String($0).uppercased() })
    }

    private func toggleTransitMode(_ mode: String) {
        var modes = enabledTransitModes
        if modes.contains(mode) { modes.remove(mode) } else { modes.insert(mode) }
        transitModesRaw = modes.sorted().joined(separator: ",")
    }

    private func normalizedTransitMode(_ mode: String?) -> String {
        switch (mode ?? "").trimmingCharacters(in: .whitespacesAndNewlines).uppercased() {
        case "TRAM", "TRAMWAY": return "TRAM"
        case "SUBWAY", "METRO", "METRO_SERVICE": return "SUBWAY"
        case "RAIL", "TRAIN", "TRAIN_SERVICE": return "RAIL"
        case "BUS", "BUS_SERVICE", "BUSSERVICE": return "BUS"
        default: return "UNKNOWN"
        }
    }

    private func journeyMatchesCurrentFilters(_ journey: DeLijnJourney) -> Bool {
        let legs = [(journey.firstLegEntityID, journey.firstLegMode),
                    (journey.secondLegEntityID, journey.secondLegMode),
                    (journey.thirdLegEntityID, journey.thirdLegMode)].filter { $0.0 != nil || $0.1 != nil }
        let entities = legs.compactMap { $0.0 }
        if let allowed = allowedPlannerNetworks,
           entities.contains(where: { entity in
               guard let network = TransitFareNetwork.networkID(for: entity) else { return true }
               return !allowed.contains(network)
           }) { return false }
        let modes = legs.map { entity, mode in
            TransitFareNetwork.networkID(for: entity ?? "") == "nmbs" ? "RAIL" : normalizedTransitMode(mode)
        }
        return modes.allSatisfy { mode in
            mode == "UNKNOWN"
                ? enabledTransitModes.isSuperset(of: ["BUS", "TRAM", "SUBWAY"])
                : enabledTransitModes.contains(mode)
        }
    }

    /// An empty subscription list means pay-as-you-go, so all networks remain available.
    /// Once at least one pass is selected, other operators are excluded unless the rider
    /// explicitly allows paid networks.
    private var allowedPlannerNetworks: Set<String>? {
        if includeUnsubscribedNetworks || subscribedTransitNetworks.isEmpty { return nil }
        var allowed = subscribedTransitNetworks
        switch transitNetwork {
        case "delijn": allowed.formIntersection(["delijn"])
        case "stib": allowed.formIntersection(["stib"])
        case "tec": allowed.formIntersection(["tec"])
        case "nmbs": allowed.formIntersection(["nmbs"])
        default: break
        }
        return allowed
    }

    private func setTransitSubscription(_ network: String, enabled: Bool) {
        var selected = subscribedTransitNetworks
        if enabled { selected.insert(network) } else { selected.remove(network) }
        subscribedTransitNetworksRaw = selected.sorted().joined(separator: ",")
    }

    private func setAllTransitSubscriptions(_ enabled: Bool) {
        subscribedTransitNetworksRaw = enabled ? TransitFareNetwork.all.map(\.id).joined(separator: ",") : ""
    }

    private func fareEstimate(for trip: DeLijnJourney) -> JourneyFareEstimate {
        let legs: [String?] = [
            trip.firstLegEntityID ?? deLijnEntityID,
            trip.secondLine == nil ? nil : trip.secondLegEntityID,
            trip.thirdLine == nil ? nil : trip.thirdLegEntityID
        ]
        var networks: Set<String> = []
        for entityID in legs {
            guard let entityID, let network = TransitFareNetwork.networkID(for: entityID) else { continue }
            // With no pass selected, assume pay-as-you-go and show fares for
            // every operator in the itinerary. A selected operator is treated
            // as covered by the pass; other operators remain chargeable.
            if subscribedTransitNetworks.isEmpty || !subscribedTransitNetworks.contains(network) {
                networks.insert(network)
            }
            // The route may use the same operator for several connecting legs;
            // one standard ticket/pass is counted once per operator.
        }
        let items = TransitFareNetwork.all.filter { networks.contains($0.id) }.map(\.singleFare)
        return JourneyFareEstimate(items: items)
    }

    private var weekdayDestinationAssignments: [String: String] {
        guard let data = weekdayDestinationAssignmentsJSON.data(using: .utf8),
              let assignments = try? JSONDecoder().decode([String: String].self, from: data) else { return [:] }
        return assignments
    }

    private func nextAssignedDestination(after date: Date) -> (place: SavedDestination, date: Date)? {
        let calendar = Calendar.current
        let assignments = weekdayDestinationAssignments
        for offset in 0..<14 {
            guard let day = calendar.date(byAdding: .day, value: offset, to: calendar.startOfDay(for: date)) else { continue }
            let weekday = calendar.component(.weekday, from: day)
            guard selectedAlarmWeekdays.contains(weekday),
                  let placeID = assignments[String(weekday)],
                  let place = savedDestinations.first(where: { $0.id == placeID }),
                  let target = calendar.date(bySettingHour: arriveByHour, minute: arriveByMinute, second: 0, of: day),
                  target > date else { continue }
            return (place, target)
        }
        return nil
    }

    private var fallbackArrivalTargetDate: Date? {
        nextCommuteDate(after: arrivalTargetDate.addingTimeInterval(1))
    }

    private func commuteDayLabel(for date: Date) -> String {
        if Calendar.current.isDateInToday(date) { return "Aujourd’hui" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "fr_BE")
        formatter.dateFormat = "EEEE d MMMM"
        return formatter.string(from: date).capitalized
    }

    private func nextCommuteDate(after date: Date) -> Date? {
        let calendar = Calendar.current
        return selectedAlarmWeekdays.compactMap { weekday -> Date? in
            var components = DateComponents()
            components.weekday = weekday
            components.hour = arriveByHour
            components.minute = arriveByMinute
            return calendar.nextDate(after: date, matching: components, matchingPolicy: .nextTime)
        }.min()
    }

    private var wakeSequenceDuration: Int {
        switch wakeDifficulty {
        case 0: return 3
        case 2...: return 9
        default: return 6
        }
    }

    private var wakeDate: Date {
        let calendar = Calendar.current
        let nextAlerts = selectedAlarmWeekdays.compactMap { weekday -> Date? in
            var components = DateComponents()
            components.weekday = weekday
            components.hour = departureHour
            components.minute = departureMinute
            guard let commute = calendar.nextDate(after: .now, matching: components, matchingPolicy: .nextTime),
                  let alert = calendar.date(byAdding: .minute, value: -wakeLeadMinutes, to: commute) else { return nil }
            return alert > .now ? alert : calendar.date(byAdding: .day, value: 7, to: alert)
        }
        return nextAlerts.min() ?? (calendar.date(byAdding: .minute, value: -wakeLeadMinutes, to: departureDate) ?? .now)
    }

    private let departureBufferMinutes = 5
    private var wakeLeadMinutes: Int { wakeMinutes + prepMinutes + homeWalkMinutes + departureBufferMinutes + 10 + wakeSequenceDuration }

    private var selectedAlarmWeekdays: Set<Int> {
        Set(alarmWeekdays.split(separator: ",").compactMap { Int($0) })
    }

    private var nextDepartureTime: Date {
        if let next = departures.first, next.realtimeTime > .now { return next.realtimeTime }
        return departureDate
    }

    private var hasFreshDeparturePredictions: Bool {
        departuresLastRefreshEpoch > 0
            && Date.now.timeIntervalSince1970 - departuresLastRefreshEpoch <= 15 * 60
    }

    private var nextDepartureHasFreshPrediction: Bool {
        guard departures.first?.hasRealtimePrediction == true else { return false }
        return hasFreshDeparturePredictions
    }

    var body: some View {
        ZStack {
            Palette.background.ignoresSafeArea()
            RadialGradient(colors: [Palette.purple.opacity(appTheme == "dark" ? 0.13 : 0.075), .clear],
                           center: .topTrailing, startRadius: 0, endRadius: 460)
                .ignoresSafeArea()
            RadialGradient(colors: [Palette.blue.opacity(appTheme == "dark" ? 0.06 : 0.035), .clear],
                           center: .bottomLeading, startRadius: 30, endRadius: 520)
                .ignoresSafeArea()
            VStack(spacing: 0) {
                activePage
                    .id(selectedTab)
                    .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: tabTransitionEdge)))
                    .animation(reduceMotion ? nil : .easeInOut(duration: 0.22), value: selectedTab)
                BannerAdSlot()
                tabBar
            }
        }
        .foregroundStyle(Palette.text)
        .buttonStyle(MobiGoPressStyle())
        .preferredColorScheme(appTheme == "light" ? .light : .dark)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.28), value: appTheme)
        .onAppear {
            WidgetDataStore.saveTheme(appTheme)
            if !interactionSoundsMutedByDefaultMigration {
                interactionSoundsEnabled = false
                interactionSoundsMutedByDefaultMigration = true
            }
            if !subscriptionSettingsMigrated {
                // The old single-network picker was a search filter, not proof
                // that the rider owned that operator's pass. Start the new
                // subscription selection empty and restore mixed-network Auto.
                transitNetwork = "auto"
                subscriptionSettingsMigrated = true
            }
        }
        .onChange(of: appTheme) { theme in
            WidgetDataStore.saveTheme(theme)
            WidgetCenter.shared.reloadAllTimelines()
        }
        .onChange(of: subscribedTransitNetworksRaw) { _ in clearJourneyIfFiltersExcludeIt() }
        .onChange(of: includeUnsubscribedNetworks) { _ in clearJourneyIfFiltersExcludeIt() }
        .onChange(of: transitModesRaw) { _ in clearJourneyIfFiltersExcludeIt() }
        .task {
            restoreDestination()
            restoreCachedJourneyIfAvailable()
            Task { await appBecameActiveForAlarm() }
            let departureRefresh = Task { await refreshDepartures() }
            if tripTrackingEnabled {
                do { try await locationProvider.startTripTracking() }
                catch { tripTrackingEnabled = false; trackingMessage = error.localizedDescription }
            }
            if !deLijnStopID.isEmpty, let scheduled = nextAssignedDestination(after: .now) {
                await selectDestinationPlace(scheduled.place.destinationPlace, prepareAlarm: alarmEnabled)
            } else if !deLijnStopID.isEmpty, destinationLatitude != 0, destinationLongitude != 0 {
                let savedPlace = DestinationPlace(name: destinationName, subtitle: destinationMunicipality,
                    coordinate: CLLocationCoordinate2D(latitude: destinationLatitude, longitude: destinationLongitude))
                await selectDestinationPlace(savedPlace, prepareAlarm: alarmEnabled)
            } else if !deLijnStopID.isEmpty, let savedDestination = selectedDestination {
                await findJourneys(to: savedDestination, prepareAlarm: alarmEnabled)
            }
            await departureRefresh.value
            didInitialRefresh = true
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 60_000_000_000)
                if !Task.isCancelled, scenePhase == .active, !deLijnStopID.isEmpty {
                    await loadDepartures()
                    await refreshUpcomingJourneyIfNeeded()
                }
            }
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active {
                Task {
                    await appBecameActiveForAlarm()
                    if didInitialRefresh, !deLijnStopID.isEmpty {
                        await loadDepartures()
                        await refreshUpcomingJourneyIfNeeded()
                    }
                }
                WidgetCenter.shared.reloadAllTimelines()
            }
        }
        .onChange(of: locationProvider.locationUpdateID) { _ in
            Task {
                await checkTransferProximity()
                if let trip = journeys.first { await refreshJourneyPredictions(for: trip) }
            }
        }
    }

    @ViewBuilder private var activePage: some View {
        switch selectedTab {
        case 4: profilePage
        case 2: mapPage
        case 3: infoPage
        default:
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 12) {
                    header
                    if showingAlertsInfo {
                        alertsCard
                            .transition(reduceMotion ? .opacity : .move(edge: .top).combined(with: .opacity))
                    }
                    if !journeys.isEmpty {
                        Group {
                            journeyHeading
                            journeyOverviewCard
                            liveDeparturesCard
                            journeyTimelineCard
                            journeyFareCard
                        }
                        .transition(reduceMotion ? .opacity : .move(edge: .bottom).combined(with: .opacity))
                        if !journeyStatus.isEmpty && isSearchingJourneys { routeLoadingCard }
                    } else {
                        if !didInitialRefresh && (!destinationStopID.isEmpty || selectedDestination != nil) {
                            routeLoadingCard
                        } else if homeLatitude == 0 || homeLongitude == 0 {
                            setupPrompt(icon: "house.fill", title: "Ajoute ton adresse", detail: "MobiGo trouvera l’arrêt le plus proche.", button: "Configurer") {
                                isEditingHomeAddress = true
                                navigateToTab(4)
                            }
                        } else if selectedPlace == nil && selectedDestination == nil {
                            setupPrompt(icon: "mappin.and.ellipse", title: "Où vas-tu ?", detail: "Choisis une adresse, je prépare le trajet.", button: "Choisir ma destination") { navigateToTab(4) }
                        } else if isSearchingJourneys {
                            routeLoadingCard
                        } else {
                            if !journeyStatus.isEmpty { routeStatusCard }
                            search
                        }
                        departureCard
                        if !journeys.isEmpty { wakeCard }
                    }
                }
                .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 14)
                .animation(reduceMotion ? nil : .spring(response: 0.36, dampingFraction: 0.9), value: routePresentationKey)
                .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: isSearchingJourneys)
            }
        }
    }

    private var journeyHeading: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .firstTextBaseline) {
                Text("Mon trajet").font(.system(size: 20, weight: .bold))
                Spacer()
                if isSearchingJourneys || isLoadingDepartures {
                    HStack(spacing: 5) {
                        RefreshPulse(reduceMotion: reduceMotion, color: Palette.purple)
                        Text("Mise à jour")
                    }
                    .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.purple)
                    .padding(.horizontal, 9).padding(.vertical, 6)
                    .background(Palette.purple.opacity(0.1), in: Capsule())
                    .transition(reduceMotion ? .opacity : .scale.combined(with: .opacity))
                } else {
                    Label("Trajet prêt", systemImage: "checkmark")
                        .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.green)
                        .padding(.horizontal, 9).padding(.vertical, 6)
                        .background(Palette.green.opacity(0.12), in: Capsule())
                        .transition(.opacity)
                }
            }
            Text(commuteDayLabel(for: journeys[0].departure).uppercased())
                .font(.system(size: 9, weight: .bold)).tracking(0.4).foregroundStyle(Palette.muted)
            HStack {
                Text("\(homeAddress.isEmpty ? "Départ" : "Domicile") → \(destinationName)").font(.system(size: 14, weight: .semibold))
                    .lineLimit(1).minimumScaleFactor(0.8)
                Spacer()
                Button("Modifier") { playInteractionFeedback(); navigateToTab(4) }
                    .font(.system(size: 11, weight: .bold)).foregroundStyle(Palette.purple)
            }
            Text("Arriver avant \(arrivalTargetDate.formatted(date: .omitted, time: .shortened))")
                .font(.system(size: 10)).foregroundStyle(Palette.muted)
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: isSearchingJourneys || isLoadingDepartures)
    }

    private var journeyOverviewCard: some View {
        let trip = journeys[0]
        let leaveTime = trip.departure.addingTimeInterval(TimeInterval(-(homeWalkMinutes + departureBufferMinutes) * 60))
        let arrival = estimatedArrival(for: trip).addingTimeInterval(TimeInterval(finalWalkMinutes * 60))
        return VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(homeAddress.isEmpty ? "DÉPART" : "DÉPART DE CHEZ TOI")
                    .font(.system(size: 9, weight: .bold)).foregroundStyle(Palette.purple)
                Spacer()
                Text("ARRIVÉE").font(.system(size: 9, weight: .bold)).foregroundStyle(Palette.muted)
            }
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(leaveTime, format: .dateTime.hour().minute())
                    .font(.system(size: 28, weight: .bold, design: .rounded)).monospacedDigit()
                    .contentTransition(reduceMotion ? .identity : .numericText())
                Image(systemName: "arrow.right").font(.system(size: 16, weight: .bold)).foregroundStyle(Palette.purple)
                Spacer(minLength: 0)
                Text(arrival, format: .dateTime.hour().minute())
                    .font(.system(size: 20, weight: .bold, design: .rounded)).monospacedDigit()
                    .contentTransition(reduceMotion ? .identity : .numericText())
            }
            liveCountdownText(to: leaveTime, suffix: " · marge \(departureBufferMinutes) min",
                font: .system(size: 9, weight: .medium), color: Palette.green)
            Rectangle().fill(Palette.muted.opacity(0.18)).frame(height: 1)
            HStack(spacing: 8) {
                Image(systemName: "alarm.fill").foregroundStyle(Palette.purple)
                Text("Réveil").font(.system(size: 11, weight: .medium))
                Text(wakeDate, format: .dateTime.hour().minute()).font(.system(size: 13, weight: .bold, design: .rounded)).monospacedDigit()
                Spacer()
                Button {
                    playInteractionFeedback()
                    Task {
                        do {
                            try await AlarmScheduler.shared.testNow()
                            alarmMessage = AlarmScheduler.supportsSystemAlarm
                                ? "Test du réveil dans 5 secondes."
                                : "20 rappels, puis 3 sons longs · volume selon iOS."
                        } catch { alarmMessage = error.localizedDescription }
                    }
                } label: {
                    Image(systemName: "speaker.wave.2.fill").font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(Palette.purple).padding(7).background(Palette.purple.opacity(0.12), in: Circle())
                }.accessibilityLabel("Tester le réveil")
                Toggle("Réveil", isOn: Binding(get: { alarmEnabled }, set: { setAlarmEnabled($0) }))
                    .labelsHidden().tint(Palette.purple).scaleEffect(0.82, anchor: .trailing).frame(width: 42)
            }
        }
        .padding(12)
        .background(Palette.highlightedCard, in: RoundedRectangle(cornerRadius: 17))
        .overlay(RoundedRectangle(cornerRadius: 17).stroke(Palette.purple.opacity(0.25), lineWidth: 1))
    }

    private var journeyFareCard: some View {
        let estimate = fareEstimate(for: journeys[0])
        return VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 7) {
                Image(systemName: estimate.items.isEmpty ? "checkmark.circle.fill" : "ticket.fill")
                    .foregroundStyle(estimate.items.isEmpty ? Palette.green : Palette.purple)
                Text("PRIX DU TRAJET").font(.system(size: 9, weight: .bold)).foregroundStyle(Palette.muted)
                Spacer()
                Text(estimate.items.isEmpty ? "0 €" : "Dès \(estimate.formattedMinimum)")
                    .font(.system(size: 13, weight: .bold, design: .rounded)).monospacedDigit()
                    .foregroundStyle(estimate.items.isEmpty ? Palette.green : Palette.text)
            }
            if estimate.items.isEmpty {
                Text("Couvert par les abonnements sélectionnés.")
                    .font(.system(size: 10, weight: .medium)).foregroundStyle(Palette.muted)
            } else {
                ForEach(estimate.items) { item in
                    HStack(spacing: 5) {
                        Text(item.networkName).font(.system(size: 10, weight: .semibold))
                        Spacer(minLength: 4)
                        Text(item.priceLabel).font(.system(size: 10, weight: .bold)).monospacedDigit()
                    }.foregroundStyle(Palette.text)
                }
                Text(subscribedTransitNetworks.isEmpty
                     ? "Sans abonnement · estimation adulte, billet simple."
                     : estimate.note)
                    .font(.system(size: 9, weight: .medium)).foregroundStyle(Palette.muted)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 10) {
                    ForEach(estimate.items) { item in
                        Link(destination: item.sourceURL) {
                            Text("Tarif \(item.networkName)")
                                .font(.system(size: 9, weight: .semibold)).foregroundStyle(Palette.purple)
                        }
                    }
                }
            }
        }
        .padding(11)
        .background(Palette.card, in: RoundedRectangle(cornerRadius: 15))
    }

    private var journeyTimelineCard: some View {
        let trip = journeys[0]
        let lineColors = journeyLineColors(for: trip)
        let transferCount = [trip.transferStop, trip.secondTransferStop].compactMap { $0 }.count
        return VStack(alignment: .leading, spacing: 7) {
            HStack {
                Text("Ton parcours").font(.system(size: 14, weight: .bold))
                Spacer()
                Text("\(trip.secondLine == nil ? 1 : trip.thirdLine == nil ? 2 : 3) lignes · \(transferCount) changement\(transferCount == 1 ? "" : "s")")
                    .font(.system(size: 9, weight: .medium)).foregroundStyle(Palette.muted)
            }
            VStack(spacing: 0) {
                if homeWalkMinutes > 0 {
                    timelineRow(icon: "figure.walk", title: "Va à l’arrêt \(stopName)", detail: "À pied · \(homeWalkMinutes) min", time: nil, color: Palette.green, isLast: false, walkTo: mapCoordinate, walkFrom: CLLocationCoordinate2D(latitude: homeLatitude, longitude: homeLongitude))
                }
                timelineRow(icon: vehicleIcon(trip.firstLegMode), title: vehicleInstruction(mode: trip.firstLegMode, line: trip.line), detail: boardDetail(name: trip.firstBoardStopName ?? stopName, direction: trip.lineDirection, duration: legDuration(start: trip.departure, end: trip.transferArrival ?? trip.arrival)), time: trip.departure, color: lineColors[0], isLast: trip.transferStop == nil && trip.secondLine == nil, boardStopID: trip.firstBoardStopID ?? deLijnStopID, boardEntityID: trip.firstLegEntityID ?? deLijnEntityID)
                if let transfer = trip.transferStop {
                    timelineRow(icon: "arrow.down.circle.fill", title: "Descends à \(cleanTransferTitle(transfer))", detail: transferWalkDetail(transfer, toward: trip.secondBoardStopName), time: trip.transferArrival, color: Palette.purple, isLast: false)
                }
                if let line = trip.secondLine {
                    timelineRow(icon: vehicleIcon(trip.secondLegMode), title: vehicleInstruction(mode: trip.secondLegMode, line: line), detail: boardDetail(name: trip.secondBoardStopName ?? trip.transferStop.map(cleanTransferTitle), direction: trip.secondLineDirection ?? "", duration: legDuration(start: trip.secondDeparture, end: trip.secondTransferArrival ?? trip.arrival)), time: trip.secondDeparture, color: lineColors[1], isLast: trip.secondTransferStop == nil && trip.thirdLine == nil, boardStopID: trip.secondBoardStopID, boardEntityID: trip.secondLegEntityID ?? deLijnEntityID)
                }
                if let transfer = trip.secondTransferStop {
                    timelineRow(icon: "arrow.down.circle.fill", title: "Descends à \(cleanTransferTitle(transfer))", detail: transferWalkDetail(transfer, toward: trip.thirdBoardStopName), time: trip.secondTransferArrival, color: Palette.purple, isLast: false)
                }
                if let line = trip.thirdLine {
                    timelineRow(icon: vehicleIcon(trip.thirdLegMode), title: vehicleInstruction(mode: trip.thirdLegMode, line: line), detail: boardDetail(name: trip.thirdBoardStopName ?? trip.secondTransferStop.map(cleanTransferTitle), direction: trip.thirdLineDirection ?? "", duration: legDuration(start: trip.thirdDeparture, end: trip.arrival)), time: trip.thirdDeparture, color: lineColors[2], isLast: false, boardStopID: trip.thirdBoardStopID, boardEntityID: trip.thirdLegEntityID ?? deLijnEntityID)
                }
                if finalWalkMinutes > 0 {
                    timelineRow(icon: "figure.walk", title: "Va à \(destinationName)", detail: "À pied · \(finalWalkMinutes) min", time: nil, color: Palette.green, isLast: true, walkTo: CLLocationCoordinate2D(latitude: destinationLatitude, longitude: destinationLongitude), walkFrom: mapFinalStopCoordinate)
                } else if trip.transferStop == nil && trip.secondLine == nil && homeWalkMinutes == 0 {
                    timelineRow(icon: "mappin.and.ellipse", title: destinationName, detail: "Arrivée", time: trip.arrival, color: Palette.purple, isLast: true)
                }
            }
        }
        .padding(11).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))
    }


    private func openWalkingDirections(to coordinate: CLLocationCoordinate2D, from start: CLLocationCoordinate2D?) {
        let origin = start.flatMap { $0.latitude != 0 && $0.longitude != 0 ? "&saddr=\($0.latitude),\($0.longitude)" : nil } ?? ""
        let urlString = "http://maps.apple.com/?daddr=\(coordinate.latitude),\(coordinate.longitude)\(origin)&dirflg=w"
        guard let url = URL(string: urlString) else { return }
        UIApplication.shared.open(url)
    }

    private func timelineRow(icon: String, title: String, detail: String?, time: Date?, color: Color, isLast: Bool, walkTo: CLLocationCoordinate2D? = nil, walkFrom: CLLocationCoordinate2D? = nil, boardStopID: String? = nil, boardEntityID: String? = nil) -> some View {
        HStack(alignment: .top, spacing: 10) {
            VStack(spacing: 3) {
                Image(systemName: icon).font(.system(size: 12, weight: .semibold)).foregroundStyle(color)
                    .frame(width: 18, height: 18)
                if !isLast { Rectangle().fill(Palette.muted.opacity(0.3)).frame(width: 1, height: 14) }
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 11, weight: .semibold)).foregroundStyle(Palette.text).lineLimit(1)
                if let detail, !detail.isEmpty { Text(detail).font(.system(size: 10)).foregroundStyle(Palette.muted).lineLimit(2).fixedSize(horizontal: false, vertical: true) }
            }
            Spacer(minLength: 4)
            if let time {
                Text(time, format: .dateTime.hour().minute())
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .monospacedDigit().foregroundStyle(Palette.muted)
                    .contentTransition(reduceMotion ? .identity : .numericText())
                    .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: time)
            }
            if icon == "figure.walk", let walkTo, walkTo.latitude != 0 {
                Button { playInteractionFeedback(); openWalkingDirections(to: walkTo, from: walkFrom) } label: { Image(systemName: "arrow.up.right.square.fill").font(.system(size: 14)).foregroundStyle(Palette.blue) }
                    .buttonStyle(MobiGoPressStyle()).accessibilityLabel("Ouvrir la marche dans Plans")
            }
            if let boardStopID, !boardStopID.isEmpty, let boardEntityID {
                Button {
                    playInteractionFeedback()
                    Task {
                        if let coordinate = try? await resolvedStopCoordinate(stopID: boardStopID, entityID: boardEntityID) {
                            openWalkingDirections(to: CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude), from: nil)
                        }
                    }
                } label: { Image(systemName: "arrow.up.right.square.fill").font(.system(size: 14)).foregroundStyle(Palette.blue) }
                    .buttonStyle(MobiGoPressStyle()).accessibilityLabel("Voir l’arrêt dans Plans")
            }
        }
        .frame(minHeight: isLast ? 20 : 34, alignment: .top)
        .id("\(icon)|\(title)")
        .transition(reduceMotion ? .opacity : .move(edge: .leading).combined(with: .opacity))
    }

    private func normalizedMode(_ mode: String?) -> String {
        switch (mode ?? "").trimmingCharacters(in: .whitespacesAndNewlines).uppercased() {
        case "TRAM", "TRAMWAY": return "tram"
        case "SUBWAY", "METRO", "METRO_SERVICE": return "métro"
        case "RAIL", "TRAIN", "TRAIN_SERVICE": return "train"
        case "BUS", "BUS_SERVICE", "BUSSERVICE": return "bus"
        default: return "transport"
        }
    }
    private func vehicleName(_ mode: String?) -> String { normalizedMode(mode) }
    private func vehicleSummary(mode: String?, line: String) -> String {
        let name = normalizedMode(mode)
        return name == "transport" ? "Ligne \(line)" : "\(name.capitalized) \(line)"
    }
    private func vehicleInstruction(mode: String?, line: String) -> String {
        let name = normalizedMode(mode)
        return name == "transport" ? "Prends la ligne \(line)" : "Prends le \(name) \(line)"
    }
    private func networkLabel(_ entityID: String) -> String {
        switch entityID.lowercased() {
        case "stib": return "STIB"
        case "tec", "letec": return "TEC"
        case "nmbs", "sncb": return "SNCB"
        default: return "DE LIJN"
        }
    }
    private func matchesSelectedNetwork(_ entityID: String) -> Bool {
        if let allowed = allowedPlannerNetworks {
            guard let network = TransitFareNetwork.networkID(for: entityID), allowed.contains(network) else {
                return false
            }
        }
        switch transitNetwork {
        case "auto": return true
        case "delijn": return entityID == "2"
        case "stib": return entityID.lowercased() == "stib"
        case "tec": return ["tec", "letec"].contains(entityID.lowercased())
        case "nmbs": return ["nmbs", "sncb"].contains(entityID.lowercased())
        default: return true
        }
    }
    private func vehicleIcon(_ mode: String?) -> String {
        switch normalizedMode(mode) {
        case "tram": return "tram.fill"
        case "métro": return "tram.tunnel.fill"
        case "train": return "train.side.front.car"
        case "transport": return "arrow.triangle.swap"
        default: return "bus.fill"
        }
    }
    private func stopIcon(_ entityID: String) -> String {
        switch entityID.lowercased() {
        case "nmbs", "sncb": return "train.side.front.car"
        case "stib": return "tram.fill"
        default: return "bus.fill"
        }
    }
    private func legDuration(start: Date?, end: Date?) -> String? {
        guard let start, let end else { return nil }
        let minutes = max(1, Int(ceil(end.timeIntervalSince(start) / 60)))
        return "\(minutes) min dans le véhicule"
    }
    private func boardDetail(name: String?, direction: String, duration: String?) -> String {
        let place = name ?? "Arrêt"
        let way = direction.isEmpty ? "" : " → \(direction)"
        let time = duration.map { " · \($0.replacingOccurrences(of: " dans le véhicule", with: ""))" } ?? ""
        return place + way + time
    }
    private func cleanTransferTitle(_ value: String) -> String {
        value.components(separatedBy: " · marche").first ?? value
    }
    private func transferWalkDetail(_ value: String, toward boardingStop: String?) -> String? {
        guard value.localizedCaseInsensitiveContains("marche") else { return "Change de ligne ici" }
        let minutes: String
        if let marker = value.range(of: "marche", options: .caseInsensitive) {
            minutes = String(value[marker.lowerBound...]).components(separatedBy: " · ").first ?? "Marche"
        } else { minutes = "Marche" }
        if let boardingStop, !boardingStop.isEmpty { return "\(minutes) → \(boardingStop)" }
        return minutes
    }

    private func setupPrompt(icon: String, title: String, detail: String, button: String, action: @escaping () -> Void) -> some View {
        VStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 27, weight: .semibold)).foregroundStyle(Palette.purple)
            Text(title).font(.system(size: 20, weight: .bold, design: .rounded))
            Text(detail).font(.system(size: 13)).foregroundStyle(Palette.muted)
            Button {
                playInteractionFeedback()
                action()
            } label: {
                Text(button).font(.system(size: 13, weight: .bold)).foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
                .background(Palette.purple, in: RoundedRectangle(cornerRadius: 13))
                .buttonStyle(MobiGoPressStyle())
        }.padding(18).frame(maxWidth: .infinity).background(Palette.card, in: RoundedRectangle(cornerRadius: 20))
    }

    private var brandMark: some View {
        HStack(spacing: 8) {
            Image(systemName: "bus.fill")
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 28, height: 28)
                .background(Palette.purple.gradient, in: RoundedRectangle(cornerRadius: 8))
            HStack(spacing: 0) {
                Text("Mobi")
                Text("Go").foregroundStyle(Palette.purple)
            }
            .font(.system(size: 16, weight: .bold))
        }
    }

    private var header: some View {
        HStack(spacing: 11) {
            brandMark
            Spacer()
            Button { playInteractionFeedback(); withAnimation(reduceMotion ? nil : .spring(response: 0.32, dampingFraction: 0.82)) { showingAlertsInfo.toggle() } } label: {
                Image(systemName: showingAlertsInfo ? "bell.badge.fill" : "bell")
                    .font(.system(size: 15, weight: .semibold)).foregroundStyle(showingAlertsInfo ? Palette.purple : Palette.text)
                    .contentTransition(reduceMotion ? .identity : .opacity)
                    .frame(width: 36, height: 36).background(Palette.card, in: Circle())
            }
            .buttonStyle(MobiGoPressStyle())
            .accessibilityLabel(showingAlertsInfo ? "Masquer les alertes" : "Afficher les alertes")
            .accessibilityHint("Affiche ou masque les informations de ton trajet")
        }
    }

    private var alertsCard: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: routeNotificationMessage.isEmpty ? "bell.badge" : "bell.badge.fill")
                .font(.system(size: 15, weight: .semibold)).foregroundStyle(Palette.purple)
            VStack(alignment: .leading, spacing: 3) {
                Text("Alertes trajet").font(.system(size: 12, weight: .bold))
                Text(routeNotificationMessage.isEmpty
                     ? "Aucun rappel de correspondance prévu."
                     : routeNotificationMessage)
                    .font(.system(size: 10)).foregroundStyle(Palette.muted)
            }
            Spacer(minLength: 0)
            Button { playInteractionFeedback(); withAnimation(reduceMotion ? nil : .spring(response: 0.32, dampingFraction: 0.82)) { showingAlertsInfo = false } } label: {
                Image(systemName: "xmark").font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.muted)
            }
            .buttonStyle(MobiGoPressStyle())
            .accessibilityLabel("Fermer les alertes")
        }
        .padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 15))
    }

    private var search: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(homeAddress.isEmpty ? "On prépare ton trajet" : "Où veux-tu aller ?")
                .font(.system(size: 27, weight: .bold, design: .rounded))
            Text(homeAddress.isEmpty ? "Ajoute ton adresse, puis ta destination." : "Choisis une adresse ou un lieu.")
                .font(.system(size: 14)).foregroundStyle(Palette.muted)
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass").foregroundStyle(Palette.muted)
                TextField("Destination…", text: $destination)
                    .font(.system(size: 13)).tint(Palette.purple)
                    .submitLabel(.search)
                    .onSubmit { openDestinationSearch() }
                Button { openDestinationSearch() } label: {
                    Image(systemName: "arrow.right.circle.fill").foregroundStyle(.white).font(.system(size: 20))
                }.buttonStyle(MobiGoPressStyle()).accessibilityLabel("Chercher un trajet")
            }
            .padding(.horizontal, 14).frame(height: 48)
            .background(LinearGradient(colors: [Palette.elevated, Palette.highlightedCard], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Palette.purple.opacity(0.45), lineWidth: 1))
            .padding(.top, 8)
        }
    }

    private var originSetupCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("D’où pars-tu ?", systemImage: "house.fill").font(.system(size: 14, weight: .bold))
            TextField("Ton adresse (ex. rue et commune)", text: $homeAddressQuery)
                .font(.system(size: 13)).textInputAutocapitalization(.words).autocorrectionDisabled()
                .submitLabel(.search).onSubmit { Task { await searchHomeAddress() } }
                .padding(.horizontal, 12).frame(height: 44).background(Palette.elevated, in: RoundedRectangle(cornerRadius: 12))
                Button { playInteractionFeedback(); Task { await searchHomeAddress() } } label: {
                Label(isSearchingHomeAddress ? "Recherche…" : "Enregistrer mon domicile", systemImage: "magnifyingglass")
                    .font(.system(size: 12, weight: .bold)).frame(maxWidth: .infinity, minHeight: 42)
                    .background(Palette.purple, in: RoundedRectangle(cornerRadius: 12))
            }.disabled(isSearchingHomeAddress || homeAddressQuery.trimmingCharacters(in: .whitespacesAndNewlines).count < 3)
            ForEach(homeAddressResults) { place in
                Button { playInteractionFeedback(); Task { await selectHomeAddress(place) } } label: {
                    HStack { Image(systemName: "mappin.and.ellipse").foregroundStyle(Palette.purple)
                        VStack(alignment: .leading) { Text(place.name).foregroundStyle(Palette.text); Text(place.subtitle).font(.caption).foregroundStyle(Palette.muted) }
                        Spacer(); Image(systemName: "chevron.right").font(.caption).foregroundStyle(Palette.muted) }
                }.buttonStyle(MobiGoPressStyle())
            }
            if !stopSearchMessage.isEmpty { Text(stopSearchMessage).font(.system(size: 10)).foregroundStyle(Palette.muted) }
            Button { playInteractionFeedback(); Task { await findNearbyOriginStop() } } label: {
                Label(isFindingNearbyOrigin ? "Recherche autour de moi…" : "Ou utiliser ma position", systemImage: "location.fill")
                    .font(.system(size: 11, weight: .semibold)).foregroundStyle(Palette.muted)
            }.disabled(isFindingNearbyOrigin)
        }
        .padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))
    }

    private var routeLoadingCard: some View {
        HStack(spacing: 11) {
            RefreshPulse(reduceMotion: reduceMotion, color: Palette.purple)
            Text("Je prépare ton trajet et ses correspondances…")
                .font(.system(size: 12, weight: .semibold)).foregroundStyle(Palette.muted)
            Spacer(minLength: 0)
        }
        .padding(14).background(Palette.card, in: RoundedRectangle(cornerRadius: 16))
        .transition(reduceMotion ? .opacity : .move(edge: .top).combined(with: .opacity))
    }

    private var routePresentationKey: String { journeys.first?.id ?? "" }

    private var routeStatusCard: some View {
        HStack(spacing: 10) {
            Image(systemName: "exclamationmark.circle.fill").foregroundStyle(Palette.pink)
            Text(journeyStatus).font(.system(size: 11, weight: .medium)).foregroundStyle(Palette.muted)
                .lineLimit(3)
            Spacer(minLength: 0)
        }
        .padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 16))
    }

    private var plannedRouteCard: some View {
        let trip = journeys[0]
        let lineColors = journeyLineColors(for: trip)
        let arrivalAtDestination = estimatedArrival(for: trip).addingTimeInterval(TimeInterval(finalWalkMinutes * 60))
        let firstDelay = liveDelayByLeg[legKey(stopID: deLijnStopID, line: trip.line, time: trip.departure.addingTimeInterval(TimeInterval(-trip.delayMinutes * 60)), entityID: trip.firstLegEntityID ?? deLijnEntityID) ]
            ?? (trip.hasRealtimePrediction ? trip.delayMinutes : nil)
        let firstScheduledDeparture = trip.departure.addingTimeInterval(TimeInterval(-trip.delayMinutes * 60))
        let firstDeparture = firstScheduledDeparture.addingTimeInterval(TimeInterval((firstDelay ?? trip.delayMinutes) * 60))
        return VStack(alignment: .leading, spacing: 11) {
            HStack {
                Label("TON TRAJET", systemImage: "sparkles").font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.muted)
                Spacer()
                if isSearchingJourneys { ProgressView().controlSize(.small).tint(Palette.purple) }
                Button { playInteractionFeedback(); withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) { navigateToTab(2) } } label: {
                    Image(systemName: "map.fill").font(.system(size: 12, weight: .bold)).foregroundStyle(Palette.purple)
                }.accessibilityLabel("Voir la carte")
                Button { playInteractionFeedback(); withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) { navigateToTab(4) } } label: {
                    Image(systemName: "pencil").font(.system(size: 12, weight: .bold)).foregroundStyle(Palette.purple)
                }.accessibilityLabel("Changer de trajet")
                Button {
                    playInteractionFeedback()
                    Task {
                        if let place = selectedPlace { await selectDestinationPlace(place) }
                        else if let destinationStop = selectedDestination { await findJourneys(to: destinationStop) }
                    }
                } label: {
                    Image(systemName: "arrow.clockwise").font(.system(size: 12, weight: .bold)).foregroundStyle(Palette.purple)
                }.accessibilityLabel("Actualiser le trajet")
            }
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text("Arrivée").font(.system(size: 13, weight: .medium)).foregroundStyle(Palette.muted)
                Text(arrivalAtDestination, format: .dateTime.hour().minute()).font(.system(size: 27, weight: .bold, design: .rounded))
                Spacer(minLength: 0)
                if let firstDelay, firstDelay > 1 {
                    Label("Retard +\(firstDelay) min", systemImage: "clock.fill")
                        .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.pink)
                } else if let firstDelay, firstDelay < -1 {
                    Label("Avance \(-firstDelay) min", systemImage: "clock")
                        .font(.system(size: 10, weight: .bold)).foregroundStyle(Color(red: 1, green: 0.74, blue: 0.28))
                } else if firstDelay != nil {
                    Label("À l’heure", systemImage: "checkmark.circle.fill")
                        .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.green)
                } else {
                    Label("Temps réel indisponible", systemImage: "clock")
                        .font(.system(size: 9, weight: .semibold)).foregroundStyle(Palette.muted)
                }
            }
            Text("Objectif · \(arrivalTargetDate.formatted(date: .omitted, time: .shortened))")
                .font(.system(size: 10, weight: .semibold)).foregroundStyle(Palette.muted)
            VStack(alignment: .leading, spacing: 6) {
                let lineColors = journeyLineColors(for: trip)
                if homeWalkMinutes > 0 {
                    Label("\(homeWalkMinutes) min à pied → \(stopName)", systemImage: "figure.walk")
                        .font(.system(size: 10, weight: .medium)).foregroundStyle(Palette.muted).lineLimit(1)
                }
                routeLegLabel(line: trip.line, direction: trip.lineDirection, delay: firstDelay, color: lineColors[0])
                if let transfer = trip.transferStop {
                    transferRow(transfer, departure: trip.secondDeparture)
                }
                if let line = trip.secondLine {
                    let delay = trip.secondDeparture.flatMap { liveDelayByLeg[legKey(stopID: trip.transferStopID ?? "", line: line, time: $0, entityID: trip.secondLegEntityID ?? deLijnEntityID)] }
                    routeLegLabel(line: line, direction: trip.secondLineDirection ?? "", delay: delay, color: lineColors[1])
                }
                if let transfer = trip.secondTransferStop {
                    transferRow(transfer, departure: trip.thirdDeparture)
                }
                if let line = trip.thirdLine {
                    let delay = trip.thirdDeparture.flatMap { liveDelayByLeg[legKey(stopID: trip.secondTransferStopID ?? "", line: line, time: $0, entityID: trip.thirdLegEntityID ?? deLijnEntityID)] }
                    routeLegLabel(line: line, direction: trip.thirdLineDirection ?? "", delay: delay, color: lineColors[2])
                }
                if finalWalkMinutes > 0 {
                    Label("\(finalWalkMinutes) min à pied → \(destinationName)", systemImage: "figure.walk")
                        .font(.system(size: 10, weight: .medium)).foregroundStyle(Palette.muted)
                }
            }
            HStack {
                HStack(spacing: 5) {
                    Image(systemName: vehicleIcon(trip.firstLegMode))
                        .foregroundStyle(lineColors[0])
                    Text("\(trip.line) · \(firstDeparture.formatted(date: .omitted, time: .shortened))")
                        .foregroundStyle(Palette.muted)
                }
                .font(.system(size: 10, weight: .semibold))
                .accessibilityElement(children: .ignore)
                .accessibilityLabel("Départ \(vehicleName(trip.firstLegMode)) \(trip.line) à \(firstDeparture.formatted(date: .omitted, time: .shortened))")
                Spacer()
                Button { playInteractionFeedback(); Task { await toggleTripTracking() } } label: {
                    Label(locationProvider.isTripTracking ? "Arrêter" : "Me suivre",
                          systemImage: locationProvider.isTripTracking ? "location.slash.fill" : "location.fill")
                        .font(.system(size: 10, weight: .bold))
                }.foregroundStyle(Palette.purple)
                Button("Détails ›") { playInteractionFeedback(); navigateToTab(4) }.font(.system(size: 11, weight: .bold)).foregroundStyle(Palette.purple)
            }
            if !trackingMessage.isEmpty {
                Label(trackingMessage, systemImage: locationProvider.isTripTracking ? "location.fill" : "location.circle")
                    .font(.system(size: 10, weight: .medium)).foregroundStyle(Palette.muted).lineLimit(2)
            }
        }
        .padding(15).background(LinearGradient(colors: [Palette.highlightedCard, Palette.card], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 19))
        .overlay(RoundedRectangle(cornerRadius: 19).stroke(Palette.purple.opacity(0.28), lineWidth: 1))
        .animation(reduceMotion ? nil : .spring(response: 0.36, dampingFraction: 0.88), value: journeyTimelineMotionKey)
    }

    private var journeyTimelineMotionKey: String {
        guard let trip = journeys.first else { return "" }
        return [trip.id, trip.line, trip.firstBoardStopName ?? "", trip.transferStop ?? "",
                trip.secondLine ?? "", trip.secondBoardStopName ?? "", trip.secondTransferStop ?? "",
                trip.thirdLine ?? "", trip.thirdBoardStopName ?? "", destinationName,
                String(homeWalkMinutes), String(finalWalkMinutes)].joined(separator: "|")
    }

    private func routeLegLabel(line: String, direction: String, delay: Int?, color: Color) -> some View {
        HStack(spacing: 7) {
            Text(line).font(.system(size: 11, weight: .bold)).padding(.horizontal, 8).padding(.vertical, 5)
                .foregroundStyle(.white).background(color, in: RoundedRectangle(cornerRadius: 7))
            Text("→ \(direction.isEmpty ? destinationName : direction)").font(.system(size: 11, weight: .semibold)).lineLimit(1)
            Spacer(minLength: 2)
            if let delay {
                Text(delay > 1 ? "+\(delay) min" : delay < -1 ? "−\(-delay) min" : "OK")
                    .font(.system(size: 9, weight: .bold)).foregroundStyle(delay > 1 ? Palette.pink : delay < -1 ? Color.orange : Palette.green)
                    .contentTransition(reduceMotion ? .identity : .numericText())
                    .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: delay)
            } else {
                Text("—").font(.system(size: 9, weight: .bold)).foregroundStyle(Palette.muted)
            }
        }
    }

    private func transferRow(_ stop: String, departure: Date?) -> some View {
        HStack(spacing: 7) {
            Image(systemName: "arrow.triangle.branch").foregroundStyle(Palette.purple)
            Text(stop).lineLimit(1)
            Spacer(minLength: 2)
            if let departure { Text("↗ \(departure.formatted(date: .omitted, time: .shortened))") }
        }
        .font(.system(size: 10, weight: .semibold)).foregroundStyle(Palette.muted)
    }

    @MainActor
    private func toggleTripTracking() async {
        if locationProvider.isTripTracking {
            locationProvider.stopTripTracking()
            tripTrackingEnabled = false
            trackingMessage = "Suivi arrêté."
            return
        }
        do {
            try await locationProvider.startTripTracking()
            tripTrackingEnabled = true
            trackingMessage = locationProvider.isBackgroundTracking
                ? "Suivi écran verrouillé actif · retards, correspondances et arrivée. Garde MobiGo ouverte."
                : "Suivi actif tant que MobiGo reste ouverte. Arrête-le à l’arrivée."
            userTrackingMode = .follow
            navigateToTab(2)
        } catch {
            trackingMessage = error.localizedDescription
        }
    }

    @MainActor
    private func checkTransferProximity() async {
        guard locationProvider.isTripTracking, let location = locationProvider.latestLocation,
              let trip = journeys.first else { return }

        if destinationLatitude != 0, destinationLongitude != 0 {
            let destination = CLLocation(latitude: destinationLatitude, longitude: destinationLongitude)
            if location.distance(from: destination) <= 100 {
                locationProvider.stopTripTracking()
                tripTrackingEnabled = false
                trackingMessage = "Arrivé·e · suivi arrêté."
                await AlarmScheduler.shared.notifyTripArrived(destinationName: destinationName)
                return
            }
        }

        let transfers: [(String, String, String, String, String, Date)] = [
            (trip.id + "-change-1", trip.transferStopID ?? "", trip.transferStop ?? "", trip.firstLegEntityID ?? deLijnEntityID, trip.secondLine ?? "", trip.secondDeparture ?? .distantFuture),
            (trip.id + "-change-2", trip.secondTransferStopID ?? "", trip.secondTransferStop ?? "", trip.secondLegEntityID ?? deLijnEntityID, trip.thirdLine ?? "", trip.thirdDeparture ?? .distantFuture)
        ]
        for (id, stopID, stopName, entityID, nextLine, departure) in transfers where !stopID.isEmpty && !nextLine.isEmpty && !notifiedTransferIDs.contains(id) {
            do {
                let coordinate: CLLocationCoordinate2D
                let cacheKey = transferCoordinateKey(stopID: stopID, entityID: entityID)
                if let cached = transferCoordinates[cacheKey] {
                    coordinate = cached
                } else {
                    let fetched = try await resolvedStopCoordinate(stopID: stopID, entityID: entityID)
                    coordinate = CLLocationCoordinate2D(latitude: fetched.latitude, longitude: fetched.longitude)
                    transferCoordinates[cacheKey] = coordinate
                }
                let stopLocation = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
                guard location.distance(from: stopLocation) <= 250 else { continue }
                notifiedTransferIDs.insert(id)
                await AlarmScheduler.shared.notifyTransferApproaching(stopName: stopName, nextLine: nextLine,
                    direction: trip.secondLine == nextLine ? (trip.secondLineDirection ?? trip.destination) : (trip.thirdLineDirection ?? trip.destination),
                    departure: departure)
            } catch {
                // The scheduled time reminder remains the fallback if a stop coordinate is unavailable.
            }
        }
    }

    private func transferCoordinateKey(stopID: String, entityID: String) -> String {
        "\(entityID.lowercased())|\(stopID)"
    }

    private func legKey(stopID: String, line: String, time: Date, entityID: String) -> String {
        "\(entityID)|\(stopID)|\(line)|\(Int(time.timeIntervalSince1970 / 60))"
    }

    private func estimatedArrival(for trip: DeLijnJourney) -> Date {
        let firstScheduled = trip.departure.addingTimeInterval(TimeInterval(-trip.delayMinutes * 60))
        let firstEntity = trip.firstLegEntityID ?? deLijnEntityID
        let secondEntity = trip.secondLegEntityID ?? deLijnEntityID
        let thirdEntity = trip.thirdLegEntityID ?? deLijnEntityID
        let firstCurrent = liveDelayByLeg[legKey(stopID: deLijnStopID, line: trip.line, time: firstScheduled, entityID: firstEntity)]
            ?? (trip.hasRealtimePrediction ? trip.delayMinutes : 0)
        let firstCorrection = trip.secondLine == nil
            ? firstCurrent - (trip.hasRealtimePrediction ? trip.delayMinutes : 0)
            : firstCurrent
        let secondCorrection: Int
        if let line = trip.secondLine, let time = trip.secondDeparture, let stopID = trip.transferStopID {
            secondCorrection = liveDelayByLeg[legKey(stopID: stopID, line: line, time: time, entityID: secondEntity)] ?? 0
        } else { secondCorrection = 0 }
        let thirdCorrection: Int
        if let line = trip.thirdLine, let time = trip.thirdDeparture, let stopID = trip.secondTransferStopID {
            thirdCorrection = liveDelayByLeg[legKey(stopID: stopID, line: line, time: time, entityID: thirdEntity)] ?? 0
        } else { thirdCorrection = 0 }
        return trip.arrival.addingTimeInterval(TimeInterval((firstCorrection + secondCorrection + thirdCorrection) * 60))
    }

    @MainActor
    private func refreshJourneyPredictions(for trip: DeLijnJourney) async {
        let now = Date.now
        if let lastRefresh = predictionRefreshDatesByJourney[trip.id],
           now.timeIntervalSince(lastRefresh) < 45 { return }
        guard !isRefreshingJourneyPredictions else { return }
        predictionRefreshDatesByJourney[trip.id] = now
        isRefreshingJourneyPredictions = true
        defer { isRefreshingJourneyPredictions = false }
        var targets: [(key: String, stopID: String, line: String, time: Date, entityID: String, direction: String, departure: Date)] = []
        let firstScheduled = trip.departure.addingTimeInterval(TimeInterval(-trip.delayMinutes * 60))
        let firstEntity = trip.firstLegEntityID ?? deLijnEntityID
        let secondEntity = trip.secondLegEntityID ?? deLijnEntityID
        let thirdEntity = trip.thirdLegEntityID ?? deLijnEntityID
        targets.append((legKey(stopID: deLijnStopID, line: trip.line, time: firstScheduled, entityID: firstEntity), deLijnStopID, trip.line, firstScheduled, firstEntity, trip.lineDirection, trip.departure))
        if let line = trip.secondLine, let time = trip.secondDeparture, let stopID = trip.transferStopID {
            targets.append((legKey(stopID: stopID, line: line, time: time, entityID: secondEntity), stopID, line, time, secondEntity, trip.secondLineDirection ?? trip.destination, time))
        }
        if let line = trip.thirdLine, let time = trip.thirdDeparture, let stopID = trip.secondTransferStopID {
            targets.append((legKey(stopID: stopID, line: line, time: time, entityID: thirdEntity), stopID, line, time, thirdEntity, trip.thirdLineDirection ?? trip.destination, time))
        }
        let updates = await withTaskGroup(of: (String, Int?).self) { group in
            for target in targets {
                group.addTask {
                    let delay: Int?
                    if target.entityID.lowercased() == "stib" {
                        let live = try? await StibClient.shared.departures(stopID: target.stopID, count: 30)
                        let matching = live?.filter {
                            $0.lineNumber == target.line && abs($0.realtimeTime.timeIntervalSince(target.time)) <= 20 * 60
                        }.min {
                            abs($0.realtimeTime.timeIntervalSince(target.time)) < abs($1.realtimeTime.timeIntervalSince(target.time))
                        }
                        delay = matching.map { Int(($0.realtimeTime.timeIntervalSince(target.time) / 60).rounded()) }
                    } else {
                        do {
                            delay = try await DeLijnClient.shared.realtimeDelay(
                                stopID: target.stopID, entityID: target.entityID,
                                line: target.line, scheduledTime: target.time)
                        } catch { delay = nil }
                    }
                    return (target.key, delay)
                }
            }
            var values: [String: Int] = [:]
            for await (key, delay) in group {
                if let delay { values[key] = delay }
            }
            return values
        }
        let previousUpdates = liveDelayByLeg
        for target in targets {
            guard let newDelay = updates[target.key] else { continue }
            let previousDelay = previousUpdates[target.key]
                ?? (target.line == trip.line && trip.hasRealtimePrediction ? trip.delayMinutes : 0)
            let becameEarly = newDelay < -1 && newDelay < previousDelay - 1
            let becameDelayed = newDelay > 1 && newDelay > previousDelay + 1
            if abs(newDelay) <= 1 {
                announcedServiceDelayByLeg.removeValue(forKey: target.key)
                continue
            }
            let shouldAnnounce: Bool
            if let announcedDelay = announcedServiceDelayByLeg[target.key] {
                let changedStatus = (newDelay < -1) != (announcedDelay < -1)
                let materiallyWorse = newDelay > 1
                    ? newDelay >= announcedDelay + 5
                    : newDelay <= announcedDelay - 5
                shouldAnnounce = changedStatus || materiallyWorse
            } else {
                shouldAnnounce = becameEarly || becameDelayed
            }
            guard shouldAnnounce else { continue }
            await AlarmScheduler.shared.notifyServiceChange(line: target.line, direction: target.direction,
                delayMinutes: newDelay, departure: target.departure.addingTimeInterval(TimeInterval(newDelay * 60)))
            announcedServiceDelayByLeg[target.key] = newDelay
        }
        let didChange = updates != previousUpdates
        liveDelayByLeg = updates
        if alarmEnabled, let firstTarget = targets.first, let liveFirstDelay = updates[firstTarget.key] {
            let liveDeparture = firstTarget.time.addingTimeInterval(TimeInterval(liveFirstDelay * 60))
            if liveDeparture > .now {
                let liveHour = Calendar.current.component(.hour, from: liveDeparture)
                let liveMinute = Calendar.current.component(.minute, from: liveDeparture)
                let liveMinuteOfDay = liveHour * 60 + liveMinute
                let scheduledMinuteOfDay = departureHour * 60 + departureMinute
                var change = liveMinuteOfDay - scheduledMinuteOfDay
                if change > 720 { change -= 1440 }
                if change < -720 { change += 1440 }
                if abs(change) >= 1 {
                    departureHour = liveHour
                    departureMinute = liveMinute
                    do {
                        try await scheduleAlarm()
                        alarmMessage = change > 0
                            ? "Réveil repoussé de \(change) min · retard du bus."
                            : "Réveil avancé de \(-change) min · bus en avance."
                    } catch {
                        alarmEnabled = false
                        alarmMessage = error.localizedDescription
                    }
                }
            }
        }
        if scheduledReminderTripID != trip.id || didChange {
            await refreshTransferReminders(for: trip)
            scheduledReminderTripID = trip.id
        }
        lastRouteRefresh = .now
    }

    @MainActor
    private func refreshUpcomingJourneyIfNeeded() async {
        guard let trip = journeys.first else { return }
        let earliestReachableDeparture = Date.now.addingTimeInterval(TimeInterval(homeWalkMinutes * 60))
        if trip.departure <= earliestReachableDeparture {
            if let place = selectedPlace {
                await selectDestinationPlace(place, prepareAlarm: alarmEnabled)
            } else if let stop = selectedDestination {
                await findJourneys(to: stop, prepareAlarm: alarmEnabled)
            }
            return
        }
        await refreshJourneyPredictions(for: trip)
    }

    @MainActor
    private func refreshTransferReminders(for trip: DeLijnJourney) async {
        let firstScheduled = trip.departure.addingTimeInterval(TimeInterval(-trip.delayMinutes * 60))
        let firstKey = legKey(stopID: deLijnStopID, line: trip.line, time: firstScheduled, entityID: trip.firstLegEntityID ?? deLijnEntityID)
        let initialFirstDelay = trip.hasRealtimePrediction ? trip.delayMinutes : 0
        let currentFirstDelay = liveDelayByLeg[firstKey] ?? initialFirstDelay
        var reminders: [BusMindTransferReminder] = []

        if let stop = trip.transferStop, let stopID = trip.transferStopID, let arrival = trip.transferArrival,
           let line = trip.secondLine, let departure = trip.secondDeparture {
            let adjustedArrival = arrival.addingTimeInterval(TimeInterval((currentFirstDelay - initialFirstDelay) * 60))
            let nextKey = legKey(stopID: stopID, line: line, time: departure, entityID: trip.secondLegEntityID ?? deLijnEntityID)
            let nextDelay = liveDelayByLeg[nextKey] ?? 0
            reminders.append(BusMindTransferReminder(id: "\(trip.id)-change-1", arrivalAtStop: adjustedArrival,
                stopName: stop, nextLine: line, nextDirection: trip.secondLineDirection ?? trip.destination,
                nextDeparture: departure.addingTimeInterval(TimeInterval(nextDelay * 60))))
        }
        if let stop = trip.secondTransferStop, let stopID = trip.secondTransferStopID, let arrival = trip.secondTransferArrival,
           let line = trip.thirdLine, let departure = trip.thirdDeparture {
            let previousLineDelay: Int
            if let line = trip.secondLine, let secondDeparture = trip.secondDeparture, let firstStop = trip.transferStopID {
                previousLineDelay = liveDelayByLeg[legKey(stopID: firstStop, line: line, time: secondDeparture, entityID: trip.secondLegEntityID ?? deLijnEntityID)] ?? 0
            } else { previousLineDelay = 0 }
            let nextKey = legKey(stopID: stopID, line: line, time: departure, entityID: trip.thirdLegEntityID ?? deLijnEntityID)
            let nextDelay = liveDelayByLeg[nextKey] ?? 0
            reminders.append(BusMindTransferReminder(id: "\(trip.id)-change-2", arrivalAtStop: arrival.addingTimeInterval(TimeInterval(previousLineDelay * 60)),
                stopName: stop, nextLine: line, nextDirection: trip.thirdLineDirection ?? trip.destination,
                nextDeparture: departure.addingTimeInterval(TimeInterval(nextDelay * 60))))
        }

        do {
            try await AlarmScheduler.shared.scheduleTransferReminders(reminders)
            routeNotificationMessage = reminders.isEmpty ? "" : "Rappels prévus avant chaque correspondance."
        } catch {
            routeNotificationMessage = "Active les notifications pour recevoir les rappels de correspondance."
        }
    }

    private var quickPlaces: some View {
        HStack(spacing: 10) {
            place(icon: "house.fill", title: "Maison")
            place(icon: "graduationcap.fill", title: "École")
            place(icon: "briefcase.fill", title: "Travail")
            place(icon: "star.fill", title: "Favoris")
        }
    }

    private func place(icon: String, title: String) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon).font(.system(size: 17))
            Text(title).font(.system(size: 11, weight: .medium))
        }
        .foregroundStyle(Palette.text)
        .frame(maxWidth: .infinity).frame(height: 70)
        .background(LinearGradient(colors: [Palette.elevated, Palette.card], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 16))
    }

    private var departureCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Prochain passage").font(.system(size: 17, weight: .bold, design: .rounded))
                Spacer()
                Text(networkLabel(deLijnEntityID) + (["tec", "letec", "nmbs", "sncb"].contains(deLijnEntityID.lowercased()) ? " · HORAIRES" : " · EN DIRECT"))
                    .font(.system(size: 8, weight: .heavy)).tracking(0.4)
                    .foregroundStyle(Palette.purple)
                Image(systemName: "clock.arrow.circlepath").font(.system(size: 13, weight: .semibold)).foregroundStyle(Palette.muted)
            }
            if !stopName.isEmpty {
                Text(stopName).font(.system(size: 10, weight: .medium)).foregroundStyle(Palette.muted).lineLimit(1)
            }
            if let next = departures.first {
                HStack(spacing: 11) {
                    Image(systemName: vehicleIcon(next.vehicleMode)).font(.system(size: 15)).foregroundStyle(.white)
                        .frame(width: 34, height: 34).background(Palette.purple, in: RoundedRectangle(cornerRadius: 11))
                    Text(next.lineNumber).font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Palette.transitLineText("\(next.entityID ?? deLijnEntityID)-\(next.vehicleMode ?? "BUS")-\(next.lineNumber)", lightMode: appTheme == "light"))
                        .padding(.horizontal, 9).padding(.vertical, 6)
                        .background(Palette.transitLine("\(next.entityID ?? deLijnEntityID)-\(next.vehicleMode ?? "BUS")-\(next.lineNumber)", lightMode: appTheme == "light"), in: RoundedRectangle(cornerRadius: 8))
                    Image(systemName: "arrow.right").foregroundStyle(Palette.muted)
                    Text(next.destination).font(.system(size: 13, weight: .semibold)).lineLimit(1)
                    Spacer(minLength: 2)
                    VStack(alignment: .trailing, spacing: 3) {
                        Text(next.realtimeTime, format: .dateTime.hour().minute()).font(.system(size: 20, weight: .bold, design: .rounded))
                        liveCountdownText(to: next.realtimeTime, font: .system(size: 10), color: Palette.muted)
                    }
                }
            } else if let trip = journeys.first {
                HStack(spacing: 11) {
                    Image(systemName: vehicleIcon(trip.firstLegMode)).font(.system(size: 15)).foregroundStyle(.white)
                        .frame(width: 34, height: 34).background(Palette.purple, in: RoundedRectangle(cornerRadius: 11))
                    Text(trip.line).font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Palette.transitLineText("\(trip.firstLegEntityID ?? deLijnEntityID)-\(trip.firstLegMode ?? "BUS")-\(trip.line)", lightMode: appTheme == "light"))
                        .padding(.horizontal, 9).padding(.vertical, 6)
                        .background(Palette.transitLine("\(trip.firstLegEntityID ?? deLijnEntityID)-\(trip.firstLegMode ?? "BUS")-\(trip.line)", lightMode: appTheme == "light"), in: RoundedRectangle(cornerRadius: 8))
                    Image(systemName: "arrow.right").foregroundStyle(Palette.muted)
                    Text(trip.lineDirection.isEmpty ? trip.destination : trip.lineDirection)
                        .font(.system(size: 13, weight: .semibold)).lineLimit(1)
                    Spacer(minLength: 2)
                    VStack(alignment: .trailing, spacing: 3) {
                        Text(trip.departure, format: .dateTime.hour().minute())
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                        liveCountdownText(to: trip.departure, font: .system(size: 10), color: Palette.muted)
                    }
                }
            } else {
                Button {
                    if homeAddress.isEmpty { navigateToTab(4); isEditingHomeAddress = true }
                    else { Task { await refreshDepartures() } }
                } label: {
                    Label(homeAddress.isEmpty ? "Indiquer mon domicile" : "Actualiser les départs", systemImage: "mappin.and.ellipse")
                        .font(.system(size: 13, weight: .semibold)).foregroundStyle(Palette.text)
                        .frame(maxWidth: .infinity, minHeight: 54).background(Palette.elevated, in: RoundedRectangle(cornerRadius: 14))
                }
            }
            Button {
                homeAddressQuery = displayHomeAddress
                isEditingHomeAddress = true
                navigateToTab(4)
            } label: {
                Label(homeAddress.isEmpty ? "Indiquer mon domicile" : "Depuis \(displayHomeAddress) · modifier", systemImage: "house.fill")
                    .font(.system(size: 11, weight: .semibold)).foregroundStyle(Palette.text)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }.buttonStyle(MobiGoPressStyle())
            HStack(spacing: 6) {
                let hasPlannedFallback = departures.isEmpty && !journeys.isEmpty
                let hasRealtime = departures.contains(where: \.hasRealtimePrediction)
                let statusColor = departures.isEmpty
                    ? (hasPlannedFallback ? Color.orange : Palette.pink)
                    : (hasRealtime && !hasFreshDeparturePredictions ? Color.orange : Palette.green)
                Circle().fill(statusColor).frame(width: 7, height: 7)
                Text(departures.isEmpty
                    ? (hasPlannedFallback ? "Horaire prévu · temps réel indisponible" : (apiStatus.isEmpty ? "En attente des départs" : apiStatus))
                    : hasRealtime
                        ? (hasFreshDeparturePredictions ? "Prédictions en temps réel" : "Données anciennes · actualise")
                        : "Horaires chargés")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(statusColor).lineLimit(1)
                Spacer()
                refreshDeparturesButton
            }
        }
        .padding(15)
        .background(LinearGradient(colors: [Palette.highlightedCard, Palette.card], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Palette.muted.opacity(0.18), lineWidth: 1))
    }

    private var liveDeparturesCard: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Label("PROCHAINS DÉPARTS", systemImage: "dot.radiowaves.left.and.right")
                    .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.muted)
                Spacer()
                if departures.count > 1 {
                    Button(showAllDepartures ? "Moins" : "Tout voir") {
                        playInteractionFeedback()
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.18)) { showAllDepartures.toggle() }
                    }
                    .font(.system(size: 9, weight: .semibold)).foregroundStyle(Palette.purple)
                }
                if !departures.isEmpty {
                    Text(nextDepartureHasFreshPrediction ? "En direct" : "Horaire")
                        .font(.system(size: 8, weight: .bold))
                        .foregroundStyle(nextDepartureHasFreshPrediction ? Palette.green : Palette.muted)
                        .padding(.horizontal, 7).padding(.vertical, 4)
                        .background(Palette.green.opacity(nextDepartureHasFreshPrediction ? 0.12 : 0.08), in: Capsule())
                }
                refreshDeparturesButton
            }
            if departures.isEmpty, ["tec", "letec", "nmbs", "sncb"].contains(deLijnEntityID.lowercased()),
               let trip = journeys.first {
                HStack(spacing: 9) {
                    Image(systemName: vehicleIcon(trip.firstLegMode)).font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(Palette.muted).frame(width: 18)
                    Text(trip.line).font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Palette.transitLineText("\(trip.firstLegEntityID ?? deLijnEntityID)-\(trip.firstLegMode ?? "BUS")-\(trip.line)", lightMode: appTheme == "light"))
                        .padding(.horizontal, 9).padding(.vertical, 6)
                        .background(Palette.transitLine("\(trip.firstLegEntityID ?? deLijnEntityID)-\(trip.firstLegMode ?? "BUS")-\(trip.line)", lightMode: appTheme == "light"), in: RoundedRectangle(cornerRadius: 7))
                    Text(trip.lineDirection.isEmpty ? trip.destination : trip.lineDirection)
                        .font(.system(size: 12, weight: .medium)).lineLimit(2).minimumScaleFactor(0.78)
                        .fixedSize(horizontal: false, vertical: true).layoutPriority(1)
                    Spacer()
                    VStack(alignment: .trailing, spacing: 2) {
                        Text(trip.departure, format: .dateTime.hour().minute())
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                        Text("Départ prévu · temps réel à confirmer")
                            .font(.system(size: 9, weight: .medium)).foregroundStyle(Palette.muted)
                    }
                }.padding(.vertical, 3)
            } else if departures.isEmpty {
                HStack(spacing: 8) {
                    Image(systemName: "clock").font(.system(size: 12, weight: .semibold)).foregroundStyle(Palette.muted)
                    Text(apiStatus.isEmpty ? "Aucun passage disponible" : apiStatus)
                        .font(.system(size: 10, weight: .medium)).foregroundStyle(Palette.muted).lineLimit(1)
                }.padding(.vertical, 5)
            } else {
                ForEach(Array(departures.prefix(showAllDepartures ? 5 : 1).enumerated()), id: \.element.id) { entry in
                    let passage = entry.element
                    HStack(spacing: 9) {
                        Image(systemName: vehicleIcon(passage.vehicleMode)).font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(Palette.muted).frame(width: 18)
                        Text(passage.lineNumber).font(.system(size: 11, weight: .bold))
                            .foregroundStyle(Palette.transitLineText("\(passage.entityID ?? deLijnEntityID)-\(passage.vehicleMode ?? "BUS")-\(passage.lineNumber)", lightMode: appTheme == "light"))
                            .padding(.horizontal, 8).padding(.vertical, 4)
                            .background(Palette.transitLine("\(passage.entityID ?? deLijnEntityID)-\(passage.vehicleMode ?? "BUS")-\(passage.lineNumber)", lightMode: appTheme == "light"), in: RoundedRectangle(cornerRadius: 7))
                        Text(passage.destination).font(.system(size: 11, weight: .medium))
                            .lineLimit(2).minimumScaleFactor(0.78)
                            .fixedSize(horizontal: false, vertical: true).layoutPriority(1)
                        Spacer()
                        VStack(alignment: .trailing, spacing: 2) {
                            Text(passage.realtimeTime, format: .dateTime.hour().minute())
                                .font(.system(size: 15, weight: .bold, design: .rounded))
                                .contentTransition(reduceMotion ? .identity : .numericText())
                            liveCountdownText(to: passage.realtimeTime,
                                font: .system(size: 9, weight: .medium), color: Palette.muted)
                            let status = departureStatus(for: passage)
                            Label(status.title, systemImage: status.symbol)
                                .font(.system(size: 8, weight: .bold)).lineLimit(1).minimumScaleFactor(0.72)
                                .foregroundStyle(status.color)
                                .padding(.horizontal, 6).padding(.vertical, 3)
                                .background(status.color.opacity(0.12), in: Capsule())
                        }
                    }
                    .padding(.vertical, 3)
                    .transition(reduceMotion ? .opacity : .move(edge: .top).combined(with: .opacity))
                    if showAllDepartures && passage.id != departures.prefix(5).last?.id {
                        Divider().overlay(Palette.muted.opacity(0.18))
                    }
                }
            }
        }
        .padding(12).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))
        .animation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.86), value: departureVisualStateKey)
    }

    private var departureVisualStateKey: [String] {
        departures.map {
            let status = departureStatus(for: $0)
            return "\($0.id)|\($0.realtimeTime.timeIntervalSince1970)|\($0.scheduledTime.timeIntervalSince1970)|\($0.hasRealtimePrediction)|\($0.hasScheduledTime)|\($0.vehicleMode ?? "")|\($0.destination)|\(status.title)|\(status.symbol)"
        } + ["fresh|\(hasFreshDeparturePredictions)"]
    }

    private func departureStatus(for passage: DeLijnStopPassage) -> (title: String, symbol: String, color: Color) {
        guard passage.hasRealtimePrediction else { return ("Horaire prévu", "clock", Palette.muted) }
        guard hasFreshDeparturePredictions else { return ("Données anciennes", "clock.badge.exclamationmark", .orange) }
        guard passage.hasScheduledTime else { return ("En direct", "dot.radiowaves.left.and.right", Palette.green) }
        let delay = Int((passage.realtimeTime.timeIntervalSince(passage.scheduledTime) / 60).rounded())
        if delay >= 2 { return ("Retard +\(delay) min", "exclamationmark.circle.fill", Palette.pink) }
        if delay <= -2 { return ("Avance \(-delay) min", "arrow.up.circle.fill", Palette.blue) }
        return ("À l’heure", "checkmark.circle.fill", Palette.green)
    }

    private var savedTrips: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Trajets enregistrés").font(.system(size: 17, weight: .bold, design: .rounded))
            Button { if deLijnStopID.isEmpty { navigateToTab(4) } else { navigateToTab(0) } } label: {
                HStack(spacing: 10) {
                    Image(systemName: "star.fill").font(.system(size: 14)).foregroundStyle(Palette.purple).frame(width: 23)
                    Text(deLijnStopID.isEmpty ? "Choisir un départ" : "\(stopName) → \(destinationName)").font(.system(size: 12, weight: .medium)).lineLimit(1)
                    Spacer()
                    Image(systemName: "arrow.up.right").font(.system(size: 11, weight: .semibold)).foregroundStyle(Palette.muted)
                }
            }.buttonStyle(MobiGoPressStyle())
        }
        .padding(15)
        .background(Palette.card, in: RoundedRectangle(cornerRadius: 20))
    }

    private func tripRow(icon: String, title: String, detail: String, color: Color) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon).font(.system(size: 14)).foregroundStyle(color).frame(width: 23)
            Text(title).font(.system(size: 12, weight: .medium))
            Spacer()
            Text(detail).font(.system(size: 11)).foregroundStyle(Palette.muted)
            Image(systemName: "arrow.left.arrow.right").font(.system(size: 11, weight: .semibold)).foregroundStyle(Palette.muted)
        }
    }

    private var wakeCard: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack {
                Label("ALERTES DE RÉVEIL", systemImage: "alarm.fill").font(.system(size: 11, weight: .bold))
                Spacer()
                if !AlarmScheduler.supportsSystemAlarm {
                    Text("NOTIFICATION").font(.system(size: 9, weight: .bold)).foregroundStyle(Palette.muted)
                }
                Button {
                    playInteractionFeedback()
                    Task {
                        do {
                            try await AlarmScheduler.shared.testNow()
                            alarmMessage = AlarmScheduler.supportsSystemAlarm
                                ? "Alarme système de test dans 5 secondes."
                                : "Son progressif dans 5 secondes · volume et mode silencieux iOS s’appliquent."
                        } catch { alarmMessage = error.localizedDescription }
                    }
                } label: {
                    Label("Tester", systemImage: "speaker.wave.2.fill").font(.system(size: 10, weight: .bold))
                }.foregroundStyle(Palette.purple)
                Button {
                    setAlarmEnabled(!alarmEnabled)
                } label: {
                    Image(systemName: alarmEnabled ? "alarm.waves.left.and.right.fill" : "alarm")
                        .foregroundStyle(alarmEnabled ? Palette.purple : Palette.muted)
                        .font(.system(size: 17, weight: .semibold))
                }
            }
            HStack(alignment: .firstTextBaseline) {
                Text(wakeDate, format: .dateTime.hour().minute()).font(.system(size: 33, weight: .bold, design: .rounded))
                Text("réveil · bus à \(departureDate.formatted(date: .omitted, time: .shortened))").font(.system(size: 12)).foregroundStyle(Palette.muted)
            }
            HStack(spacing: 8) {
                Label("\(wakeMinutes) min pour me réveiller", systemImage: "sunrise.fill")
                Text("·")
                Text("\(prepMinutes) min de préparation")
            }.font(.system(size: 10)).foregroundStyle(Palette.muted)
            Text(AlarmScheduler.supportsSystemAlarm
                ? "Alarme iOS 26 · bouton « Je suis réveillé » ou ouverture de MobiGo pour arrêter."
                : "20 rappels · 5 s · volume et vibration selon iOS · ouvre MobiGo pour arrêter.")
                .font(.system(size: 10)).foregroundStyle(Palette.muted)
            if !alarmMessage.isEmpty { Text(alarmMessage).font(.system(size: 10)).foregroundStyle(Palette.muted) }
        }
        .padding(15).background(Palette.card, in: RoundedRectangle(cornerRadius: 20))
    }

    private var liveInfoNote: some View {
        Text(deLijnStopID.isEmpty ? "Indique ton domicile : MobiGo prépare le trajet depuis une adresse" : "Horaires actualisés quand MobiGo est ouvert")
            .font(.system(size: 10)).foregroundStyle(Palette.muted)
            .frame(maxWidth: .infinity).padding(.bottom, 10)
    }

    private var refreshDeparturesButton: some View {
        Button {
            guard !isLoadingDepartures else { return }
            playInteractionFeedback()
            Task { await refreshDepartures() }
        } label: {
            Image(systemName: "arrow.clockwise")
                .font(.system(size: 12, weight: .semibold)).foregroundStyle(Palette.purple)
                .rotationEffect(.degrees(isLoadingDepartures ? 180 : 0))
                .animation(reduceMotion ? nil : .easeInOut(duration: 0.3), value: isLoadingDepartures)
                .frame(width: 30, height: 30).contentShape(Rectangle())
        }
        .buttonStyle(MobiGoPressStyle())
        .disabled(isLoadingDepartures)
        .accessibilityLabel(isLoadingDepartures ? "Actualisation des départs" : "Actualiser les départs")
    }

    private func navigateToTab(_ index: Int) {
        guard selectedTab != index else { return }
        tabTransitionEdge = index > selectedTab ? .trailing : .leading
        selectedTab = index
    }

    private var tabBar: some View {
        HStack(spacing: 0) {
            tab(icon: "bus", label: "Mon trajet", index: 0)
            tab(icon: "slider.horizontal.3", label: "Configuration", index: 4)
        }
        .padding(.top, 9).padding(.bottom, 5)
        .background(Palette.card.overlay(alignment: .top) { Rectangle().fill(Palette.muted.opacity(0.2)).frame(height: 1) })
    }

    private func tab(icon: String, label: String, index: Int) -> some View {
        let isSelected = selectedTab == index
        return Button {
            if selectedTab != index { playInteractionFeedback() }
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.22)) {
                navigateToTab(index)
            }
            if index == 4 { restoreDestination() }
        } label: {
            VStack(spacing: 4) {
                ZStack {
                    if isSelected {
                        RoundedRectangle(cornerRadius: 9)
                            .fill(Palette.purple.opacity(0.14))
                            .matchedGeometryEffect(id: "tab-highlight", in: tabHighlight)
                    }
                    Image(systemName: icon).font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(isSelected ? Palette.purple : Palette.muted)
                }
                    .frame(width: 30, height: 25)
                    .scaleEffect(isSelected ? 1.04 : 1)
                    .animation(reduceMotion ? nil : .spring(response: 0.28, dampingFraction: 0.72), value: isSelected)
                Text(label).font(.system(size: 9, weight: isSelected ? .semibold : .medium))
                    .foregroundStyle(isSelected ? Palette.purple : Palette.muted)
            }
            .frame(maxWidth: .infinity).frame(height: 45)
        }.buttonStyle(MobiGoPressStyle())
    }

    private func countdown(to date: Date, now: Date = .now) -> String {
        let minutes = max(0, Int(date.timeIntervalSince(now) / 60))
        if minutes < 60 { return "dans \(minutes) min" }
        return "dans \(minutes / 60) h \(minutes % 60)"
    }

    private func liveCountdownText(to date: Date, suffix: String = "", font: Font, color: Color) -> some View {
        TimelineView(.periodic(from: .now, by: 30)) { timeline in
            let value = countdown(to: date, now: timeline.date) + suffix
            Text(value)
                .font(font).foregroundStyle(color).monospacedDigit()
                .contentTransition(reduceMotion ? .identity : .numericText())
                .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: value)
        }
    }

    private var stopPickerSheet: some View {
        NavigationView {
            Form {
                Section("Arrêt de départ") {
                    TextField("Nom d’arrêt ou commune", text: $stopSearchText)
                        .textInputAutocapitalization(.words)
                        .autocorrectionDisabled()
                    Button {
                        playInteractionFeedback()
                        Task { await searchStops() }
                    } label: {
                        Label(isSearchingStops ? "Recherche…" : "Rechercher", systemImage: "magnifyingglass")
                    }
                    .disabled(isSearchingStops || stopSearchText.trimmingCharacters(in: .whitespacesAndNewlines).count < 2)

                    if stopResults.isEmpty && !isSearchingStops && !stopSearchMessage.isEmpty {
                        Text(stopSearchMessage).font(.footnote).foregroundStyle(.secondary)
                    }

                    ForEach(stopResults) { stop in
                        Button {
                            deLijnStopID = String(stop.properties.STOPID)
                            deLijnEntityID = stop.properties.ENTITEITNUMMER
                            stopName = stop.properties.NAAMHALTE
                            rememberWidgetStop(stopID: deLijnStopID, entityID: deLijnEntityID,
                                name: stopName, municipality: stop.properties.NAAMGEM)
                            WidgetDataStore.configure(stopID: deLijnStopID, entityID: deLijnEntityID, stopName: stopName)
                            WidgetDataStore.save([])
                            WidgetCenter.shared.reloadAllTimelines()
                            stopResults = []
                            stopSearchText = ""
                            showingStopPicker = false
                            Task { await loadDepartures() }
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: stopIcon(stop.properties.ENTITEITNUMMER)).foregroundStyle(Palette.purple)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(stop.properties.NAAMHALTE).foregroundStyle(.primary)
                                    Text("\(networkLabel(stop.properties.ENTITEITNUMMER)) · \(stop.properties.NAAMGEM) · \(stop.properties.STOPID)")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                            }
                        }
                    }
                }
                Section {
                    Text("Arrêts De Lijn · STIB · TEC · SNCB")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Palette.background)
            .tint(Palette.purple)
            .listRowBackground(Palette.card)
            .listRowSeparatorTint(Palette.muted.opacity(0.2))
            .navigationTitle("Choisir mon arrêt")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Fermer") { showingStopPicker = false } } }
        }
    }

    private var configurationHeading: some View {
        HStack(spacing: 10) {
            Image(systemName: "slider.horizontal.3")
                .font(.system(size: 17, weight: .semibold)).foregroundStyle(Palette.purple)
            VStack(alignment: .leading, spacing: 2) {
                Text("Configuration").font(.system(size: 20, weight: .bold))
                Text("Un matin bien préparé commence ici.")
                    .font(.system(size: 10)).foregroundStyle(Palette.muted).lineLimit(1).minimumScaleFactor(0.8)
            }
            Spacer(minLength: 2)
            HStack(spacing: 2) {
                appearanceOption("moon.stars.fill", title: "Sombre", theme: "dark")
                appearanceOption("sun.max.fill", title: "Clair", theme: "light")
            }
            .padding(3)
            .background(Palette.card, in: RoundedRectangle(cornerRadius: 12))
            .frame(width: 140)
        }
        .padding(.horizontal, 16).padding(.vertical, 6)
    }

    private var transitSubscriptionsCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Label("MES ABONNEMENTS", systemImage: "ticket.fill")
                    .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.muted)
                Spacer()
                Button("Tous") { playInteractionFeedback(); setAllTransitSubscriptions(true) }
                    .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.purple)
                Button("Aucun") { playInteractionFeedback(); setAllTransitSubscriptions(false) }
                    .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.muted)
            }
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 7) {
                ForEach(TransitFareNetwork.all) { network in
                    let selected = subscribedTransitNetworks.contains(network.id)
                    Button {
                        playInteractionFeedback()
                        setTransitSubscription(network.id, enabled: !selected)
                    } label: {
                        HStack(spacing: 7) {
                            Image(systemName: network.symbol).font(.system(size: 11, weight: .semibold))
                            Text(network.name).font(.system(size: 11, weight: .semibold))
                            Spacer(minLength: 1)
                            Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                                .font(.system(size: 12, weight: .semibold))
                        }
                        .foregroundStyle(selected ? Palette.purple : Palette.text)
                        .padding(.horizontal, 10).frame(height: 38)
                        .background(selected ? Palette.purple.opacity(0.13) : Palette.elevated,
                                    in: RoundedRectangle(cornerRadius: 10))
                    }
                    .buttonStyle(MobiGoPressStyle())
                    .accessibilityLabel("\(network.name), abonnement \(selected ? "sélectionné" : "non sélectionné")")
                }
            }
            Toggle(isOn: $includeUnsubscribedNetworks) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Inclure les autres réseaux")
                        .font(.system(size: 10, weight: .semibold))
                    Text("MobiGo affichera le prix du billet")
                        .font(.system(size: 9)).foregroundStyle(Palette.muted)
                }
            }
            .tint(Palette.purple)
            .scaleEffect(0.92, anchor: .trailing)
            .font(.system(size: 10))
            Text(subscriptionHelpText)
                .font(.system(size: 9, weight: .medium)).foregroundStyle(Palette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))
    }

    private var transitModesCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("MOYENS DE TRANSPORT", systemImage: "tram.fill")
                .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.muted)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 7) {
                let options: [(String, String, String)] = [
                    ("BUS", "Bus", "bus.fill"), ("TRAM", "Tram", "tram.fill"),
                    ("SUBWAY", "Métro", "tram.tunnel.fill"), ("RAIL", "Train", "train.side.front.car")
                ]
                ForEach(options.indices, id: \.self) { index in
                    let (mode, title, icon) = options[index]
                    let selected = enabledTransitModes.contains(mode)
                    Button {
                        playInteractionFeedback()
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.18)) {
                            toggleTransitMode(mode)
                        }
                    } label: {
                        HStack(spacing: 7) {
                            Image(systemName: icon).font(.system(size: 11, weight: .semibold))
                            Text(title).font(.system(size: 11, weight: .semibold))
                            Spacer(minLength: 1)
                            Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                                .font(.system(size: 12, weight: .semibold))
                        }
                        .foregroundStyle(selected ? Palette.purple : Palette.text)
                        .padding(.horizontal, 10).frame(height: 36)
                        .background(selected ? Palette.purple.opacity(0.13) : Palette.elevated,
                                    in: RoundedRectangle(cornerRadius: 10))
                    }
                    .buttonStyle(MobiGoPressStyle())
                    .accessibilityLabel("\(title), \(selected ? "activé" : "désactivé")")
                }
            }
            Text("Train désactivé au départ. Active-le si tu veux aussi voir les IC et autres trains.")
                .font(.system(size: 9, weight: .medium)).foregroundStyle(Palette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))
    }

    private var interactionFeedbackCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("SONS ET VIBRATIONS", systemImage: "waveform")
                .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.muted)
            Toggle(isOn: $interactionSoundsEnabled) {
                Label("Sons des boutons", systemImage: "speaker.wave.2.fill")
                    .font(.system(size: 11, weight: .medium))
            }.tint(Palette.purple)
            Toggle(isOn: $interactionHapticsEnabled) {
                Label("Vibrations", systemImage: "iphone.radiowaves.left.and.right")
                    .font(.system(size: 11, weight: .medium))
            }.tint(Palette.purple)
            Button { playInteractionFeedback(success: true, sound: true) } label: {
                Label("Tester le son et la vibration", systemImage: "play.circle.fill")
                    .font(.system(size: 10, weight: .semibold)).foregroundStyle(Palette.purple)
            }.buttonStyle(MobiGoPressStyle())
        }
        .padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))
    }

    private var subscriptionHelpText: String {
        if subscribedTransitNetworks.isEmpty {
            return "Sans abonnement · billet à payer. Les moyens cochés ci-dessous limitent les trajets."
        }
        if includeUnsubscribedNetworks {
            return "Les réseaux sans abonnement restent proposés; leur billet est ajouté au prix estimé."
        }
        return "Seuls tes réseaux sélectionnés seront proposés. Enregistre le trajet pour recalculer."
    }

    private var profileSheet: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 11) {
                brandMark
                configurationHeading

                configurationAddressesCard
                if journeys.count > 1 {
                    DisclosureGroup("Autres trajets · \(journeys.count - 1)") {
                        VStack(alignment: .leading, spacing: 10) {
                            ForEach(Array(journeys.dropFirst())) { journeyOptionRow($0) }
                        }.padding(.top, 8)
                    }.font(.system(size: 11, weight: .semibold)).tint(Palette.purple)
                        .padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))
                }

                VStack(alignment: .leading, spacing: 9) {
                    Label("JOURS DE TRAJET", systemImage: "calendar")
                        .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.muted)
                    HStack(spacing: 6) {
                        ForEach([2, 3, 4, 5, 6, 7, 1], id: \.self) { weekday in
                            weekdayPill(weekday)
                        }
                    }
                    if savedDestinations.isEmpty {
                        Text("Ajoute tes lieux avec + ci-dessus.")
                            .font(.system(size: 9)).foregroundStyle(Palette.muted)
                    }
                    HStack {
                        Label("Arriver au plus tard à", systemImage: "clock")
                            .font(.system(size: 11, weight: .medium))
                        Spacer()
                        DatePicker("Heure d’arrivée", selection: Binding(
                            get: { arrivalTargetDate },
                            set: {
                                arriveByHour = Calendar.current.component(.hour, from: $0)
                                arriveByMinute = Calendar.current.component(.minute, from: $0)
                            }
                        ), displayedComponents: .hourAndMinute)
                        .labelsHidden().tint(Palette.purple)
                    }
                }.padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))

                HStack(spacing: 9) {
                    Image(systemName: "alarm.fill").font(.system(size: 14, weight: .semibold)).foregroundStyle(Palette.purple)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Préparation avant le départ").font(.system(size: 11, weight: .semibold))
                        Text("Le temps pour te préparer, sans stress").font(.system(size: 9)).foregroundStyle(Palette.muted)
                    }
                    Spacer(minLength: 3)
                    Stepper("\(prepMinutes) min", value: $prepMinutes, in: 5...120, step: 5)
                        .labelsHidden().fixedSize()
                    Text("\(prepMinutes) min").font(.system(size: 12, weight: .bold)).monospacedDigit()
                        .foregroundStyle(Palette.purple).frame(minWidth: 42, alignment: .trailing)
                }.padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))

                Button {
                    playInteractionFeedback()
                    Task {
                        if let selectedPlace { await selectDestinationPlace(selectedPlace) }
                        else if let selectedDestination { await findJourneys(to: selectedDestination) }
                        if alarmEnabled { try? await scheduleAlarm() }
                        navigateToTab(0)
                    }
                } label: {
                    Label(isSearchingJourneys ? "Calcul du trajet…" : "Enregistrer mon trajet", systemImage: "checkmark")
                        .font(.system(size: 13, weight: .bold)).frame(maxWidth: .infinity, minHeight: 44)
                        .foregroundStyle(.white)
                        .background(Palette.purple, in: RoundedRectangle(cornerRadius: 13))
                }.disabled(isSearchingJourneys || selectedPlace == nil && selectedDestination == nil)

                DisclosureGroup(isExpanded: $showingAdvancedSettings) {
                    VStack(alignment: .leading, spacing: 10) {
                        widgetStopsCard
                        transitSubscriptionsCard
                        transitModesCard
                        interactionFeedbackCard

                        DisclosureGroup(isExpanded: $showingWidgetHelp) {
                            VStack(alignment: .leading, spacing: 9) {
                                widgetSetupStep("1", icon: "plus", text: "Ajoute MobiGo sur l’écran d’accueil ou verrouillé")
                                widgetSetupStep("2", icon: "rectangle.stack.fill", text: "Ajoute une copie du widget par arrêt")
                                widgetSetupStep("3", icon: "slider.horizontal.3", text: "Modifie chaque copie → Arrêt → choisis l’arrêt")
                            }
                            .padding(.top, 8)
                        } label: {
                            Label("Configurer les widgets", systemImage: "rectangle.stack.fill")
                        }
                        DisclosureGroup("Réglages du réveil") {
                            VStack(spacing: 8) {
                                Stepper("Temps pour me réveiller · \(wakeMinutes) min", value: $wakeMinutes, in: 0...90, step: 5)
                                HStack {
                                    Text("Difficulté au réveil").font(.system(size: 11, weight: .medium))
                                    Spacer()
                                    Picker("Difficulté au réveil", selection: $wakeDifficulty) {
                                        Text("Facile").tag(0); Text("Moyenne").tag(1); Text("Difficile").tag(2)
                                    }.labelsHidden().tint(Palette.purple)
                                }
                            }.padding(.top, 7)
                        }
                    VStack(alignment: .leading, spacing: 10) {
                        Text(stopName.isEmpty ? "MobiGo choisit l’arrêt près de ton domicile." : "Arrêt choisi automatiquement · \(stopName)")
                            .font(.system(size: 11)).foregroundStyle(Palette.muted)
                        Button { Task { await findNearbyOriginStop() } } label: {
                            Label(isFindingNearbyOrigin ? "Recherche…" : "Actualiser l’arrêt proche", systemImage: "location.fill")
                        }.disabled(isFindingNearbyOrigin)
                        TextField("Nom d’arrêt ou commune", text: $stopSearchText)
                            .textInputAutocapitalization(.words).autocorrectionDisabled()
                        Button { Task { await searchStops() } } label: {
                            Label(isSearchingStops ? "Recherche…" : "Chercher un arrêt", systemImage: "magnifyingglass")
                        }.disabled(isSearchingStops || stopSearchText.trimmingCharacters(in: .whitespacesAndNewlines).count < 2)
                        if !stopSearchMessage.isEmpty { Text(stopSearchMessage).font(.caption).foregroundStyle(Palette.muted) }
                        ForEach(stopResults) { stop in
                            Button {
                                deLijnStopID = String(stop.properties.STOPID)
                                deLijnEntityID = stop.properties.ENTITEITNUMMER
                                stopName = stop.properties.NAAMHALTE
                                rememberWidgetStop(stopID: deLijnStopID, entityID: deLijnEntityID,
                                    name: stopName, municipality: stop.properties.NAAMGEM)
                                stopSearchText = ""; stopResults = []; stopSearchMessage = ""
                                WidgetDataStore.configure(stopID: deLijnStopID, entityID: deLijnEntityID, stopName: stopName)
                                Task { await loadDepartures() }
                            } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(stop.properties.NAAMHALTE).foregroundStyle(Palette.text)
                                    Text(stop.properties.NAAMGEM).font(.caption).foregroundStyle(Palette.muted)
                                }.frame(maxWidth: .infinity, alignment: .leading)
                            }.buttonStyle(MobiGoPressStyle())
                        }
                        Button(isLoadingDepartures ? "Actualisation…" : "Actualiser les horaires") { Task { await loadDepartures() } }
                            .disabled(isLoadingDepartures || deLijnStopID.isEmpty)
                        if !apiStatus.isEmpty { Text(apiStatus).font(.caption).foregroundStyle(Palette.muted) }
                    }.padding(.top, 8)
                        if adsConsent.privacyOptionsRequired {
                            Button {
                                Task { await adsConsent.presentPrivacyOptions() }
                            } label: {
                                Label("Confidentialité des publicités", systemImage: "hand.raised.fill")
                            }
                        }
                    }
                } label: {
                    Label("Autres réglages", systemImage: "ellipsis.circle")
                        .font(.system(size: 12, weight: .semibold))
                }
                .font(.system(size: 11, weight: .semibold)).tint(Palette.purple)
                    .padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))
                    .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: showingAdvancedSettings)

            }
            .padding(.horizontal, 16).padding(.top, 10).padding(.bottom, 18)
        }
        .foregroundStyle(Palette.text)
        .onAppear {
            if homeAddressQuery.isEmpty { homeAddressQuery = displayHomeAddress }
            savedWidgetStopItems = WidgetDataStore.savedWidgetStops()
        }
        .onChange(of: transitNetwork) { _ in Task { await reselectNearestHomeStop() } }
        .onDisappear { if alarmEnabled { Task { try? await scheduleAlarm() } } }
    }

    private func appearanceOption(_ symbol: String, title: String, theme: String) -> some View {
        let isSelected = appTheme == theme
        return Button {
            if !isSelected { playInteractionFeedback() }
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
                appTheme = theme
            }
        } label: {
            Label(title, systemImage: symbol)
                .labelStyle(.titleAndIcon)
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(isSelected ? .white : Palette.muted)
                .frame(maxWidth: .infinity)
                .frame(height: 40)
                .background(isSelected ? Palette.purple : .clear, in: RoundedRectangle(cornerRadius: 9))
        }
        .buttonStyle(MobiGoPressStyle())
        .accessibilityLabel("Thème \(title.lowercased())")
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }

    private func widgetSetupStep(_ number: String, icon: String, text: String) -> some View {
        HStack(spacing: 9) {
            Text(number).font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(Palette.purple).frame(width: 19, height: 19)
                .background(Palette.purple.opacity(0.14), in: Circle())
            Image(systemName: icon).font(.system(size: 11, weight: .semibold))
                .foregroundStyle(Palette.muted).frame(width: 16)
            Text(text).font(.system(size: 10, weight: .medium)).foregroundStyle(Palette.text)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var configurationAddressesCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            Label("TES ADRESSES", systemImage: "mappin.and.ellipse")
                .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.muted)

            VStack(spacing: 0) {
                Button {
                    isEditingHomeAddress.toggle()
                    if homeAddressQuery.isEmpty { homeAddressQuery = displayHomeAddress }
                } label: {
                    configurationAddressRow(icon: "house.fill", title: "Domicile",
                        value: homeAddress.isEmpty ? "Choisir une adresse" : displayHomeAddress)
                }.buttonStyle(MobiGoPressStyle())

                if isEditingHomeAddress {
                    HStack(spacing: 8) {
                        TextField("Rue et commune", text: $homeAddressQuery)
                            .textInputAutocapitalization(.words).autocorrectionDisabled().submitLabel(.search)
                            .onSubmit { Task { await searchHomeAddress() } }
                        Button { Task { await searchHomeAddress() } } label: {
                            Image(systemName: isSearchingHomeAddress ? "hourglass" : "magnifyingglass")
                                .foregroundStyle(Palette.purple)
                        }.disabled(isSearchingHomeAddress || homeAddressQuery.trimmingCharacters(in: .whitespacesAndNewlines).count < 3)
                    }.font(.system(size: 11)).padding(.leading, 42).padding(.trailing, 10).padding(.bottom, 9)
                }

                ForEach(homeAddressResults) { place in
                    Button { playInteractionFeedback(); Task { await selectHomeAddress(place) } } label: {
                        HStack(spacing: 8) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(place.name).foregroundStyle(Palette.text)
                                Text(place.subtitle).font(.system(size: 9)).foregroundStyle(Palette.muted)
                            }
                            Spacer(minLength: 4)
                            Image(systemName: "chevron.right").font(.system(size: 10)).foregroundStyle(Palette.muted)
                        }
                    }.buttonStyle(MobiGoPressStyle()).padding(.leading, 40).padding(.bottom, 8)
                }

                Rectangle().fill(Palette.muted.opacity(0.18)).frame(height: 1).padding(.leading, 40)

                Button {
                    isEditingDestination.toggle()
                    if destination.isEmpty || destination == "Centre-ville" { destination = destinationName }
                } label: {
                    configurationAddressRow(icon: "mappin.and.ellipse", title: "Destination",
                        value: selectedPlace.map { "\($0.name), \($0.subtitle)" }
                            ?? (journeys.isEmpty ? "Choisir une destination" : destinationName))
                }.buttonStyle(MobiGoPressStyle())

                if isEditingDestination {
                    HStack(spacing: 8) {
                        TextField("Adresse, école, travail…", text: $destination)
                            .textInputAutocapitalization(.words).autocorrectionDisabled().submitLabel(.search)
                            .onSubmit { openDestinationSearch() }
                        Button { openDestinationSearch() } label: {
                            Image(systemName: isSearchingJourneys ? "arrow.triangle.2.circlepath" : "magnifyingglass")
                                .foregroundStyle(Palette.purple)
                        }.disabled(isSearchingJourneys || destination.trimmingCharacters(in: .whitespacesAndNewlines).count < 2)
                    }.font(.system(size: 11)).padding(.leading, 42).padding(.trailing, 10).padding(.bottom, 9)
                }

                if let selectedPlace {
                    Button { playInteractionFeedback(success: true); saveDestination(selectedPlace) } label: {
                        Label(savedDestinations.contains(where: { $0.id == SavedDestination.id(for: selectedPlace) })
                            ? "Lieu enregistré" : "Ajouter aux destinations", systemImage: "plus.circle.fill")
                            .font(.system(size: 10, weight: .semibold)).foregroundStyle(Palette.purple)
                    }.disabled(savedDestinations.contains(where: { $0.id == SavedDestination.id(for: selectedPlace) }))
                        .frame(maxWidth: .infinity, alignment: .leading).padding(.leading, 42).padding(.bottom, 8)
                }

                if !destinationPlaceResults.isEmpty {
                    ForEach(destinationPlaceResults) { destinationPlaceRow($0) }
                }
                if !destinationResults.isEmpty {
                    ForEach(destinationResults) { destinationStopRow($0) }
                }
                if isSearchingJourneys {
                    ProgressView("Je prépare ton trajet…").font(.caption).tint(Palette.purple).padding(.vertical, 8)
                }
            }
            .padding(.horizontal, 10).padding(.vertical, 3)
            .background(Palette.elevated, in: RoundedRectangle(cornerRadius: 14))

            Button { Task { await findNearbyOriginStop() } } label: {
                Label(isFindingNearbyOrigin ? "Recherche autour de toi…" : "Utiliser ma position comme domicile",
                      systemImage: "location.fill")
                    .font(.system(size: 10, weight: .semibold)).foregroundStyle(Palette.purple)
                    .frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 11).padding(.vertical, 9)
                    .background(Palette.highlightedCard, in: RoundedRectangle(cornerRadius: 10))
            }.buttonStyle(MobiGoPressStyle()).disabled(isFindingNearbyOrigin)
        }.padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))
    }

    private var widgetStopsCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("ARRÊTS DES WIDGETS", systemImage: "rectangle.stack.fill")
                .font(.system(size: 10, weight: .bold)).foregroundStyle(Palette.muted)
            Text("Chaque widget choisit son arrêt, séparément de ton trajet.")
                .font(.system(size: 9, weight: .medium)).foregroundStyle(Palette.muted)
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: 7) {
                TextField("Chercher un arrêt ou une commune", text: $widgetStopSearchText)
                    .textInputAutocapitalization(.words).autocorrectionDisabled().submitLabel(.search)
                    .onSubmit { Task { await searchWidgetStops() } }
                    .font(.system(size: 11))
                Button { Task { await searchWidgetStops() } } label: {
                    Image(systemName: isSearchingWidgetStops ? "hourglass" : "magnifyingglass")
                        .font(.system(size: 12, weight: .semibold)).foregroundStyle(Palette.purple)
                        .frame(width: 30, height: 30)
                }
                .disabled(isSearchingWidgetStops || widgetStopSearchText.trimmingCharacters(in: .whitespacesAndNewlines).count < 2)
                .accessibilityLabel("Chercher des arrêts pour les widgets")
            }
            .padding(.horizontal, 9).background(Palette.elevated, in: RoundedRectangle(cornerRadius: 10))

            if !widgetStopSearchMessage.isEmpty {
                Text(widgetStopSearchMessage).font(.system(size: 9, weight: .medium)).foregroundStyle(Palette.muted)
            }

            ForEach(widgetStopSearchResults) { stop in
                let stopID = String(stop.properties.STOPID)
                let entityID = stop.properties.ENTITEITNUMMER
                let isSaved = savedWidgetStopItems.contains {
                    $0.stopID == stopID && $0.entityID.lowercased() == entityID.lowercased()
                }
                HStack(spacing: 7) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(stop.properties.NAAMHALTE).font(.system(size: 10, weight: .semibold))
                            .foregroundStyle(Palette.text).lineLimit(1)
                        Text("\(networkLabel(entityID)) · \(stop.properties.NAAMGEM)")
                            .font(.system(size: 8, weight: .medium)).foregroundStyle(Palette.muted).lineLimit(1)
                    }
                    Spacer(minLength: 3)
                    Button {
                        rememberWidgetStop(stopID: stopID, entityID: entityID,
                            name: stop.properties.NAAMHALTE, municipality: stop.properties.NAAMGEM)
                    } label: {
                        Image(systemName: isSaved ? "checkmark.circle.fill" : "plus.circle.fill")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(isSaved ? Palette.green : Palette.purple).padding(4)
                    }
                    .buttonStyle(MobiGoPressStyle()).disabled(isSaved)
                    .accessibilityLabel(isSaved ? "Arrêt déjà ajouté" : "Ajouter \(stop.properties.NAAMHALTE) aux arrêts des widgets")
                }
            }

            if savedWidgetStopItems.isEmpty {
                Label("Choisis un arrêt pour commencer", systemImage: "plus.circle")
                    .font(.system(size: 10, weight: .medium)).foregroundStyle(Palette.text)
                    .padding(.vertical, 3)
            } else {
                ForEach(savedWidgetStopItems) { stop in
                    HStack(spacing: 8) {
                        Image(systemName: stopIcon(stop.entityID)).foregroundStyle(Palette.purple)
                            .frame(width: 20)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(stop.name).font(.system(size: 10, weight: .semibold)).foregroundStyle(Palette.text)
                                .lineLimit(1)
                            Text("\(networkLabel(stop.entityID))\(stop.municipality.isEmpty ? "" : " · \(stop.municipality)")")
                                .font(.system(size: 8, weight: .medium)).foregroundStyle(Palette.muted)
                                .lineLimit(1)
                        }
                        Spacer(minLength: 4)
                        Button {
                            playInteractionFeedback()
                            WidgetDataStore.removeWidgetStop(id: stop.id)
                            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.2)) {
                                savedWidgetStopItems = WidgetDataStore.savedWidgetStops()
                            }
                            WidgetCenter.shared.reloadAllTimelines()
                        } label: {
                            Image(systemName: "minus.circle.fill").foregroundStyle(Palette.muted)
                        }
                        .buttonStyle(MobiGoPressStyle()).accessibilityLabel("Retirer \(stop.name) de la liste des widgets")
                    }
                }
            }

            Text("Écran verrouillé : appui long → Personnaliser → touche le widget → Arrêt. Ajoute 2 widgets pour suivre 2 arrêts.")
                .font(.system(size: 9, weight: .medium)).foregroundStyle(Palette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(13).background(Palette.card, in: RoundedRectangle(cornerRadius: 17))
    }

    @MainActor
    private func rememberWidgetStop(stopID: String, entityID: String, name: String, municipality: String) {
        WidgetDataStore.addWidgetStop(WidgetSavedStop(stopID: stopID, entityID: entityID,
            name: name, municipality: municipality))
        withAnimation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.84)) {
            savedWidgetStopItems = WidgetDataStore.savedWidgetStops()
        }
        playInteractionFeedback(success: true)
        WidgetCenter.shared.reloadAllTimelines()
    }

    private func playInteractionFeedback(success: Bool = false, sound: Bool? = nil) {
        if interactionHapticsEnabled {
            MobiGoInteractionFeedback.play(success: success)
        }
        // Play sound only for the explicit test and successful confirmations.
        // Ordinary taps stay silent, so they don't clutter navigation or interrupt media.
        if (sound ?? success) && interactionSoundsEnabled { AudioServicesPlaySystemSound(1025) }
    }

    @MainActor
    private func searchWidgetStops() async {
        let term = widgetStopSearchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard term.count >= 2 else { return }
        isSearchingWidgetStops = true
        widgetStopSearchResults = []
        widgetStopSearchMessage = "Recherche des arrêts…"
        defer { isSearchingWidgetStops = false }
        async let deLijn = DeLijnClient.shared.searchStops(term)
        async let stib = StibClient.shared.searchStops(term)
        let combined = ((try? await deLijn) ?? []) + ((try? await stib) ?? [])
            + BelgianStopCatalog.searchStops(term)
        var seen = Set<String>()
        widgetStopSearchResults = Array(combined.filter {
            seen.insert("\($0.properties.ENTITEITNUMMER.lowercased())|\($0.properties.STOPID)").inserted
        }.prefix(30))
        widgetStopSearchMessage = widgetStopSearchResults.isEmpty
            ? "Aucun arrêt trouvé. Essaie un nom plus court."
            : "Touche + pour ajouter un arrêt à la liste des widgets."
    }

    private func configurationAddressRow(icon: String, title: String, value: String) -> some View {
        HStack(spacing: 9) {
            Image(systemName: icon).font(.system(size: 13, weight: .semibold)).foregroundStyle(Palette.purple)
                .frame(width: 27, height: 27).background(Palette.purple.opacity(0.12), in: RoundedRectangle(cornerRadius: 8))
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 9, weight: .medium)).foregroundStyle(Palette.muted)
                Text(value).font(.system(size: 11, weight: .semibold)).foregroundStyle(Palette.text)
                    .lineLimit(1).minimumScaleFactor(0.8)
            }
            Spacer(minLength: 4)
            Image(systemName: "chevron.right").font(.system(size: 10, weight: .semibold)).foregroundStyle(Palette.muted)
        }.padding(.vertical, 10).contentShape(Rectangle())
    }

    private var apiKeyBinding: Binding<String> {
        Binding(get: { DeLijnClient.shared.apiKey }, set: { DeLijnClient.shared.apiKey = $0 })
    }

    @MainActor
    private func searchStops() async {
        isSearchingStops = true
        stopSearchMessage = ""
        defer { isSearchingStops = false }
        do {
            async let deLijn = DeLijnClient.shared.searchStops(stopSearchText.trimmingCharacters(in: .whitespacesAndNewlines))
            async let stib = StibClient.shared.searchStops(stopSearchText.trimmingCharacters(in: .whitespacesAndNewlines))
            let term = stopSearchText.trimmingCharacters(in: .whitespacesAndNewlines)
            let combined = ((try? await deLijn) ?? []) + ((try? await stib) ?? [])
                + BelgianStopCatalog.searchStops(term)
            stopResults = Array(combined.filter { matchesSelectedNetwork($0.properties.ENTITEITNUMMER) }.prefix(40))
            if stopResults.isEmpty { stopSearchMessage = "Aucun arrêt trouvé. Essaie un autre nom de lieu." }
            else { stopSearchMessage = "Choisis ton arrêt dans les résultats." }
        } catch {
            stopSearchMessage = "Recherche indisponible : \(error.localizedDescription)"
        }
    }

    @MainActor
    private func findNearbyOriginStop() async {
        isFindingNearbyOrigin = true
        defer { isFindingNearbyOrigin = false }
        stopSearchMessage = "Recherche de l’arrêt le plus proche…"
        do {
            let location = try await DeviceLocationProvider.shared.currentLocation()
            homeAddress = "Ma position actuelle"
            homeLatitude = location.coordinate.latitude
            homeLongitude = location.coordinate.longitude
            isEditingHomeAddress = false
            let nearest = await nearestStops(latitude: location.coordinate.latitude,
                                             longitude: location.coordinate.longitude)
            guard let stop = nearest.min(by: { $0.distanceMeters < $1.distanceMeters }) else {
                stopSearchMessage = noNearbyStopMessage()
                return
            }
            deLijnStopID = stop.stop.properties.STOPID
            deLijnEntityID = stop.stop.properties.ENTITEITNUMMER
            stopName = stop.stop.properties.NAAMHALTE
            homeWalkMinutes = stop.walkMinutes
            rememberWidgetStop(stopID: deLijnStopID, entityID: deLijnEntityID,
                name: stopName, municipality: stop.stop.properties.NAAMGEM)
            await updateHomeWalkingTime(from: location.coordinate,
                to: CLLocationCoordinate2D(latitude: stop.latitude, longitude: stop.longitude))
            stopSearchMessage = "Arrêt choisi : \(stopName) · environ \(stop.walkMinutes) min à pied."
            WidgetDataStore.configure(stopID: deLijnStopID, entityID: deLijnEntityID, stopName: stopName)
            WidgetDataStore.save([])
            WidgetCenter.shared.reloadAllTimelines()
            await loadDepartures()
            navigateToTab(0)
        } catch {
            stopSearchMessage = error.localizedDescription
        }
    }

    @MainActor
    private func searchHomeAddress() async {
        let query = homeAddressQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        guard query.count >= 3 else { return }
        isSearchingHomeAddress = true
        homeAddressResults = []
        isEditingHomeAddress = false
        stopSearchMessage = "Recherche de ton domicile…"
        defer { isSearchingHomeAddress = false }
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        request.region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 50.85, longitude: 4.5),
            span: MKCoordinateSpan(latitudeDelta: 3.3, longitudeDelta: 5.5))
        do {
            let response = try await MKLocalSearch(request: request).start()
            homeAddressResults = response.mapItems.prefix(5).compactMap { item in
                let coordinate = item.placemark.coordinate
                guard coordinate.latitude.isFinite, coordinate.longitude.isFinite,
                      (49.4...51.6).contains(coordinate.latitude), (2.4...6.5).contains(coordinate.longitude) else { return nil }
                return DestinationPlace(name: item.name ?? query,
                    subtitle: item.placemark.title ?? item.placemark.locality ?? "Belgique", coordinate: coordinate)
            }
            stopSearchMessage = homeAddressResults.isEmpty ? "Adresse introuvable en Belgique. Précise la rue et la commune." : "Choisis ton adresse dans la liste."
        } catch {
            stopSearchMessage = "Recherche d’adresse impossible pour le moment."
        }
    }

    @MainActor
    private func selectHomeAddress(_ place: DestinationPlace) async {
        homeAddress = formattedAddress(place)
        homeLatitude = place.coordinate.latitude
        homeLongitude = place.coordinate.longitude
        homeAddressQuery = ""
        homeAddressResults = []
        isFindingNearbyOrigin = true
        stopSearchMessage = "Je cherche l’arrêt le plus proche de chez toi…"
        defer { isFindingNearbyOrigin = false }
        deLijnStopID = ""
        deLijnEntityID = "2"
        stopName = ""
        homeWalkMinutes = 0
        let nearby = await nearestStops(latitude: homeLatitude, longitude: homeLongitude)
        guard let origin = nearby.min(by: { $0.distanceMeters < $1.distanceMeters }) else {
            stopSearchMessage = noNearbyStopMessage(fromAddress: true)
            return
        }
        deLijnStopID = origin.stop.properties.STOPID
        deLijnEntityID = origin.stop.properties.ENTITEITNUMMER
        stopName = origin.stop.properties.NAAMHALTE
        homeWalkMinutes = origin.walkMinutes
        await updateHomeWalkingTime(from: place.coordinate,
            to: CLLocationCoordinate2D(latitude: origin.latitude, longitude: origin.longitude))
        WidgetDataStore.configure(stopID: deLijnStopID, entityID: deLijnEntityID, stopName: stopName)
        WidgetDataStore.save([])
        WidgetCenter.shared.reloadAllTimelines()
        stopSearchMessage = "Départ prêt · marche d’environ \(homeWalkMinutes) min jusqu’à \(stopName)."
        await loadDepartures()
        if let place = selectedPlace { await selectDestinationPlace(place) }
        navigateToTab(0)
    }

    private func formattedAddress(_ place: DestinationPlace) -> String {
        let parts = ([place.name] + place.subtitle.split(separator: ",").map(String.init))
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        var seen = Set<String>()
        return parts.filter { seen.insert($0.lowercased()).inserted }.joined(separator: ", ")
    }

    @MainActor
    private func updateHomeWalkingTime(from home: CLLocationCoordinate2D, to stop: CLLocationCoordinate2D) async {
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: home))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: stop))
        request.transportType = .walking
        do {
            let response = try await MKDirections(request: request).calculate()
            if let route = response.routes.min(by: { $0.expectedTravelTime < $1.expectedTravelTime }) {
                homeWalkMinutes = max(1, Int(ceil(route.expectedTravelTime / 60)))
            }
        } catch {
            // Retain the nearby-stop estimate if detailed walking directions are unavailable.
        }
    }

    @MainActor
    private func loadDepartures() async {
        isLoadingDepartures = true
        defer { isLoadingDepartures = false }
        // Keep the Lock Screen widget linked to the same stop as the app.
        // This also repairs older installs that only cached a departure.
        if !deLijnStopID.isEmpty {
            WidgetDataStore.configure(stopID: deLijnStopID, entityID: deLijnEntityID, stopName: stopName)
        }
        do {
            departures = try await TransitDataClient.departures(stopID: deLijnStopID, entityID: deLijnEntityID)
            departuresLastRefreshEpoch = Date.now.timeIntervalSince1970
            let hasLiveStopBoard = ["2", "stib", "tec", "letec", "nmbs", "sncb"].contains(deLijnEntityID.lowercased())
            if hasLiveStopBoard {
                WidgetDataStore.save(departures.map { WidgetDeparture(line: $0.lineNumber,
                    destination: $0.destination, time: $0.realtimeTime, stop: stopName,
                    scheduledTime: $0.hasScheduledTime ? $0.scheduledTime : nil,
                    vehicleMode: $0.vehicleMode,
                    hasRealtimePrediction: $0.hasRealtimePrediction) })
            } else if WidgetDataStore.load().filter({ $0.time > .now }).isEmpty {
                WidgetDataStore.save([])
            }
            WidgetCenter.shared.reloadAllTimelines()
            if !departures.isEmpty {
                if alarmEnabled {
                    try? await scheduleAlarm()
                }
            }
            if hasLiveStopBoard {
                apiStatus = departures.isEmpty ? "Aucun départ prochain trouvé." : "\(departures.count) départs chargés."
            } else {
                apiStatus = WidgetDataStore.load().contains(where: { $0.time > .now })
                    ? "Départ prévu du trajet · temps réel à confirmer."
                    : "Horaires TEC/SNCB non disponibles pour ce widget."
            }
        } catch {
            apiStatus = error.localizedDescription
        }
    }

    @MainActor
    private func nearestStops(latitude: Double, longitude: Double) async -> [NearbyDeLijnStop] {
        switch transitNetwork {
        case "stib":
            return (try? await StibClient.shared.nearbyStops(latitude: latitude, longitude: longitude, limit: 1)) ?? []
        case "delijn":
            return (try? await DeLijnClient.shared.nearbyStops(latitude: latitude, longitude: longitude, limit: 1)) ?? []
        case "tec":
            return BelgianStopCatalog.nearbyStops(latitude: latitude, longitude: longitude, limitPerAgency: 2)
                .filter { $0.stop.properties.ENTITEITNUMMER == "tec" }
        case "nmbs":
            return BelgianStopCatalog.nearbyStops(latitude: latitude, longitude: longitude, limitPerAgency: 2)
                .filter { $0.stop.properties.ENTITEITNUMMER == "nmbs" }
        default:
            async let delijn = DeLijnClient.shared.nearbyStops(latitude: latitude, longitude: longitude, limit: 1)
            async let stib = StibClient.shared.nearbyStops(latitude: latitude, longitude: longitude, limit: 1)
            return ((try? await delijn) ?? []) + ((try? await stib) ?? [])
                + BelgianStopCatalog.nearbyStops(latitude: latitude, longitude: longitude, limitPerAgency: 1)
        }
    }

    private func noNearbyStopMessage(fromAddress: Bool = false) -> String {
        let area = fromAddress ? "à moins de 3 km de cette adresse" : "près de toi"
        switch transitNetwork {
        case "delijn": return "Aucun arrêt De Lijn trouvé \(area). Cherche par nom."
        case "stib": return "Aucun arrêt STIB trouvé \(area). Cherche par nom."
        case "tec": return "Aucun arrêt TEC trouvé \(area). Cherche par nom."
        case "nmbs": return "Aucune gare SNCB trouvée \(area). Cherche par nom."
        default: return "Aucun arrêt trouvé \(area) sur De Lijn, STIB, TEC ou SNCB. Cherche par nom."
        }
    }

    @MainActor
    private func reselectNearestHomeStop() async {
        guard homeLatitude != 0, homeLongitude != 0 else { return }
        isFindingNearbyOrigin = true
        defer { isFindingNearbyOrigin = false }
        let nearby = await nearestStops(latitude: homeLatitude, longitude: homeLongitude)
        guard let stop = nearby.min(by: { $0.distanceMeters < $1.distanceMeters }) else {
            stopSearchMessage = noNearbyStopMessage()
            return
        }
        deLijnStopID = stop.stop.properties.STOPID
        deLijnEntityID = stop.stop.properties.ENTITEITNUMMER
        stopName = stop.stop.properties.NAAMHALTE
        homeWalkMinutes = stop.walkMinutes
        WidgetDataStore.configure(stopID: deLijnStopID, entityID: deLijnEntityID, stopName: stopName)
        WidgetDataStore.save([])
        WidgetCenter.shared.reloadAllTimelines()
        journeys = []
        selectedDestination = nil
        journeyStatus = ""
        await loadDepartures()
        if let place = selectedPlace { await selectDestinationPlace(place) }
    }

    @MainActor
    private func refreshDepartures() async {
        guard !deLijnStopID.isEmpty else { apiStatus = "Choisis un arrêt depuis l’accueil."; return }
        await loadDepartures()
        WidgetCenter.shared.reloadAllTimelines()
    }

    @MainActor
    private func syncAlarmState() async {
        alarmEnabled = await AlarmScheduler.shared.hasPendingAlarm()
    }

    @MainActor
    private func appBecameActiveForAlarm() async {
        let scheduledAlarm = await AlarmScheduler.shared.hasPendingAlarm()
        let shouldKeepAlarm = UserDefaults.standard.bool(forKey: "busmind-alarm-enabled")
            || alarmEnabled || scheduledAlarm
        await AlarmScheduler.shared.stopAlertingAlarmWhenAppOpens()
        if shouldKeepAlarm && !AlarmScheduler.supportsSystemAlarm {
            do {
                try await scheduleAlarm()
                alarmEnabled = true
                UserDefaults.standard.set(true, forKey: "busmind-alarm-enabled")
            } catch {
                alarmEnabled = false
                UserDefaults.standard.set(false, forKey: "busmind-alarm-enabled")
                alarmMessage = error.localizedDescription
            }
        } else {
            await syncAlarmState()
        }
    }

    @MainActor
    private func scheduleAlarm() async throws {
        try await AlarmScheduler.shared.schedule(
            commuteHour: departureHour,
            commuteMinute: departureMinute,
            minutesBefore: wakeLeadMinutes,
            difficulty: wakeDifficulty,
            weekdays: selectedAlarmWeekdays
        )
    }

    private func setAlarmEnabled(_ enabled: Bool) {
        playInteractionFeedback(success: enabled)
        alarmEnabled = enabled
        UserDefaults.standard.set(enabled, forKey: "busmind-alarm-enabled")
        Task {
            if enabled {
                do {
                    try await scheduleAlarm()
                    alarmMessage = AlarmScheduler.supportsSystemAlarm
                        ? "Réveil programmé · \(selectedAlarmWeekdays.count) jours"
                        : "20 rappels, puis 3 sons longs · \(selectedAlarmWeekdays.count) jours"
                } catch {
                    alarmEnabled = false
                    alarmMessage = error.localizedDescription
                }
            } else {
                await AlarmScheduler.shared.cancel()
                alarmMessage = "Alarme désactivée"
            }
        }
    }

    private func toggleAlarmWeekday(_ weekday: Int) {
        playInteractionFeedback()
        var days = selectedAlarmWeekdays
        if days.contains(weekday) { days.remove(weekday) } else { days.insert(weekday) }
        alarmWeekdays = days.sorted().map(String.init).joined(separator: ",")
    }

    private func alarmWeekdayLabel(_ weekday: Int) -> String {
        [1: "Di", 2: "Lu", 3: "Ma", 4: "Me", 5: "Je", 6: "Ve", 7: "Sa"][weekday] ?? "?"
    }

    @ViewBuilder
    private func weekdayPill(_ weekday: Int) -> some View {
        let place = assignedDestination(for: weekday)
        let active = selectedAlarmWeekdays.contains(weekday)
        let tint = place.map { Palette.line($0.name) } ?? Palette.purple
        if savedDestinations.isEmpty {
            Button { toggleAlarmWeekday(weekday) } label: {
                weekdayPillLabel(weekday, place: nil, active: active, tint: Palette.purple)
            }.buttonStyle(MobiGoPressStyle())
        } else {
            Menu {
                Button("Aucun trajet") { assignDestination(nil, to: weekday) }
                ForEach(savedDestinations) { destination in
                    Button(destination.name) { assignDestination(destination.id, to: weekday) }
                }
            } label: {
                weekdayPillLabel(weekday, place: place, active: active, tint: tint)
            }.buttonStyle(MobiGoPressStyle())
        }
    }

    private func weekdayPillLabel(_ weekday: Int, place: SavedDestination?, active: Bool, tint: Color) -> some View {
        VStack(spacing: 1) {
            Text(alarmWeekdayLabel(weekday)).font(.system(size: 10, weight: .bold))
            if let place {
                Text(String(place.name.prefix(3))).font(.system(size: 7, weight: .bold)).lineLimit(1).minimumScaleFactor(0.65)
            } else if !savedDestinations.isEmpty {
                Image(systemName: "plus").font(.system(size: 7, weight: .bold))
            }
        }
        .foregroundStyle(active ? Color.white : Palette.muted)
        .frame(maxWidth: .infinity).frame(height: savedDestinations.isEmpty ? 32 : 40)
        .background(active ? tint : Palette.elevated, in: Capsule())
        .accessibilityLabel(place.map { "\(alarmWeekdayLongLabel(weekday)), \($0.name)" } ?? "\(alarmWeekdayLongLabel(weekday)), choisir la destination")
    }

    private func assignedDestination(for weekday: Int) -> SavedDestination? {
        guard let id = weekdayDestinationAssignments[String(weekday)] else { return nil }
        return savedDestinations.first(where: { $0.id == id })
    }

    private func saveDestination(_ place: DestinationPlace) {
        let item = SavedDestination(id: SavedDestination.id(for: place), name: place.name,
            subtitle: place.subtitle, latitude: place.coordinate.latitude, longitude: place.coordinate.longitude)
        var places = savedDestinations
        guard !places.contains(where: { $0.id == item.id }) else { return }
        places.append(item)
        if let data = try? JSONEncoder().encode(places), let value = String(data: data, encoding: .utf8) {
            savedDestinationItemsJSON = value
        }
    }

    private func assignDestination(_ id: String?, to weekday: Int) {
        playInteractionFeedback(success: id != nil)
        var assignments = weekdayDestinationAssignments
        assignments[String(weekday)] = id
        if let data = try? JSONEncoder().encode(assignments), let value = String(data: data, encoding: .utf8) {
            weekdayDestinationAssignmentsJSON = value
        }
        var activeDays = selectedAlarmWeekdays
        if id == nil { activeDays.remove(weekday) } else { activeDays.insert(weekday) }
        alarmWeekdays = activeDays.sorted().map(String.init).joined(separator: ",")
        if alarmEnabled { Task { try? await scheduleAlarm() } }
        guard !deLijnStopID.isEmpty, let scheduled = nextAssignedDestination(after: .now) else { return }
        Task { await selectDestinationPlace(scheduled.place.destinationPlace, prepareAlarm: alarmEnabled) }
    }

    private func alarmWeekdayLongLabel(_ weekday: Int) -> String {
        [1: "Dimanche", 2: "Lundi", 3: "Mardi", 4: "Mercredi", 5: "Jeudi", 6: "Vendredi", 7: "Samedi"][weekday] ?? "Jour"
    }

    private var routesSheet: some View {
        NavigationView {
            Form {
                routeSearchSection
                if !journeyStatus.isEmpty { journeyStatusSection }
                if !journeys.isEmpty { journeyOptionsSection }
                savedRouteSection
            }
            .scrollContentBackground(.hidden)
            .background(Palette.background)
            .foregroundStyle(Palette.text)
            .tint(Palette.purple)
            .listRowBackground(Palette.card)
            .listRowSeparatorTint(Palette.muted.opacity(0.2))
            .navigationTitle("Étapes du trajet")
            .navigationBarItems(trailing: Button("Accueil") { navigateToTab(0) })
            .onAppear(perform: restoreDestination)
        }
    }

    private var routeSearchSection: some View {
        Section("Chercher un trajet") {
            Text("Départ : \(homeAddress.isEmpty ? (deLijnStopID.isEmpty ? "ajoute ton adresse dans Configuration" : stopName) : displayHomeAddress)")
                .font(.footnote).foregroundStyle(Palette.muted)
            if !homeAddress.isEmpty, !stopName.isEmpty {
                Text("Arrêt choisi automatiquement : \(stopName) · marche \(homeWalkMinutes) min")
                    .font(.caption).foregroundStyle(Palette.muted)
            }
            TextField("Où veux-tu aller ?", text: $destination)
                .textInputAutocapitalization(.words).autocorrectionDisabled()
            Button { Task { await searchDestinationStops() } } label: {
                Label(isSearchingJourneys ? "Recherche…" : "Chercher un trajet", systemImage: "magnifyingglass")
            }
            .disabled(isSearchingJourneys || destination.count < 2)
            if !destinationPlaceResults.isEmpty {
                Text("LIEUX ET ADRESSES").font(.caption2.bold()).foregroundStyle(Palette.muted)
                ForEach(destinationPlaceResults) { place in destinationPlaceRow(place) }
            }
            if !destinationResults.isEmpty {
                Text("ARRÊTS DE LIJN · OPTIONNEL").font(.caption2.bold()).foregroundStyle(Palette.muted)
                ForEach(destinationResults) { stop in destinationStopRow(stop) }
            }
            if let selectedPlace {
                Label(isSearchingJourneys ? "Je prépare le meilleur trajet…" : "Destination : \(selectedPlace.name)", systemImage: isSearchingJourneys ? "arrow.triangle.2.circlepath" : "mappin.and.ellipse")
                    .font(.caption.weight(.semibold)).foregroundStyle(Palette.purple)
                DatePicker("Arriver vers", selection: Binding(
                    get: { arrivalTargetDate },
                    set: { arriveByHour = Calendar.current.component(.hour, from: $0); arriveByMinute = Calendar.current.component(.minute, from: $0) }
                ), displayedComponents: .hourAndMinute).tint(Palette.purple)
                Button { Task { await selectDestinationPlace(selectedPlace) } } label: {
                    Label(isSearchingJourneys ? "Calcul du trajet…" : "Recalculer pour cette heure", systemImage: "clock.badge.checkmark")
                }.disabled(isSearchingJourneys)
            }
            if selectedPlace == nil, let selectedDestination {
                DatePicker("Arriver vers", selection: Binding(
                    get: { arrivalTargetDate },
                    set: { arriveByHour = Calendar.current.component(.hour, from: $0); arriveByMinute = Calendar.current.component(.minute, from: $0) }
                ), displayedComponents: .hourAndMinute).tint(Palette.purple)
                Button { Task { await findJourneys(to: selectedDestination) } } label: {
                    Label(isSearchingJourneys ? "Recherche…" : "Calculer pour cette heure", systemImage: "sparkles")
                }.disabled(isSearchingJourneys)
            }
        }
    }

    private func destinationPlaceRow(_ place: DestinationPlace) -> some View {
        Button { playInteractionFeedback(); Task { await selectDestinationPlace(place) } } label: {
            HStack(spacing: 10) {
                Image(systemName: "figure.walk").foregroundStyle(Palette.purple)
                VStack(alignment: .leading, spacing: 3) {
                    Text(place.name).foregroundStyle(.primary).lineLimit(1)
                    Text(place.subtitle.isEmpty ? "Lieu · arrêts à proximité" : "\(place.subtitle) · arrêts à proximité")
                        .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption).foregroundStyle(Palette.muted)
            }
        }
    }

    private func nearbyStopRow(_ nearby: NearbyDeLijnStop, place: DestinationPlace) -> some View {
        Button {
            playInteractionFeedback(success: true)
            selectedDestination = nearby.stop
            destinationName = place.name
            destinationMunicipality = place.subtitle
            destinationStopID = nearby.stop.properties.STOPID
            destinationEntityID = nearby.stop.properties.ENTITEITNUMMER
            destinationLatitude = place.coordinate.latitude
            destinationLongitude = place.coordinate.longitude
            mapFinalStopCoordinate = CLLocationCoordinate2D(latitude: nearby.latitude, longitude: nearby.longitude)
            finalWalkMinutes = nearby.walkMinutes
            finalWalkIsApproximate = true
            journeys = []
            journeyStatus = "Marche estimée : environ \(nearby.walkMinutes) min depuis \(nearby.stop.properties.NAAMHALTE)"
            updateMapRegion()
            Task { await updateWalkingTime(from: nearby, to: place) }
        } label: {
            HStack(spacing: 10) {
                Image(systemName: "mappin.and.ellipse").foregroundStyle(Palette.blue)
                VStack(alignment: .leading, spacing: 3) {
                    Text(nearby.stop.properties.NAAMHALTE).foregroundStyle(.primary).lineLimit(1)
                    Text("\(networkLabel(nearby.stop.properties.ENTITEITNUMMER)) · \(nearby.stop.properties.NAAMGEM) · arrêt \(nearby.stop.properties.STOPID)")
                        .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer()
                Text("≈ \(nearby.walkMinutes) min à pied").font(.caption.bold()).foregroundStyle(Palette.purple)
                if selectedDestination?.id == nearby.stop.id {
                    Image(systemName: "checkmark.circle.fill").foregroundStyle(Palette.purple)
                }
            }
        }
    }

    private func destinationStopRow(_ stop: StopFeature) -> some View {
        Button {
            playInteractionFeedback(success: true)
            selectedDestination = stop
            selectedPlace = nil
            destination = stop.properties.NAAMHALTE
            nearbyDestinationStops = []
            finalWalkMinutes = 0
            finalWalkIsApproximate = true
            destinationLatitude = 0
            destinationLongitude = 0
            mapDestinationCoordinate = nil
            mapFinalStopCoordinate = nil
            Task { await loadMapDestinationStopCoordinate(stop) }
            destinationName = stop.properties.NAAMHALTE
            destinationStopID = stop.properties.STOPID
            destinationEntityID = stop.properties.ENTITEITNUMMER
            destinationMunicipality = stop.properties.NAAMGEM
            journeys = []
            journeyStatus = ""
        } label: {
            HStack {
                VStack(alignment: .leading) {
                    Text(stop.properties.NAAMHALTE).foregroundStyle(.primary)
                    Text("\(networkLabel(stop.properties.ENTITEITNUMMER)) · \(stop.properties.NAAMGEM) · arrêt \(stop.properties.STOPID)").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                if selectedDestination?.id == stop.id { Image(systemName: "checkmark.circle.fill").foregroundStyle(Palette.purple) }
            }
        }
    }

    @MainActor
    private func findJourneys(to destinationStop: StopFeature, prepareAlarm: Bool = true) async {
        guard !enabledTransitModes.isEmpty else {
            journeyStatus = "Choisis au moins un moyen de transport dans Configuration."
            return
        }
        guard !deLijnStopID.isEmpty else { journeyStatus = "Choisis d’abord ton arrêt de départ."; return }
        let destinationIsStib = destinationStop.properties.ENTITEITNUMMER.lowercased() == "stib"
        if transitNetwork == "auto" || transitNetwork == "tec" || transitNetwork == "nmbs" {
            if let coordinate = try? await resolvedStopCoordinate(
                stopID: destinationStop.properties.STOPID,
                entityID: destinationStop.properties.ENTITEITNUMMER) {
                let place = DestinationPlace(name: destinationStop.properties.NAAMHALTE,
                    subtitle: destinationStop.properties.NAAMGEM,
                    coordinate: CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude))
                if await selectBelgianUnifiedJourney(to: place, prepareAlarm: prepareAlarm) { return }
                if transitNetwork != "auto" { return }
                if destinationIsStib && (allowedPlannerNetworks == nil || allowedPlannerNetworks?.contains("stib") == true) {
                    await selectStibDestinationPlace(place, prepareAlarm: prepareAlarm)
                    return
                }
                if destinationIsStib, allowedPlannerNetworks != nil {
                    journeyStatus = "Cette arrivée demande un trajet STIB. Ajoute STIB ou autorise les réseaux payants."
                    return
                }
            }
            if let allowed = allowedPlannerNetworks,
               !allowed.contains("delijn"), !allowed.contains("stib") {
                journeyStatus = "Aucun trajet trouvé avec les abonnements choisis. Active les autres réseaux pour voir leur prix."
                return
            }
        } else if transitNetwork == "stib" || destinationIsStib {
            guard let coordinate = try? await resolvedStopCoordinate(
                stopID: destinationStop.properties.STOPID,
                entityID: destinationStop.properties.ENTITEITNUMMER) else {
                journeyStatus = "Coordonnées de l’arrêt STIB indisponibles."
                return
            }
            let place = DestinationPlace(name: destinationStop.properties.NAAMHALTE,
                subtitle: destinationStop.properties.NAAMGEM,
                coordinate: CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude))
            await selectStibDestinationPlace(place, prepareAlarm: prepareAlarm)
            return
        }
        guard !enabledTransitModes.isDisjoint(with: ["BUS", "TRAM", "SUBWAY"]) else {
            journeyStatus = "Aucun trajet trouvé avec ces moyens de transport. Active le train ou un réseau bus/tram."
            return
        }
        var stibFallbackPlace: DestinationPlace?
        if transitNetwork == "auto",
           let coordinate = try? await resolvedStopCoordinate(
            stopID: destinationStop.properties.STOPID,
            entityID: destinationStop.properties.ENTITEITNUMMER) {
            stibFallbackPlace = DestinationPlace(name: destinationStop.properties.NAAMHALTE,
                subtitle: destinationStop.properties.NAAMGEM,
                coordinate: CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude))
        }
        isSearchingJourneys = true
        journeyStatus = "Recherche des meilleurs trajets…"
        liveDelayByLeg = [:]
        defer { isSearchingJourneys = false }
        do {
            let origin = StopFeature(id: "\(deLijnEntityID)-\(deLijnStopID)", properties: StopProperties(
                ENTITEITNUMMER: deLijnEntityID, STOPID: deLijnStopID, NAAMHALTE: stopName, NAAMGEM: ""))
            let options = try await DeLijnClient.shared.planJourneys(from: origin, to: destinationStop,
                after: .now.addingTimeInterval(TimeInterval(homeWalkMinutes * 60)),
                arrivingBy: arrivalTargetDate, finalWalkMinutes: finalWalkMinutes,
                fallbackArrivalBy: fallbackArrivalTargetDate)
            journeys = Array(options.filter { journeyMatchesCurrentFilters($0) }.prefix(1))
            if let recommended = journeys.first {
                DeLijnJourneyCache.save(recommended, originStopID: deLijnStopID,
                    originStopName: stopName, homeWalkMinutes: homeWalkMinutes,
                    destinationStopID: destinationStop.properties.STOPID,
                    destinationEntityID: destinationStop.properties.ENTITEITNUMMER,
                    destinationName: destinationName,
                    targetArrival: arrivalTargetDate, homeLatitude: homeLatitude,
                    homeLongitude: homeLongitude, destinationLatitude: destinationLatitude,
                    destinationLongitude: destinationLongitude)
                journeyStatus = "\(vehicleSummary(mode: recommended.firstLegMode, line: recommended.line)) vers \(recommended.lineDirection.isEmpty ? recommended.destination : recommended.lineDirection)."
                syncDepartureTime(with: recommended)
                lastRouteRefresh = .now
                if prepareAlarm { useJourney(recommended) }
                navigateToTab(0)
                Task { await refreshJourneyPredictions(for: recommended) }
            } else {
                if let stibFallbackPlace {
                    await selectStibDestinationPlace(stibFallbackPlace, prepareAlarm: prepareAlarm)
                    return
                }
                journeyStatus = "Aucun trajet trouvé aujourd’hui ni demain."
            }
        } catch {
            if let stibFallbackPlace {
                await selectStibDestinationPlace(stibFallbackPlace, prepareAlarm: prepareAlarm)
                return
            }
            journeyStatus = error.localizedDescription
        }
    }

    private var journeyStatusSection: some View {
        Section { Text(journeyStatus).font(.footnote).foregroundStyle(Palette.muted) }
    }

    private var journeyOptionsSection: some View {
        Section("Ton trajet conseillé") {
            ForEach(journeys) { trip in journeyOptionRow(trip) }
        }
    }

    private func journeyOptionRow(_ trip: DeLijnJourney) -> some View {
        let lineColors = journeyLineColors(for: trip)
        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                lineBadge(trip.line, mode: trip.firstLegMode, color: lineColors[0])
                if let secondLine = trip.secondLine {
                    Image(systemName: "arrow.right").font(.caption).foregroundStyle(.secondary)
                    lineBadge(secondLine, mode: trip.secondLegMode, color: lineColors[1])
                }
                if let thirdLine = trip.thirdLine {
                    Image(systemName: "arrow.right").font(.caption).foregroundStyle(.secondary)
                    lineBadge(thirdLine, mode: trip.thirdLegMode, color: lineColors[2])
                }
                VStack(alignment: .leading, spacing: 3) {
                    Text(journeyTimeLabel(trip)).font(.subheadline.bold())
                    Text(journeySubtitle(trip)).font(.caption).foregroundStyle(trip.delayMinutes > 0 && trip.transferStop == nil ? Palette.pink : .secondary)
                }
            }
            Text("→ \(trip.lineDirection.isEmpty ? trip.destination : trip.lineDirection)")
                .font(.caption).foregroundStyle(Palette.muted).lineLimit(1)
                if trip.secondLine != nil {
                Text("→ \(trip.secondLineDirection ?? trip.destination)")
                    .font(.caption).foregroundStyle(Palette.muted).lineLimit(1)
            }
            if trip.thirdLine != nil {
                Text("→ \(trip.thirdLineDirection ?? trip.destination)")
                    .font(.caption).foregroundStyle(Palette.muted).lineLimit(1)
            }
            if let stop = trip.transferStop {
                Label("Changer à \(stop)", systemImage: "arrow.triangle.branch")
                    .font(.caption.weight(.semibold)).foregroundStyle(Palette.muted)
            }
            if let stop = trip.secondTransferStop {
                Label("Changer à \(stop)", systemImage: "arrow.triangle.branch")
                    .font(.caption.weight(.semibold)).foregroundStyle(Palette.muted)
            }
        }
    }

    private func journeyLineColors(for trip: DeLijnJourney) -> [Color] {
        let count = trip.thirdLine != nil ? 3 : trip.secondLine != nil ? 2 : 1
        return (0..<count).map(Palette.routeLine)
    }

    private func lineBadge(_ line: String, mode: String?, color: Color) -> some View {
        HStack(spacing: 4) {
            Image(systemName: vehicleIcon(mode)).font(.system(size: 10, weight: .bold))
            Text(line).font(.caption.bold())
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 8).padding(.vertical, 7)
        .background(color, in: RoundedRectangle(cornerRadius: 7))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(vehicleName(mode).capitalized) \(line)")
    }

    private func journeyTimeLabel(_ trip: DeLijnJourney) -> String {
        let departure = trip.departure.formatted(date: .abbreviated, time: .shortened)
        let destinationArrival = estimatedArrival(for: trip).addingTimeInterval(TimeInterval(finalWalkMinutes * 60))
        let arrival = destinationArrival.formatted(date: .omitted, time: .shortened)
        return "\(departure) → \(arrival)"
    }

    private func journeySubtitle(_ trip: DeLijnJourney) -> String {
        let changes = [trip.transferStop, trip.secondTransferStop].compactMap { $0 }.count
        var summary = "\(trip.durationMinutes) min · \(changes == 0 ? "direct" : "\(changes) changement\(changes > 1 ? "s" : "")")"
        if !trip.hasRealtimePrediction {
            summary += " · horaire prévu"
        } else if trip.delayMinutes > 1 {
            summary += " · +\(trip.delayMinutes) min"
        } else if trip.delayMinutes < -1 {
            summary += " · −\(-trip.delayMinutes) min"
        } else {
            summary += " · à l’heure"
        }
        return summary
    }

    private var savedRouteSection: some View {
        Section("Trajet favori") {
            HStack { Text("Destination"); Spacer(); Text(destinationName).foregroundStyle(Palette.muted) }
            HStack { Text("Domicile"); Spacer(); Text(homeAddress.isEmpty ? "À ajouter" : displayHomeAddress).foregroundStyle(Palette.muted).lineLimit(1) }
            if !stopName.isEmpty { HStack { Text("Arrêt choisi par MobiGo"); Spacer(); Text("\(stopName) · marche \(homeWalkMinutes) min").foregroundStyle(Palette.muted).lineLimit(1) } }
            HStack { Text("Départ"); Spacer(); Text(departureDate.formatted(date: .omitted, time: .shortened)).foregroundStyle(Palette.muted) }
            Text("Horaires officiels du jour, demain si besoin · jusqu’à deux correspondances. Choisis un trajet pour régler ton réveil.")
                .font(.footnote).foregroundStyle(Palette.muted)
        }
    }

    private func restoreDestination() {
        guard selectedDestination == nil, !destinationStopID.isEmpty else { return }
        selectedDestination = StopFeature(
            id: "\(destinationEntityID)-\(destinationStopID)",
            properties: StopProperties(ENTITEITNUMMER: destinationEntityID, STOPID: destinationStopID,
                NAAMHALTE: destinationName, NAAMGEM: destinationMunicipality)
        )
    }

    private func restoreCachedJourneyIfAvailable() {
        guard !deLijnStopID.isEmpty, !destinationStopID.isEmpty,
              let cached = DeLijnJourneyCache.load(
                originStopID: deLijnStopID, destinationStopID: destinationStopID,
                targetArrival: arrivalTargetDate, homeLatitude: homeLatitude,
                homeLongitude: homeLongitude, destinationLatitude: destinationLatitude,
                destinationLongitude: destinationLongitude) else { return }
        guard journeyMatchesCurrentFilters(cached.journey) else {
            // A route saved under previous mode or pass settings must never
            // briefly reappear when the app starts offline.
            DeLijnJourneyCache.clear()
            journeyStatus = "Choix mis à jour · enregistre le trajet pour recalculer."
            return
        }
        deLijnStopID = cached.originStopID
        stopName = cached.originStopName
        homeWalkMinutes = cached.homeWalkMinutes
        destinationStopID = cached.destinationStopID
        destinationEntityID = cached.destinationEntityID
        destinationName = cached.destinationName
        selectedDestination = StopFeature(
            id: "\(cached.destinationEntityID)-\(cached.destinationStopID)",
            properties: StopProperties(ENTITEITNUMMER: cached.destinationEntityID,
                STOPID: cached.destinationStopID, NAAMHALTE: cached.destinationName,
                NAAMGEM: destinationMunicipality))
        journeys = [cached.journey]
    }

    private func clearJourneyIfFiltersExcludeIt() {
        guard let journey = journeys.first, !journeyMatchesCurrentFilters(journey) else { return }
        journeys = []
        journeyStatus = "Choix mis à jour · enregistre le trajet pour recalculer."
        DeLijnJourneyCache.clear()
    }

    @MainActor
    private func useJourney(_ journey: DeLijnJourney) {
        syncDepartureTime(with: journey)
        let time = journey.departure.formatted(date: .omitted, time: .shortened)
        alarmEnabled = true
        Task {
            do {
                try await scheduleAlarm()
                alarmMessage = AlarmScheduler.supportsSystemAlarm
                    ? "Réveil recalculé pour le départ de \(time)"
                    : "Alerte hebdomadaire réglée pour le départ de \(time)"
            } catch {
                alarmEnabled = false
                journeyStatus = error.localizedDescription
                alarmMessage = error.localizedDescription
            }
        }
    }

    private func syncDepartureTime(with journey: DeLijnJourney) {
        departureHour = Calendar.current.component(.hour, from: journey.departure)
        departureMinute = Calendar.current.component(.minute, from: journey.departure)
    }

    private func openDestinationSearch() {
        playInteractionFeedback()
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.22)) { navigateToTab(4) }
        Task { await searchDestinationStops() }
    }

    @MainActor
    private func searchDestinationStops() async {
        let term = destination.trimmingCharacters(in: .whitespacesAndNewlines)
        guard term.count >= 2 else { return }
        isSearchingJourneys = true
        journeyStatus = ""
        destinationResults = []
        destinationPlaceResults = []
        nearbyDestinationStops = []
        selectedPlace = nil
        selectedDestination = nil
        journeys = []
        liveDelayByLeg = [:]
        scheduledReminderTripID = nil
        Task { try? await AlarmScheduler.shared.scheduleTransferReminders([]) }
        defer { isSearchingJourneys = false }
        async let deLijnStops = try? DeLijnClient.shared.searchStops(term)
        async let stibStops = try? StibClient.shared.searchStops(term)
        let allStops = ((await deLijnStops) ?? []) + ((await stibStops) ?? []) + BelgianStopCatalog.searchStops(term)
        destinationResults = allStops.filter { stop in
            matchesSelectedNetwork(stop.properties.ENTITEITNUMMER)
        }

        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = term
        request.region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 50.85, longitude: 4.5),
            span: MKCoordinateSpan(latitudeDelta: 3.3, longitudeDelta: 5.5))
        do {
            let response = try await MKLocalSearch(request: request).start()
            destinationPlaceResults = response.mapItems.prefix(5).compactMap { item in
                let coordinate = item.placemark.coordinate
                guard coordinate.latitude.isFinite, coordinate.longitude.isFinite,
                      abs(coordinate.latitude) > 0.01, abs(coordinate.longitude) > 0.01 else { return nil }
                let name = item.name ?? item.placemark.title ?? term
                let locality = item.placemark.locality ?? item.placemark.subAdministrativeArea ?? ""
                return DestinationPlace(name: name, subtitle: locality, coordinate: coordinate)
            }
        } catch {
            if destinationResults.isEmpty { journeyStatus = "Aucun lieu trouvé. Essaie une adresse ou le nom d’un arrêt." }
        }
        if destinationResults.isEmpty && destinationPlaceResults.isEmpty && journeyStatus.isEmpty {
            journeyStatus = "Aucun arrêt ni lieu trouvé. Vérifie l’orthographe."
        }
    }

    @MainActor
    private func selectDestinationPlace(_ place: DestinationPlace, prepareAlarm: Bool = true) async {
        guard !enabledTransitModes.isEmpty else {
            journeyStatus = "Choisis au moins un moyen de transport dans Configuration."
            return
        }
        if transitNetwork == "auto" || transitNetwork == "tec" || transitNetwork == "nmbs" {
            if await selectBelgianUnifiedJourney(to: place, prepareAlarm: prepareAlarm) { return }
            if transitNetwork != "auto" { return }
        }
        if transitNetwork == "auto",
           let allowed = allowedPlannerNetworks,
           !allowed.contains("delijn"), allowed.contains("stib") {
            await selectStibDestinationPlace(place, prepareAlarm: prepareAlarm)
            return
        }
        if transitNetwork == "stib" {
            await selectStibDestinationPlace(place, prepareAlarm: prepareAlarm)
            return
        }
        guard !enabledTransitModes.isDisjoint(with: ["BUS", "TRAM", "SUBWAY"]) else {
            journeyStatus = "Aucun trajet trouvé avec ces moyens de transport. Active le train ou un réseau bus/tram."
            return
        }
        let keepsCurrentRoute = journeys.first != nil
            && abs(destinationLatitude - place.coordinate.latitude) < 0.0005
            && abs(destinationLongitude - place.coordinate.longitude) < 0.0005
        selectedPlace = place
        selectedDestination = nil
        destination = place.name
        nearbyDestinationStops = []
        if !keepsCurrentRoute { journeys = [] }
        liveDelayByLeg = [:]
        destinationName = place.name
        destinationMunicipality = place.subtitle
        destinationLatitude = place.coordinate.latitude
        destinationLongitude = place.coordinate.longitude
        mapDestinationCoordinate = place.coordinate
        updateMapRegion()
        finalWalkMinutes = 0
        journeyStatus = "Recherche des arrêts les plus proches…"
        isSearchingJourneys = true
        defer { isSearchingJourneys = false }
        do {
            if let allowed = allowedPlannerNetworks,
               !allowed.contains("delijn"), !allowed.contains("stib") {
                journeyStatus = "Aucun trajet trouvé avec les abonnements choisis. Active les autres réseaux pour voir leur prix."
                return
            }
            nearbyDestinationStops = try await DeLijnClient.shared.nearbyStops(
                latitude: place.coordinate.latitude, longitude: place.coordinate.longitude, limit: 3)
            guard !nearbyDestinationStops.isEmpty else {
                if transitNetwork == "auto", allowedPlannerNetworks == nil || allowedPlannerNetworks?.contains("stib") == true {
                    await selectStibDestinationPlace(place, prepareAlarm: prepareAlarm)
                    return
                }
                journeyStatus = "Aucun arrêt De Lijn trouvé à moins de 3 km. Essaie une adresse voisine."
                return
            }
            let destinationWalkEstimates = await withTaskGroup(of: (String, WalkEstimate).self) { group in
                for nearby in nearbyDestinationStops {
                    let stopID = nearby.stop.id
                    let destinationCoordinate = place.coordinate
                    group.addTask {
                        (stopID, await WalkingRouteEstimator.estimate(from: nearby, to: destinationCoordinate))
                    }
                }
                var estimates: [String: WalkEstimate] = [:]
                for await (stopID, estimate) in group { estimates[stopID] = estimate }
                return estimates
            }
            var originCandidates: [(stop: StopFeature, walkMinutes: Int)] = []
            if homeLatitude != 0, homeLongitude != 0 {
                let nearbyOrigins = try await DeLijnClient.shared.nearbyStops(
                    latitude: homeLatitude, longitude: homeLongitude, limit: 3)
                guard !nearbyOrigins.isEmpty else {
                    if transitNetwork == "auto", allowedPlannerNetworks == nil || allowedPlannerNetworks?.contains("stib") == true {
                        await selectStibDestinationPlace(place, prepareAlarm: prepareAlarm)
                        return
                    }
                    journeyStatus = "Aucun arrêt De Lijn trouvé près de ton domicile."
                    return
                }
                // Keep the previously resolved home platform first when it is
                // still among the nearby results. Opposite platforms can be only
                // a few metres closer while sending the rider the wrong way;
                // retrying those first can consume the whole route-search budget.
                let configuredOriginID = "\(deLijnEntityID)-\(deLijnStopID)"
                let orderedOrigins = nearbyOrigins.sorted { lhs, rhs in
                    let lhsIsConfigured = lhs.stop.id == configuredOriginID
                    let rhsIsConfigured = rhs.stop.id == configuredOriginID
                    if lhsIsConfigured != rhsIsConfigured { return lhsIsConfigured }
                    return lhs.distanceMeters < rhs.distanceMeters
                }
                let homeCoordinate = CLLocationCoordinate2D(latitude: homeLatitude, longitude: homeLongitude)
                let originWalkEstimates = await withTaskGroup(of: (String, WalkEstimate).self) { group in
                    for nearby in orderedOrigins where nearby.stop.id != configuredOriginID || homeWalkMinutes <= 0 {
                        let stopID = nearby.stop.id
                        group.addTask {
                            (stopID, await WalkingRouteEstimator.estimate(from: nearby, to: homeCoordinate))
                        }
                    }
                    var estimates: [String: WalkEstimate] = [:]
                    for await (stopID, estimate) in group { estimates[stopID] = estimate }
                    return estimates
                }
                originCandidates = orderedOrigins.map { nearby in
                    let minutes = nearby.stop.id == configuredOriginID && homeWalkMinutes > 0
                        ? homeWalkMinutes : originWalkEstimates[nearby.stop.id]?.minutes ?? nearby.walkMinutes
                    return (nearby.stop, minutes)
                }
            } else if deLijnStopID.isEmpty {
                if transitNetwork == "auto", allowedPlannerNetworks == nil || allowedPlannerNetworks?.contains("stib") == true {
                    await selectStibDestinationPlace(place, prepareAlarm: prepareAlarm)
                    return
                }
                journeyStatus = "Ajoute ton adresse de départ. MobiGo trouvera l’arrêt le plus proche."
                return
            } else {
                let selectedOrigin = StopFeature(id: "\(deLijnEntityID)-\(deLijnStopID)", properties: StopProperties(
                    ENTITEITNUMMER: deLijnEntityID, STOPID: deLijnStopID, NAAMHALTE: stopName, NAAMGEM: ""))
                originCandidates = [(selectedOrigin, homeWalkMinutes)]
            }
            var candidates: [PlannedJourneyCandidate] = []
            let desiredArrival = arrivalTargetDate
            let fallbackArrival = fallbackArrivalTargetDate
            let searchDeadline = Date.now.addingTimeInterval(40)
            var searchTimedOut = false
            for origin in originCandidates {
                guard Date.now < searchDeadline else { searchTimedOut = true; break }
                let destinationStops = Array(nearbyDestinationStops.prefix(3))
                for start in stride(from: 0, to: destinationStops.count, by: 2) {
                    guard Date.now < searchDeadline else { searchTimedOut = true; break }
                    let batch = Array(destinationStops[start..<min(start + 2, destinationStops.count)])
                    let options = await withTaskGroup(of: [PlannedJourneyCandidate].self) { group in
                        for nearby in batch {
                            let destinationWalk = destinationWalkEstimates[nearby.stop.id]
                                ?? WalkEstimate(minutes: nearby.walkMinutes, distanceMeters: nil)
                            group.addTask {
                                let earliest = Date.now.addingTimeInterval(TimeInterval(origin.walkMinutes * 60))
                                let trips = (try? await DeLijnClient.shared.planJourneys(from: origin.stop, to: nearby.stop,
                                    after: earliest, arrivingBy: desiredArrival,
                                    finalWalkMinutes: destinationWalk.minutes,
                                    fallbackArrivalBy: fallbackArrival)) ?? []
                                return trips.map { PlannedJourneyCandidate(trip: $0, stop: nearby,
                                    origin: origin.stop, originWalk: origin.walkMinutes,
                                    destinationWalk: destinationWalk) }
                            }
                        }
                        var collected: [PlannedJourneyCandidate] = []
                        for await groupResult in group { collected.append(contentsOf: groupResult) }
                        return collected
                    }
                    let eligibleOptions = options.filter { journeyMatchesCurrentFilters($0.trip) }
                    if !eligibleOptions.isEmpty {
                        candidates = eligibleOptions
                        break
                    }
                    if Date.now >= searchDeadline { searchTimedOut = true; break }
                }
                if !candidates.isEmpty { break }
                if searchTimedOut { break }
            }
            guard let best = candidates.max(by: {
                $0.trip.arrival.addingTimeInterval(TimeInterval($0.destinationWalk.minutes * 60)) <
                $1.trip.arrival.addingTimeInterval(TimeInterval($1.destinationWalk.minutes * 60))
            }) else {
                if transitNetwork == "auto", allowedPlannerNetworks == nil || allowedPlannerNetworks?.contains("stib") == true {
                    await selectStibDestinationPlace(place, prepareAlarm: prepareAlarm)
                    return
                }
                journeyStatus = searchTimedOut
                    ? "La recherche prend trop de temps. Appuie sur Actualiser pour réessayer."
                    : "Aucun trajet trouvé pour le moment. Essaie un autre lieu ou réessaie plus tard."
                return
            }
            deLijnStopID = best.origin.properties.STOPID
            deLijnEntityID = best.origin.properties.ENTITEITNUMMER
            stopName = best.origin.properties.NAAMHALTE
            homeWalkMinutes = best.originWalk
            WidgetDataStore.configure(stopID: deLijnStopID, entityID: deLijnEntityID, stopName: stopName)
            selectedDestination = best.stop.stop
            destinationStopID = best.stop.stop.properties.STOPID
            destinationEntityID = best.stop.stop.properties.ENTITEITNUMMER
            destinationLatitude = place.coordinate.latitude
            destinationLongitude = place.coordinate.longitude
            destinationMunicipality = place.subtitle
            finalWalkMinutes = best.destinationWalk.minutes
            finalWalkIsApproximate = best.destinationWalk.distanceMeters == nil
            mapFinalStopCoordinate = CLLocationCoordinate2D(latitude: best.stop.latitude, longitude: best.stop.longitude)
            journeys = [best.trip]
            DeLijnJourneyCache.save(best.trip, originStopID: deLijnStopID,
                originStopName: stopName, homeWalkMinutes: homeWalkMinutes,
                destinationStopID: destinationStopID,
                destinationEntityID: destinationEntityID, destinationName: destinationName,
                targetArrival: desiredArrival,
                homeLatitude: homeLatitude, homeLongitude: homeLongitude,
                destinationLatitude: place.coordinate.latitude,
                destinationLongitude: place.coordinate.longitude)
            syncDepartureTime(with: best.trip)
            // Keep the widget as a live board for the configured stop. Route
            // departures belong to the trip card and must not overwrite it.
            WidgetCenter.shared.reloadAllTimelines()
            lastRouteRefresh = .now
            updateMapRegion()
            journeyStatus = "\(vehicleSummary(mode: best.trip.firstLegMode, line: best.trip.line)) vers \(best.trip.lineDirection.isEmpty ? best.trip.destination : best.trip.lineDirection) · arrêt \(best.stop.stop.properties.NAAMHALTE) · \(best.destinationWalk.minutes) min à pied\(best.destinationWalk.distanceMeters == nil ? " environ" : "")."
            if prepareAlarm { useJourney(best.trip) }
            navigateToTab(0)
            Task { await refreshJourneyPredictions(for: best.trip) }
        } catch {
            if transitNetwork == "auto" {
                await selectStibDestinationPlace(place, prepareAlarm: prepareAlarm)
                return
            }
            journeyStatus = "Recherche des arrêts indisponible : \(error.localizedDescription)"
        }
    }

    @MainActor
    private func selectBelgianUnifiedJourney(to place: DestinationPlace, prepareAlarm: Bool) async -> Bool {
        let keepsCurrentRoute = journeys.first != nil
            && abs(destinationLatitude - place.coordinate.latitude) < 0.0005
            && abs(destinationLongitude - place.coordinate.longitude) < 0.0005
        selectedPlace = place
        selectedDestination = nil
        destination = place.name
        destinationName = place.name
        destinationMunicipality = place.subtitle
        destinationLatitude = place.coordinate.latitude
        destinationLongitude = place.coordinate.longitude
        mapDestinationCoordinate = place.coordinate
        if !keepsCurrentRoute {
            journeys = []
            liveDelayByLeg = [:]
        }
        journeyStatus = "Je cherche le meilleur trajet…"
        isSearchingJourneys = true
        defer { isSearchingJourneys = false }

        do {
            let originCoordinate: (latitude: Double, longitude: Double)
            if homeLatitude != 0 && homeLongitude != 0 {
                originCoordinate = (homeLatitude, homeLongitude)
            } else if !deLijnStopID.isEmpty {
                if deLijnEntityID.lowercased() == "stib",
                   let coordinate = try await StibSchedulePlanner.shared.coordinate(for: deLijnStopID) {
                    originCoordinate = coordinate
                } else {
                    if let coordinate = BelgianStopCatalog.coordinate(
                        stopID: deLijnStopID, entityID: deLijnEntityID) {
                        originCoordinate = coordinate
                    } else {
                        originCoordinate = try await DeLijnClient.shared.stopCoordinate(
                            stopID: deLijnStopID, entityID: deLijnEntityID)
                    }
                }
            } else {
                journeyStatus = "Ajoute ton adresse de départ dans Configuration."
                return false
            }

            var options: [BelgianUnifiedJourney] = []
            let arrivalTargets = [arrivalTargetDate, fallbackArrivalTargetDate].compactMap { $0 }
            for target in arrivalTargets {
                options = try await BelgianTransitPlanner.plan(from: originCoordinate,
                    to: (place.coordinate.latitude, place.coordinate.longitude),
                    originName: homeAddress.isEmpty ? stopName : homeAddress,
                    destinationName: place.name, arrivingBy: target,
                    networkFilter: ["tec", "nmbs"].contains(transitNetwork) ? transitNetwork : nil,
                    allowedNetworks: allowedPlannerNetworks,
                    allowedModes: enabledTransitModes)
                if !options.isEmpty { break }
            }
            guard let best = options.first else {
                journeyStatus = "Aucun trajet trouvé pour cette arrivée. Essaie une autre heure."
                return false
            }

            let trip = best.journey
            deLijnStopID = best.origin.properties.STOPID
            deLijnEntityID = best.origin.properties.ENTITEITNUMMER
            stopName = best.origin.properties.NAAMHALTE
            homeWalkMinutes = best.originWalkMinutes
            destinationStopID = best.destination.properties.STOPID
            destinationEntityID = best.destination.properties.ENTITEITNUMMER
            finalWalkMinutes = best.destinationWalkMinutes
            finalWalkIsApproximate = false
            selectedDestination = best.destination
            mapCoordinate = CLLocationCoordinate2D(latitude: best.originLatitude, longitude: best.originLongitude)
            mapFinalStopCoordinate = CLLocationCoordinate2D(latitude: best.destinationLatitude, longitude: best.destinationLongitude)
            journeys = [trip]
            WidgetDataStore.configure(stopID: deLijnStopID, entityID: deLijnEntityID, stopName: stopName)
            WidgetCenter.shared.reloadAllTimelines()
            DeLijnJourneyCache.save(trip, originStopID: deLijnStopID, originStopName: stopName,
                homeWalkMinutes: homeWalkMinutes, destinationStopID: destinationStopID,
                destinationEntityID: destinationEntityID, destinationName: destinationName,
                targetArrival: arrivalTargetDate, homeLatitude: homeLatitude, homeLongitude: homeLongitude,
                destinationLatitude: place.coordinate.latitude, destinationLongitude: place.coordinate.longitude)
            syncDepartureTime(with: trip)
            lastRouteRefresh = .now
            journeyStatus = "Prêt · " + [trip.line, trip.secondLine, trip.thirdLine]
                .compactMap { $0 }.joined(separator: " → ")
            updateMapRegion()
            if prepareAlarm { useJourney(trip) }
            navigateToTab(0)
            Task { await refreshJourneyPredictions(for: trip) }
            return true
        } catch {
            journeyStatus = "Planification indisponible · je cherche un trajet du réseau choisi."
            return false
        }
    }

    @MainActor
    private func selectStibDestinationPlace(_ place: DestinationPlace, prepareAlarm: Bool) async {
        guard !enabledTransitModes.isEmpty else {
            journeyStatus = "Choisis au moins un moyen de transport dans Configuration."
            return
        }
        guard !enabledTransitModes.isDisjoint(with: ["BUS", "TRAM", "SUBWAY"]) else {
            journeyStatus = "Le réseau STIB propose bus, tram et métro. Active l’un de ces choix."
            return
        }
        guard !homeAddress.isEmpty || !deLijnStopID.isEmpty else {
            journeyStatus = "Ajoute ton domicile ou choisis ta position pour calculer le trajet STIB."
            return
        }
        let keepsCurrentRoute = journeys.first != nil
            && abs(destinationLatitude - place.coordinate.latitude) < 0.0005
            && abs(destinationLongitude - place.coordinate.longitude) < 0.0005
        selectedPlace = place
        destination = place.name
        destinationName = place.name
        destinationMunicipality = place.subtitle
        destinationLatitude = place.coordinate.latitude
        destinationLongitude = place.coordinate.longitude
        mapDestinationCoordinate = place.coordinate
        selectedDestination = nil
        if !keepsCurrentRoute { journeys = [] }
        liveDelayByLeg = [:]
        journeyStatus = "Recherche des arrêts et horaires STIB…"
        isSearchingJourneys = true
        defer { isSearchingJourneys = false }

        do {
            let destinationStops = try await StibClient.shared.nearbyStops(
                latitude: place.coordinate.latitude, longitude: place.coordinate.longitude, limit: 5, radiusMeters: 3000)
            guard !destinationStops.isEmpty else {
                journeyStatus = "Aucun arrêt STIB près de cette destination."
                return
            }

            var originStops: [NearbyDeLijnStop]
            if homeLatitude != 0, homeLongitude != 0 {
                originStops = try await StibClient.shared.nearbyStops(
                    latitude: homeLatitude, longitude: homeLongitude, limit: 5, radiusMeters: 3000)
            } else if let coordinate = try? await resolvedStopCoordinate(stopID: deLijnStopID, entityID: deLijnEntityID) {
                originStops = try await StibClient.shared.nearbyStops(
                    latitude: coordinate.latitude, longitude: coordinate.longitude, limit: 5, radiusMeters: 1200)
            } else { originStops = [] }
            guard !originStops.isEmpty else {
                journeyStatus = "Aucun arrêt STIB près de ton domicile. Vérifie l’adresse ou choisis un arrêt."
                return
            }

            // Ask the Belgian planner for a STIB-only itinerary first. This
            // supports up to three vehicle legs while excluding De Lijn rides;
            // the local STIB timetable remains the offline/provider fallback.
            let plannerOrigin: (latitude: Double, longitude: Double)
            if homeLatitude != 0, homeLongitude != 0 {
                plannerOrigin = (homeLatitude, homeLongitude)
            } else if let stop = originStops.first {
                plannerOrigin = (stop.latitude, stop.longitude)
            } else {
                journeyStatus = "Adresse de départ introuvable."
                return
            }
            let plannerTargets = [arrivalTargetDate, fallbackArrivalTargetDate].compactMap { $0 }
            var stibPlannerOptions: [BelgianUnifiedJourney] = []
            for target in plannerTargets {
                stibPlannerOptions = (try? await BelgianTransitPlanner.plan(
                    from: plannerOrigin,
                    to: (place.coordinate.latitude, place.coordinate.longitude),
                    originName: homeAddress.isEmpty ? stopName : homeAddress,
                    destinationName: place.name,
                    arrivingBy: target,
                    onlySTIB: true,
                    allowedModes: enabledTransitModes)) ?? []
                if !stibPlannerOptions.isEmpty { break }
            }
            if let best = stibPlannerOptions.first {
                let trip = best.journey
                deLijnStopID = best.origin.properties.STOPID
                deLijnEntityID = "stib"
                stopName = best.origin.properties.NAAMHALTE
                homeWalkMinutes = best.originWalkMinutes
                destinationStopID = best.destination.properties.STOPID
                destinationEntityID = "stib"
                selectedDestination = best.destination
                finalWalkMinutes = best.destinationWalkMinutes
                finalWalkIsApproximate = false
                mapCoordinate = CLLocationCoordinate2D(latitude: best.originLatitude,
                    longitude: best.originLongitude)
                mapFinalStopCoordinate = CLLocationCoordinate2D(latitude: best.destinationLatitude,
                    longitude: best.destinationLongitude)
                journeys = [trip]
                WidgetDataStore.configure(stopID: deLijnStopID, entityID: "stib", stopName: stopName)
                WidgetCenter.shared.reloadAllTimelines()
                DeLijnJourneyCache.save(trip, originStopID: deLijnStopID,
                    originStopName: stopName, homeWalkMinutes: homeWalkMinutes,
                    destinationStopID: destinationStopID, destinationEntityID: "stib",
                    destinationName: destinationName, targetArrival: arrivalTargetDate,
                    homeLatitude: homeLatitude, homeLongitude: homeLongitude,
                    destinationLatitude: place.coordinate.latitude,
                    destinationLongitude: place.coordinate.longitude)
                syncDepartureTime(with: trip)
                lastRouteRefresh = .now
                journeyStatus = "STIB · " + [trip.line, trip.secondLine, trip.thirdLine]
                    .compactMap { $0 }.joined(separator: " → ")
                updateMapRegion()
                if prepareAlarm { useJourney(trip) }
                await loadDepartures()
                await loadJourneyMapCoordinates()
                navigateToTab(0)
                Task { await refreshJourneyPredictions(for: trip) }
                return
            }

            let configuredID = "stib-\(deLijnStopID)"
            originStops.sort { left, right in
                if (left.stop.id == configuredID) != (right.stop.id == configuredID) { return left.stop.id == configuredID }
                return left.distanceMeters < right.distanceMeters
            }
            let homeCoordinate = CLLocationCoordinate2D(latitude: homeLatitude, longitude: homeLongitude)
            let originWalks = await withTaskGroup(of: (String, WalkEstimate).self) { group in
                for stop in originStops {
                    let coordinate = homeLatitude != 0 && homeLongitude != 0 ? homeCoordinate :
                        CLLocationCoordinate2D(latitude: stop.latitude, longitude: stop.longitude)
                    group.addTask { (stop.id, await WalkingRouteEstimator.estimate(from: stop, to: coordinate)) }
                }
                var values: [String: WalkEstimate] = [:]
                for await (id, value) in group { values[id] = value }
                return values
            }
            let destinationWalks = await withTaskGroup(of: (String, WalkEstimate).self) { group in
                for stop in destinationStops {
                    let coordinate = place.coordinate
                    group.addTask { (stop.id, await WalkingRouteEstimator.estimate(from: stop, to: coordinate)) }
                }
                var values: [String: WalkEstimate] = [:]
                for await (id, value) in group { values[id] = value }
                return values
            }
            let originChoices = originStops.map { stop in
                let estimate = originWalks[stop.id]?.minutes ?? stop.walkMinutes
                let minutes = stop.id == configuredID && homeWalkMinutes > 0 ? homeWalkMinutes : estimate
                return StibStopChoice(stop: stop, walkMinutes: minutes)
            }
            let destinationChoices = destinationStops.map { stop in
                StibStopChoice(stop: stop, walkMinutes: destinationWalks[stop.id]?.minutes ?? stop.walkMinutes)
            }

            journeyStatus = "Calcul des horaires STIB jusqu’à \(arrivalTargetDate.formatted(date: .omitted, time: .shortened))…"
            let plans = try await StibSchedulePlanner.shared.plan(from: originChoices, to: destinationChoices,
                arrivingBy: arrivalTargetDate, earliestDeparture: .now)
            guard let best = plans.first else {
                journeyStatus = "Aucun trajet STIB trouvé pour cette heure. Essaie une autre destination ou une autre heure d’arrivée."
                return
            }

            deLijnStopID = best.origin.stop.properties.STOPID
            deLijnEntityID = "stib"
            stopName = best.origin.stop.properties.NAAMHALTE
            homeWalkMinutes = best.originWalkMinutes
            destinationStopID = best.destination.stop.properties.STOPID
            destinationEntityID = "stib"
            selectedDestination = best.destination.stop
            finalWalkMinutes = best.destinationWalkMinutes
            finalWalkIsApproximate = destinationWalks[best.destination.id]?.distanceMeters == nil
            mapCoordinate = CLLocationCoordinate2D(latitude: best.origin.latitude, longitude: best.origin.longitude)
            mapFinalStopCoordinate = CLLocationCoordinate2D(latitude: best.destination.latitude, longitude: best.destination.longitude)
            journeys = [best.journey]
            syncDepartureTime(with: best.journey)
            WidgetDataStore.configure(stopID: deLijnStopID, entityID: "stib", stopName: stopName)
            WidgetCenter.shared.reloadAllTimelines()
            let transferText = best.journey.secondLine.map { " · correspondance \($0)" } ?? ""
            journeyStatus = "STIB · \(best.journey.line) vers \(best.journey.lineDirection)\(transferText) · départ \(best.journey.departure.formatted(date: .omitted, time: .shortened)) · arrivée avant \(arrivalTargetDate.formatted(date: .omitted, time: .shortened))."
            lastRouteRefresh = .now
            updateMapRegion()
            if prepareAlarm { useJourney(best.journey) }
            await loadDepartures()
            await loadJourneyMapCoordinates()
            navigateToTab(0)
            Task { await refreshJourneyPredictions(for: best.journey) }
        } catch {
            journeyStatus = "Horaires STIB indisponibles : \(error.localizedDescription)"
        }
    }

    @MainActor
    private func updateWalkingTime(from stop: NearbyDeLijnStop, to place: DestinationPlace) async {
        let estimate = await WalkingRouteEstimator.estimate(from: stop, to: place.coordinate)
        finalWalkMinutes = estimate.minutes
        finalWalkIsApproximate = estimate.distanceMeters == nil
        updateMapRegion()
        if let distance = estimate.distanceMeters {
            journeyStatus = "Marche jusqu’à \(place.name) : \(estimate.minutes) min · \(String(format: "%.0f", distance)) m"
        } else {
            journeyStatus = "Marche estimée jusqu’à \(place.name) : environ \(estimate.minutes) min"
        }
    }

    private var infoSheet: some View {
        NavigationView {
            List {
                    Label("De Lijn · STIB · TEC · SNCB", systemImage: "bus.fill")
                    Label("Données temps réel : Belgian Mobility Company", systemImage: "antenna.radiowaves.left.and.right")
                    Label("Widget : prochain départ", systemImage: "rectangle.on.rectangle")
                    Label("Réveil : alerte sonore planifiée", systemImage: "alarm.fill")
                    Text("Chaque widget peut afficher un arrêt différent. Cherche des arrêts dans Configuration, touche + pour les enregistrer, puis modifie chaque widget pour choisir son arrêt. iOS peut retarder l’actualisation; ouvre MobiGo pour rafraîchir.").foregroundStyle(Palette.muted)
                    Text("En mode Auto, les trajets peuvent combiner De Lijn, STIB, TEC et SNCB, avec marche et correspondances. Les prochains départs en direct sont disponibles pour les quatre réseaux; le widget est actualisé selon les limites d’iOS.").foregroundStyle(Palette.muted)
            }
            .background(Palette.background).foregroundStyle(Palette.text)
            .navigationTitle("Infos réseau")
            .navigationBarItems(trailing: Button("Accueil") { navigateToTab(0) })
        }
    }

    private var mapSheet: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: "map.fill").font(.title2).foregroundStyle(Palette.purple)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Carte").font(.system(size: 25, weight: .bold, design: .rounded))
                    Text("Trajet, arrêts et départs").font(.caption).foregroundStyle(Palette.muted)
                }
                Spacer()
                Button { navigateToTab(0) } label: {
                    Image(systemName: "chevron.left").font(.system(size: 14, weight: .bold))
                        .padding(10).background(Palette.card, in: Circle())
                }.accessibilityLabel("Retour au trajet")
            }.padding(.horizontal, 19).padding(.vertical, 14)
            if !journeyMapAnnotations.isEmpty {
                journeyMapView
                    .frame(height: 420)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .padding(.horizontal, 16).padding(.bottom, 12)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(Array(transitMapRoutes.enumerated()), id: \.offset) { item in
                            let route = item.element
                            Label(route.2, systemImage: vehicleIcon(route.3))
                                .foregroundStyle(Color(route.1))
                                .transition(reduceMotion ? .opacity : .move(edge: .trailing).combined(with: .opacity))
                        }
                        if walkToDeparturePolyline != nil {
                            Label("Maison → arrêt", systemImage: "figure.walk")
                                .foregroundStyle(Palette.blue)
                                .accessibilityLabel("Maison vers arrêt")
                        }
                        if walkToDestinationPolyline != nil {
                            Label("Arrêt → destination", systemImage: "figure.walk")
                                .foregroundStyle(Palette.pink)
                        }
                    }
                    .font(.system(size: 10, weight: .semibold))
                    .lineLimit(1).fixedSize(horizontal: true, vertical: false)
                    .padding(.horizontal, 19).padding(.bottom, 10)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: transitMapRoutes.count)
                VStack(alignment: .leading, spacing: 10) {
                    Label(stopName.isEmpty ? "Arrêt sélectionné" : stopName,
                          systemImage: journeys.first.map { vehicleIcon($0.firstLegMode) } ?? "mappin.and.ellipse")
                        .font(.headline)
                    if !transitMapRoutes.isEmpty {
                        Text("Tracé indicatif reliant les arrêts de chaque ligne.")
                            .font(.system(size: 10)).foregroundStyle(Palette.muted)
                    }
                    if destinationLatitude != 0, destinationLongitude != 0 {
                        Label("\(destinationName) · marche estimée \(finalWalkMinutes) min", systemImage: "figure.walk")
                            .font(.caption).foregroundStyle(Palette.muted)
                    }
                    ForEach(departures.prefix(4)) { item in
                        HStack { Text(item.lineNumber).font(.caption.bold()).padding(6).background(Palette.blue, in: RoundedRectangle(cornerRadius: 6)); Text("vers \(item.destination)").font(.caption); Spacer(); Text(item.realtimeTime, format: .dateTime.hour().minute()).font(.caption.bold()) }
                    }
                }.padding(15).background(Palette.card, in: RoundedRectangle(cornerRadius: 18)).padding(.horizontal, 16)
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "map").font(.system(size: 44)).foregroundStyle(Palette.purple)
                    Text("Choisis un arrêt").font(.headline)
                    Text("La carte affiche ton arrêt et la destination choisie.").font(.caption).foregroundStyle(Palette.muted).multilineTextAlignment(.center)
                }.padding(24)
                Button("Choisir un arrêt") { navigateToTab(4) }.buttonStyle(.borderedProminent).tint(Palette.purple)
            }
            Spacer(minLength: 0)
        }
        .background(Palette.background)
        .task(id: "\(deLijnStopID)-\(destinationStopID)-\(destinationLatitude)-\(destinationLongitude)") { await loadJourneyMapCoordinates() }
    }

    private var routesPage: some View { routesSheet }
    private var profilePage: some View { profileSheet }
    private var infoPage: some View { infoSheet }
    private var mapPage: some View { mapSheet }

    @ViewBuilder private var journeyMapView: some View {
        JourneyMapView(region: mapRegion, annotations: journeyMapAnnotations,
            walkingRoutes: [(walkToDeparturePolyline, UIColor.systemBlue), (walkToDestinationPolyline, UIColor.systemPink)].compactMap { (polyline, color) in
                polyline.map { ($0, color) }
            }, transitRoutes: transitMapRoutes.map { ($0.0, $0.1) },
            showsUserLocation: locationProvider.isTripTracking, reduceMotion: reduceMotion,
            isDarkTheme: appTheme == "dark")
    }

    private var journeyMapAnnotations: [BusStopAnnotation] {
        var markers: [BusStopAnnotation] = []
        if homeLatitude != 0, homeLongitude != 0 {
            markers.append(BusStopAnnotation(
                coordinate: CLLocationCoordinate2D(latitude: homeLatitude, longitude: homeLongitude),
                name: displayHomeAddress.isEmpty ? "Maison" : "Maison · \(displayHomeAddress)",
                isDestination: false, isHome: true))
        }
        if let mapCoordinate {
            markers.append(BusStopAnnotation(coordinate: mapCoordinate,
                name: stopName.isEmpty ? "Mon arrêt" : stopName, isDestination: false,
                vehicleMode: journeys.first?.firstLegMode))
        }
        if let mapFinalStopCoordinate {
            let finalMode = journeys.first.flatMap { $0.thirdLegMode ?? $0.secondLegMode ?? $0.firstLegMode }
            markers.append(BusStopAnnotation(coordinate: mapFinalStopCoordinate,
                name: "Arrêt de descente", isDestination: false, vehicleMode: finalMode))
        }
        if let trip = journeys.first {
            let transferStops: [(String?, String?, String?)] = [
                (trip.transferStopID, trip.transferStop, trip.firstLegEntityID ?? deLijnEntityID),
                (trip.secondTransferStopID, trip.secondTransferStop, trip.secondLegEntityID ?? deLijnEntityID)
            ]
            for (index, transfer) in transferStops.enumerated() {
                guard let id = transfer.0,
                      let coordinate = transferCoordinates[transferCoordinateKey(stopID: id, entityID: transfer.2 ?? deLijnEntityID)] else { continue }
                let name = index == 0 ? journeys.first?.transferStop : journeys.first?.secondTransferStop
                let place = name?.components(separatedBy: "→").last?.trimmingCharacters(in: .whitespacesAndNewlines)
                let markerName = place.flatMap { $0.isEmpty ? nil : $0 } ?? "Correspondance"
                let mode = index == 0 ? trip.firstLegMode : trip.secondLegMode
                markers.append(BusStopAnnotation(coordinate: coordinate, name: "↔ \(markerName)",
                    isDestination: false, isTransfer: true, vehicleMode: mode))
            }
        }
        if let mapDestinationCoordinate {
            markers.append(BusStopAnnotation(coordinate: mapDestinationCoordinate, name: destinationName, isDestination: true))
        }
        return markers
    }

    private func pageTitle(_ title: String, subtitle: String, icon: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.title2).foregroundStyle(Palette.purple)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 25, weight: .bold, design: .rounded))
                Text(subtitle).font(.caption).foregroundStyle(Palette.muted)
            }
            Spacer()
        }.padding(.horizontal, 19).padding(.vertical, 14)
    }

    private func resolvedStopCoordinate(stopID: String, entityID: String) async throws -> (latitude: Double, longitude: Double) {
        if let routeStop = journeys.first?.firstLegCoordinates?.first(where: {
            $0.entityID.caseInsensitiveCompare(entityID) == .orderedSame && $0.stopID == stopID
        }) ?? journeys.first?.secondLegCoordinates?.first(where: {
            $0.entityID.caseInsensitiveCompare(entityID) == .orderedSame && $0.stopID == stopID
        }) ?? journeys.first?.thirdLegCoordinates?.first(where: {
            $0.entityID.caseInsensitiveCompare(entityID) == .orderedSame && $0.stopID == stopID
        }) {
            return (routeStop.latitude, routeStop.longitude)
        }
        if entityID.lowercased() == "stib" {
            guard let coordinate = try await StibSchedulePlanner.shared.coordinate(for: stopID) else {
                throw DeLijnError.invalidResponse
            }
            return coordinate
        }
        if let coordinate = BelgianStopCatalog.coordinate(stopID: stopID, entityID: entityID) {
            return coordinate
        }
        return try await DeLijnClient.shared.stopCoordinate(stopID: stopID, entityID: entityID)
    }

    @MainActor private func geocodeSelectedStop() async {
        guard !stopName.isEmpty else { mapCoordinate = nil; return }
        do {
            let coordinate = try await resolvedStopCoordinate(stopID: deLijnStopID, entityID: deLijnEntityID)
            let center = CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude)
            mapCoordinate = center
            updateMapRegion()
        } catch { mapCoordinate = nil }
    }

    @MainActor private func loadJourneyMapCoordinates() async {
        await geocodeSelectedStop()
        if destinationLatitude != 0, destinationLongitude != 0 {
            mapDestinationCoordinate = CLLocationCoordinate2D(latitude: destinationLatitude, longitude: destinationLongitude)
            if !destinationStopID.isEmpty, let coordinate = try? await resolvedStopCoordinate(stopID: destinationStopID, entityID: destinationEntityID) {
                mapFinalStopCoordinate = CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude)
            }
            updateMapRegion()
        } else if !destinationStopID.isEmpty, let stop = selectedDestination {
            await loadMapDestinationStopCoordinate(stop)
        }
        await loadWalkingMapRoutes()
        await loadTransitMapRoutes()
    }

    @MainActor private func loadTransitMapRoutes() async {
        transitMapRoutes = []
        guard let trip = journeys.first else { return }
        let routeStops = (trip.firstLegCoordinates ?? [])
            + (trip.secondLegCoordinates ?? []) + (trip.thirdLegCoordinates ?? [])
        for stop in routeStops {
            transferCoordinates[transferCoordinateKey(stopID: stop.stopID, entityID: stop.entityID)] =
                CLLocationCoordinate2D(latitude: stop.latitude, longitude: stop.longitude)
        }
        var legs: [([String], String, String, String)] = []
        if trip.firstLegStopIDs.count > 1 {
            legs.append((trip.firstLegStopIDs, trip.line + " → " + trip.lineDirection,
                         trip.firstLegEntityID ?? deLijnEntityID, trip.firstLegMode ?? "BUS"))
        }
        if let line = trip.secondLine, trip.secondLegStopIDs.count > 1 {
            legs.append((trip.secondLegStopIDs, line + " → " + (trip.secondLineDirection ?? ""),
                         trip.secondLegEntityID ?? deLijnEntityID, trip.secondLegMode ?? "BUS"))
        }
        if let line = trip.thirdLine, trip.thirdLegStopIDs.count > 1 {
            legs.append((trip.thirdLegStopIDs, line + " → " + (trip.thirdLineDirection ?? ""),
                         trip.thirdLegEntityID ?? deLijnEntityID, trip.thirdLegMode ?? "BUS"))
        }
        let stops = Array(Set(legs.flatMap { leg in leg.0.map { "\(leg.2)|\($0)" } })).prefix(45)
        await withTaskGroup(of: (String, CLLocationCoordinate2D?).self) { group in
            for key in stops where transferCoordinates[key] == nil {
                let parts = key.split(separator: "|", maxSplits: 1).map(String.init)
                guard parts.count == 2 else { continue }
                let entityID = parts[0]
                let id = parts[1]
                group.addTask {
                    let value: (latitude: Double, longitude: Double)?
                    if entityID.lowercased() == "stib" {
                        value = try? await StibSchedulePlanner.shared.coordinate(for: id)
                    } else {
                        value = try? await DeLijnClient.shared.stopCoordinate(stopID: id, entityID: entityID)
                    }
                    return (key, value.map { CLLocationCoordinate2D(latitude: $0.latitude, longitude: $0.longitude) })
                }
            }
            for await (key, coordinate) in group {
                if let coordinate { transferCoordinates[key] = coordinate }
            }
        }
        let palette = [UIColor.systemPurple, .systemOrange, .systemTeal]
        transitMapRoutes = legs.enumerated().compactMap { item in
            let index = item.offset
            let leg = item.element
            let coordinates = leg.0.compactMap { transferCoordinates["\(leg.2)|\($0)"] }
            guard coordinates.count > 1 else { return nil }
            return (MKPolyline(coordinates: coordinates, count: coordinates.count),
                    palette[index % palette.count], leg.1, leg.3)
        }
        updateMapRegion()
    }

    @MainActor private func loadWalkingMapRoutes() async {
        walkToDeparturePolyline = nil
        walkToDestinationPolyline = nil

        if homeLatitude != 0, homeLongitude != 0, let mapCoordinate {
            walkToDeparturePolyline = await walkingPolyline(
                from: CLLocationCoordinate2D(latitude: homeLatitude, longitude: homeLongitude), to: mapCoordinate)
        }
        if let mapFinalStopCoordinate, let mapDestinationCoordinate {
            walkToDestinationPolyline = await walkingPolyline(from: mapFinalStopCoordinate, to: mapDestinationCoordinate)
        }
    }

    private func walkingPolyline(from start: CLLocationCoordinate2D,
                                 to end: CLLocationCoordinate2D) async -> MKPolyline? {
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: start))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: end))
        request.transportType = .walking
        guard let response = try? await MKDirections(request: request).calculate() else { return nil }
        return response.routes.min(by: { $0.expectedTravelTime < $1.expectedTravelTime })?.polyline
    }

    @MainActor private func loadMapDestinationStopCoordinate(_ stop: StopFeature) async {
        guard let coordinate = try? await resolvedStopCoordinate(
            stopID: stop.properties.STOPID, entityID: stop.properties.ENTITEITNUMMER) else { return }
        mapDestinationCoordinate = CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude)
        updateMapRegion()
    }

    @MainActor private func updateMapRegion() {
        var points: [CLLocationCoordinate2D] = []
        if homeLatitude != 0, homeLongitude != 0 {
            points.append(CLLocationCoordinate2D(latitude: homeLatitude, longitude: homeLongitude))
        }
        if let mapCoordinate { points.append(mapCoordinate) }
        if let mapFinalStopCoordinate { points.append(mapFinalStopCoordinate) }
        if let mapDestinationCoordinate { points.append(mapDestinationCoordinate) }
        for route in transitMapRoutes {
            for index in 0..<route.0.pointCount {
                let point = route.0.points()[index].coordinate
                points.append(point)
            }
        }
        guard let first = points.first else { return }
        let minLatitude = points.map(\.latitude).min() ?? first.latitude
        let maxLatitude = points.map(\.latitude).max() ?? first.latitude
        let minLongitude = points.map(\.longitude).min() ?? first.longitude
        let maxLongitude = points.map(\.longitude).max() ?? first.longitude
        mapRegion = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: (minLatitude + maxLatitude) / 2, longitude: (minLongitude + maxLongitude) / 2),
            span: MKCoordinateSpan(latitudeDelta: max(0.012, (maxLatitude - minLatitude) * 1.5), longitudeDelta: max(0.012, (maxLongitude - minLongitude) * 1.5)))
    }
}

private struct TransitFareNetwork: Identifiable {
    let id: String
    let name: String
    let symbol: String
    let fare: Double
    let priceLabel: String
    let note: String
    let sourceURL: URL

    var singleFare: TransitFareItem {
        TransitFareItem(id: id, networkName: name, amount: fare,
                        priceLabel: priceLabel, note: note, sourceURL: sourceURL)
    }

    static let all: [TransitFareNetwork] = [
        .init(id: "delijn", name: "De Lijn", symbol: "bus.fill", fare: 3.00,
              priceLabel: "3,00 €", note: "Ticket valable 60 min.",
              sourceURL: URL(string: "https://www.delijn.be/fr/content/vervoerbewijzen/tarieven/")!),
        .init(id: "stib", name: "STIB", symbol: "tram.fill", fare: 2.40,
              priceLabel: "2,40 €", note: "Sans contact · maximum 8,50 € par jour.",
              sourceURL: URL(string: "https://www.stib-mivb.be/buy/your-bank-card-is-your-ticket")!),
        .init(id: "tec", name: "TEC", symbol: "bus.fill", fare: 2.80,
              priceLabel: "Dès 2,80 €", note: "Classic; Express : 5,50 €.",
              sourceURL: URL(string: "https://presse.groupe.letec.be/letec-annonce-sa-nouvelle-grille-tarifaire-a-partir-du-1er-fevrier-2026")!),
        .init(id: "nmbs", name: "SNCB", symbol: "train.side.front.car", fare: 2.60,
              priceLabel: "Dès 2,60 €", note: "Le prix du train dépend de la distance.",
              sourceURL: URL(string: "https://www.belgiantrain.be/fr/tickets-and-railcards")!)
    ]

    static func networkID(for entityID: String) -> String? {
        let value = entityID.lowercased()
        if value == "2" || value.contains("delijn") || value.contains("de lijn") { return "delijn" }
        if value.contains("stib") || value.contains("mivb") { return "stib" }
        if value.contains("tec") || value.contains("letec") { return "tec" }
        if value.contains("nmbs") || value.contains("sncb") { return "nmbs" }
        return nil
    }
}

private struct TransitFareItem: Identifiable {
    let id: String
    let networkName: String
    let amount: Double
    let priceLabel: String
    let note: String
    let sourceURL: URL
}

private struct JourneyFareEstimate {
    let items: [TransitFareItem]
    var minimum: Double { items.reduce(0) { $0 + $1.amount } }
    var formattedMinimum: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale(identifier: "fr_BE")
        return formatter.string(from: NSNumber(value: minimum)) ?? String(format: "%.2f €", minimum)
    }
    var note: String {
        var parts = ["Estimation adulte, billet simple par réseau."]
        parts.append(contentsOf: items.map(\.note))
        if items.contains(where: { $0.id == "stib" }) && items.count > 1 {
            parts.append("Un Brupass peut coûter moins cher dans sa zone.")
        }
        if items.contains(where: { $0.id == "nmbs" }) {
            parts.append("Vérifie le prix SNCB exact avant de partir.")
        }
        return parts.joined(separator: " ")
    }
}

private struct SavedDestination: Codable, Identifiable {
    let id: String
    let name: String
    let subtitle: String
    let latitude: Double
    let longitude: Double

    static func id(for place: DestinationPlace) -> String {
        "\(place.coordinate.latitude.rounded(toPlaces: 5))_\(place.coordinate.longitude.rounded(toPlaces: 5))"
    }

    var destinationPlace: DestinationPlace {
        DestinationPlace(name: name, subtitle: subtitle,
            coordinate: CLLocationCoordinate2D(latitude: latitude, longitude: longitude))
    }
}

private extension Double {
    func rounded(toPlaces places: Int) -> Double {
        let factor = pow(10.0, Double(places))
        return (self * factor).rounded() / factor
    }
}

private struct DestinationPlace: Identifiable {
    let name: String
    let subtitle: String
    let coordinate: CLLocationCoordinate2D
    var id: String { "\(name)-\(coordinate.latitude)-\(coordinate.longitude)" }
}

private struct BusStopAnnotation: Identifiable {
    let coordinate: CLLocationCoordinate2D
    let name: String
    let isDestination: Bool
    var isHome = false
    var isTransfer = false
    var vehicleMode: String? = nil
    var id: String { "\(name)-\(coordinate.latitude)-\(coordinate.longitude)" }
    var styleKey: String { "\(isDestination)|\(isHome)|\(isTransfer)|\(vehicleMode ?? "")|\(name)" }
    var glyphName: String {
        if isDestination { return "figure.walk" }
        if isHome { return "house.fill" }
        if isTransfer { return "arrow.triangle.swap" }
        switch (vehicleMode ?? "").uppercased() {
        case "TRAM": return "tram.fill"
        case "SUBWAY", "METRO": return "tram.tunnel.fill"
        case "RAIL", "TRAIN": return "train.side.front.car"
        case "BUS": return "bus.fill"
        default: return "mappin.and.ellipse"
        }
    }
}

private struct JourneyMapView: UIViewRepresentable {
    let region: MKCoordinateRegion
    let annotations: [BusStopAnnotation]
    let walkingRoutes: [(MKPolyline, UIColor)]
    let transitRoutes: [(MKPolyline, UIColor)]
    let showsUserLocation: Bool
    let reduceMotion: Bool
    let isDarkTheme: Bool

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView(frame: .zero)
        map.delegate = context.coordinator
        context.coordinator.reduceMotion = reduceMotion
        context.coordinator.isDarkTheme = isDarkTheme
        map.overrideUserInterfaceStyle = isDarkTheme ? .dark : .light
        let style = MKStandardMapConfiguration(elevationStyle: .flat,
            emphasisStyle: isDarkTheme ? .muted : .default)
        style.pointOfInterestFilter = .excludingAll
        style.showsTraffic = false
        map.preferredConfiguration = style
        map.pointOfInterestFilter = .excludingAll
        map.showsCompass = true
        map.showsScale = false
        return map
    }

    func updateUIView(_ map: MKMapView, context: Context) {
        if context.coordinator.isDarkTheme != isDarkTheme {
            context.coordinator.isDarkTheme = isDarkTheme
            map.overrideUserInterfaceStyle = isDarkTheme ? .dark : .light
            let style = MKStandardMapConfiguration(elevationStyle: .flat,
                emphasisStyle: isDarkTheme ? .muted : .default)
            style.pointOfInterestFilter = .excludingAll
            style.showsTraffic = false
            map.preferredConfiguration = style
        }
        map.showsTraffic = false
        map.showsUserLocation = showsUserLocation
        context.coordinator.reduceMotion = reduceMotion
        var desiredByID: [String: BusStopAnnotation] = [:]
        for annotation in annotations where desiredByID[annotation.id] == nil {
            desiredByID[annotation.id] = annotation
        }
        let currentPins = map.annotations.compactMap { $0 as? MapStopPin }
        var seenCurrentIDs = Set<String>()
        let removedPins = currentPins.filter { pin in
            guard seenCurrentIDs.insert(pin.identifier).inserted else { return true }
            guard let desired = desiredByID[pin.identifier] else { return true }
            return pin.styleKey != desired.styleKey
        }
        let removedIDs = Set(removedPins.map(\.identifier))
        if !removedPins.isEmpty {
            map.removeAnnotations(removedPins)
        }
        let retainedIDs = Set(currentPins.map(\.identifier)).subtracting(removedIDs)
        var accountedForIDs = retainedIDs
        let newPins = annotations.filter { accountedForIDs.insert($0.id).inserted }.map(MapStopPin.init)
        if !newPins.isEmpty {
            map.addAnnotations(newPins)
        }
        let regionSignature = [region.center.latitude, region.center.longitude,
                               region.span.latitudeDelta, region.span.longitudeDelta]
            .map { String(format: "%.7f", $0) }.joined(separator: ":")
        if context.coordinator.regionSignature != regionSignature {
            context.coordinator.regionSignature = regionSignature
            map.setRegion(region, animated: !reduceMotion)
        }
        let allRoutes = walkingRoutes.map { ($0.0, $0.1, CGFloat(7)) } + transitRoutes.map { ($0.0, $0.1, CGFloat(6)) }
        var desiredRoutes: [String: (polyline: MKPolyline, color: UIColor, width: CGFloat)] = [:]
        for (polyline, color, width) in allRoutes {
            let key = context.coordinator.routeKey(for: polyline, color: color, width: width)
            desiredRoutes[key] = (polyline, color, width)
        }

        // Keep unchanged overlays on the map. Removing every line when just one
        // leg changes makes the route flash and forces MapKit to rebuild all renderers.
        for key in Array(context.coordinator.routeOverlays.keys) where desiredRoutes[key] == nil {
            guard let pair = context.coordinator.routeOverlays.removeValue(forKey: key) else { continue }
            map.removeOverlays([pair.outline, pair.route])
            context.coordinator.routeColors.removeValue(forKey: ObjectIdentifier(pair.outline))
            context.coordinator.routeColors.removeValue(forKey: ObjectIdentifier(pair.route))
        }

        for (key, desired) in desiredRoutes where context.coordinator.routeOverlays[key] == nil {
            let outline = MKPolyline(points: desired.polyline.points(), count: desired.polyline.pointCount)
            context.coordinator.routeColors[ObjectIdentifier(outline)] = (.white, desired.width + 6)
            context.coordinator.routeColors[ObjectIdentifier(desired.polyline)] = (desired.color, desired.width)
            context.coordinator.routeOverlays[key] = (outline, desired.polyline)
            map.addOverlay(outline, level: .aboveRoads)
            map.addOverlay(desired.polyline, level: .aboveRoads)
        }
    }

    final class Coordinator: NSObject, MKMapViewDelegate {
        var reduceMotion = false
        var isDarkTheme = false
        var regionSignature = ""
        var routeColors: [ObjectIdentifier: (color: UIColor, width: CGFloat)] = [:]
        var routeOverlays: [String: (outline: MKPolyline, route: MKPolyline)] = [:]

        func routeKey(for polyline: MKPolyline, color: UIColor, width: CGFloat) -> String {
            var hasher = Hasher()
            hasher.combine(polyline.pointCount)
            for index in 0..<polyline.pointCount {
                let point = polyline.points()[index]
                hasher.combine(point.x.bitPattern)
                hasher.combine(point.y.bitPattern)
            }
            var red: CGFloat = 0
            var green: CGFloat = 0
            var blue: CGFloat = 0
            var alpha: CGFloat = 0
            color.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
            hasher.combine(Int((red * 255).rounded()))
            hasher.combine(Int((green * 255).rounded()))
            hasher.combine(Int((blue * 255).rounded()))
            hasher.combine(Int((alpha * 255).rounded()))
            hasher.combine(Double(width).bitPattern)
            return "\(polyline.pointCount):\(hasher.finalize())"
        }

        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            guard let polyline = overlay as? MKPolyline else { return MKOverlayRenderer(overlay: overlay) }
            let renderer = MKPolylineRenderer(polyline: polyline)
            let style = routeColors[ObjectIdentifier(polyline)] ?? (.systemBlue, 7)
            renderer.strokeColor = style.color
            renderer.lineWidth = style.width
            renderer.lineCap = .round
            renderer.lineJoin = .round
            return renderer
        }

        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            guard let pin = annotation as? MapStopPin else { return nil }
            let view = (mapView.dequeueReusableAnnotationView(withIdentifier: "stop") as? MKMarkerAnnotationView)
                ?? MKMarkerAnnotationView(annotation: pin, reuseIdentifier: "stop")
            view.annotation = pin
            view.markerTintColor = pin.markerTintColor
            view.glyphImage = UIImage(systemName: pin.glyphName)
            view.glyphTintColor = .white
            view.canShowCallout = true
            view.titleVisibility = .adaptive
            if !reduceMotion {
                view.alpha = 0
                view.transform = CGAffineTransform(scaleX: 0.78, y: 0.78)
                UIView.animate(withDuration: 0.22, delay: 0,
                    usingSpringWithDamping: 0.82, initialSpringVelocity: 0.15,
                    options: [.beginFromCurrentState, .allowUserInteraction]) {
                    view.alpha = 1
                    view.transform = .identity
                }
            }
            return view
        }
    }
}

private final class MapStopPin: NSObject, MKAnnotation {
    let identifier: String
    let coordinate: CLLocationCoordinate2D
    let title: String?
    let isDestination: Bool
    let isHome: Bool
    let isTransfer: Bool
    let vehicleMode: String?
    let glyphName: String
    var styleKey: String { "\(isDestination)|\(isHome)|\(isTransfer)|\(vehicleMode ?? "")|\(title ?? "")" }
    var markerTintColor: UIColor {
        if isDestination { return .systemPink }
        if isHome { return .systemGreen }
        if isTransfer { return .systemOrange }
        switch (vehicleMode ?? "").uppercased() {
        case "TRAM": return .systemTeal
        case "SUBWAY", "METRO": return .systemBlue
        case "RAIL", "TRAIN": return .systemIndigo
        default: return .systemPurple
        }
    }

    init(_ pin: BusStopAnnotation) {
        identifier = pin.id
        coordinate = pin.coordinate
        title = pin.name
        isDestination = pin.isDestination
        isHome = pin.isHome
        isTransfer = pin.isTransfer
        vehicleMode = pin.vehicleMode
        glyphName = pin.glyphName
    }
}

@available(iOS 17.0, *)
private struct ModernJourneyMapView: View {
    let region: MKCoordinateRegion
    let annotations: [BusStopAnnotation]
    let walkToDeparture: MKPolyline?
    let walkToDestination: MKPolyline?
    let showsUserLocation: Bool
    @State private var cameraPosition: MapCameraPosition

    init(region: MKCoordinateRegion, annotations: [BusStopAnnotation],
         walkToDeparture: MKPolyline?, walkToDestination: MKPolyline?, showsUserLocation: Bool) {
        self.region = region
        self.annotations = annotations
        self.walkToDeparture = walkToDeparture
        self.walkToDestination = walkToDestination
        self.showsUserLocation = showsUserLocation
        _cameraPosition = State(initialValue: .region(region))
    }

    private var regionKey: String {
        [region.center.latitude, region.center.longitude,
         region.span.latitudeDelta, region.span.longitudeDelta]
            .map { String(format: "%.7f", $0) }.joined(separator: ":")
    }

    var body: some View {
        Map(position: $cameraPosition, interactionModes: .all) {
            if let walkToDeparture {
                MapPolyline(walkToDeparture).stroke(.white, style: StrokeStyle(lineWidth: 13, lineCap: .round, lineJoin: .round))
                MapPolyline(walkToDeparture).stroke(.cyan, style: StrokeStyle(lineWidth: 7, lineCap: .round, lineJoin: .round))
            }
            if let walkToDestination {
                MapPolyline(walkToDestination).stroke(.white, style: StrokeStyle(lineWidth: 13, lineCap: .round, lineJoin: .round))
                MapPolyline(walkToDestination).stroke(.pink, style: StrokeStyle(lineWidth: 7, lineCap: .round, lineJoin: .round))
            }
            if showsUserLocation { UserAnnotation() }
            ForEach(annotations) { marker in
                Annotation(marker.name, coordinate: marker.coordinate) {
                    Image(systemName: marker.glyphName)
                        .font(.system(size: 15, weight: .bold)).foregroundStyle(.white)
                        .padding(11)
                        .background(marker.isDestination ? Color.pink : marker.isHome ? Color.green : Palette.purple, in: Circle())
                        .overlay(Circle().stroke(.white, lineWidth: 2))
                }
            }
        }
        .mapStyle(.hybrid(elevation: .flat, pointsOfInterest: .excludingAll, showsTraffic: false))
        .onChange(of: regionKey) { _, _ in cameraPosition = .region(region) }
    }
}

#Preview {
    HomeView()
}
