import Foundation
import SQLite3
import ZIPFoundation

struct StibStopChoice: Sendable {
    let stop: NearbyDeLijnStop
    let walkMinutes: Int
}

struct StibJourneyCandidate: Identifiable, Sendable {
    let id: String
    let journey: DeLijnJourney
    let origin: NearbyDeLijnStop
    let destination: NearbyDeLijnStop
    let originWalkMinutes: Int
    let destinationWalkMinutes: Int
}

struct StibDepartureMetadata: Sendable {
    let scheduledTime: Date?
    let mode: String?
}

enum StibScheduleError: LocalizedError {
    case noFeed, invalidFeed, database(String)

    var errorDescription: String? {
        switch self {
        case .noFeed: return "Les horaires STIB ne sont pas disponibles pour le moment."
        case .invalidFeed: return "Le fichier d’horaires STIB reçu est incomplet. Réessaie dans un instant."
        case .database(let message): return "Impossible de préparer les horaires STIB : \(message)"
        }
    }
}

/// Downloads BMC's daily GTFS feed, indexes it locally, then finds direct and
/// one-transfer journeys by arrival time. All timetable calculations come from
/// GTFS; the separate STIB waiting-times API is used only for live departures.
actor StibSchedulePlanner {
    static let shared = StibSchedulePlanner()

    private let fileManager = FileManager.default
    private let updateKey = "busmind.stib.gtfs.updated-at"
    private let baseDirectory: URL = {
        let root = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: WidgetDataStore.suite)
            ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        return root.appendingPathComponent("BusMind/STIB", isDirectory: true)
    }()
    private var isReady = false

    private init() {}

    func plan(from origins: [StibStopChoice], to destinations: [StibStopChoice],
              arrivingBy target: Date, earliestDeparture: Date) async throws -> [StibJourneyCandidate] {
        guard !origins.isEmpty, !destinations.isEmpty else { return [] }
        try await ensureDatabase()
        let databaseURL = baseDirectory.appendingPathComponent("gtfs.sqlite")
        let database = try openDatabase(databaseURL, create: false)
        defer { sqlite3_close(database) }

        var candidates: [StibJourneyCandidate] = []
        let localCalendar = Self.brusselsCalendar
        let targetStart = localCalendar.startOfDay(for: target)
        let targetSecond = localCalendar.dateComponents([.hour, .minute, .second], from: target)
        let targetTimeOfDay = (targetSecond.hour ?? 0) * 3600 + (targetSecond.minute ?? 0) * 60 + (targetSecond.second ?? 0)
        let serviceDays = targetTimeOfDay < 4 * 3600
            ? [targetStart, localCalendar.date(byAdding: .day, value: -1, to: targetStart)!]
            : [targetStart]

        for serviceDay in serviceDays {
            let active = try activeServices(database, on: serviceDay)
            guard !active.isEmpty else { continue }
            try setActiveServices(database, active)
            let secondsToTarget = Int(target.timeIntervalSince(serviceDay))
            let earliestSecond = max(0, Int(earliestDeparture.timeIntervalSince(serviceDay)))

            for origin in origins {
                let firstAllowed = max(earliestSecond, Int(Date.now.timeIntervalSince(serviceDay)) + origin.walkMinutes * 60)
                for destination in destinations {
                    let lastAllowed = secondsToTarget - destination.walkMinutes * 60
                    guard firstAllowed < lastAllowed else { continue }
                    let direct = try directJourneys(database, originID: origin.stop.stop.properties.STOPID,
                        destinationID: destination.stop.stop.properties.STOPID,
                        earliest: firstAllowed, latestArrival: lastAllowed)
                    candidates.append(contentsOf: direct.map {
                        makeCandidate(database, raw: $0, origin: origin, destination: destination,
                            serviceDay: serviceDay, transfer: nil)
                    })

                    let transfers = try transferJourneys(database, originID: origin.stop.stop.properties.STOPID,
                        destinationID: destination.stop.stop.properties.STOPID,
                        earliest: firstAllowed, latestArrival: lastAllowed)
                    candidates.append(contentsOf: transfers.map { raw in
                        makeCandidate(database, raw: raw.first, origin: origin, destination: destination,
                            serviceDay: serviceDay, transfer: raw)
                    })
                }
            }
        }

        let unique = Dictionary(candidates.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
        return unique.values.sorted { left, right in
            let leftArrival = left.journey.arrival.addingTimeInterval(TimeInterval(left.destinationWalkMinutes * 60))
            let rightArrival = right.journey.arrival.addingTimeInterval(TimeInterval(right.destinationWalkMinutes * 60))
            if leftArrival != rightArrival { return leftArrival > rightArrival }
            return left.journey.durationMinutes < right.journey.durationMinutes
        }.prefix(8).map { $0 }
    }

    func coordinate(for stopID: String) async throws -> (latitude: Double, longitude: Double)? {
        try await ensureDatabase()
        let db = try openDatabase(baseDirectory.appendingPathComponent("gtfs.sqlite"), create: false)
        defer { sqlite3_close(db) }
        let statement = try prepare(db, "SELECT latitude, longitude FROM stops WHERE stop_id = ? LIMIT 1")
        defer { sqlite3_finalize(statement) }
        bind(stopID, at: 1, to: statement)
        guard sqlite3_step(statement) == SQLITE_ROW else { return nil }
        return (sqlite3_column_double(statement, 0), sqlite3_column_double(statement, 1))
    }

    /// Finds the scheduled STIB passage closest to a live waiting-time estimate.
    /// It only uses an already cached feed so a widget refresh never has to
    /// download and index GTFS in its limited execution window.
    func departureMetadata(stopID: String, lineNumber: String, near liveTime: Date) -> StibDepartureMetadata {
        let databaseURL = baseDirectory.appendingPathComponent("gtfs.sqlite")
        guard fileManager.fileExists(atPath: databaseURL.path),
              let database = try? openDatabase(databaseURL, create: false) else {
            return StibDepartureMetadata(scheduledTime: nil, mode: nil)
        }
        defer { sqlite3_close(database) }

        let calendar = Self.brusselsCalendar
        let today = calendar.startOfDay(for: liveTime)
        let hour = calendar.component(.hour, from: liveTime)
        let serviceDays = hour < 4
            ? [calendar.date(byAdding: .day, value: -1, to: today)!, today]
            : [today]
        var best: (date: Date, distance: TimeInterval, type: Int)?

        for serviceDay in serviceDays {
            guard let active = try? activeServices(database, on: serviceDay), !active.isEmpty else { continue }
            do { try setActiveServices(database, active) } catch { continue }
            guard let statement = try? prepare(database, """
                    SELECT a.departure_time, r.route_type
                    FROM stop_times a
                    JOIN trips t ON t.trip_id=a.trip_id
                    JOIN routes r ON r.route_id=t.route_id
                    JOIN active_services act ON act.service_id=t.service_id
                    WHERE a.stop_id=? AND r.route_short_name=?
                      AND a.departure_time BETWEEN ? AND ?
                    ORDER BY ABS(a.departure_time-?) LIMIT 1
                    """) else { continue }
            defer { sqlite3_finalize(statement) }

            let targetSeconds = Int(liveTime.timeIntervalSince(serviceDay))
            let lowerBound = max(0, targetSeconds - 45 * 60)
            let upperBound = targetSeconds + 45 * 60
            bind(stopID, at: 1, to: statement)
            bind(lineNumber, at: 2, to: statement)
            bindInt(lowerBound, at: 3, to: statement)
            bindInt(upperBound, at: 4, to: statement)
            bindInt(targetSeconds, at: 5, to: statement)
            guard sqlite3_step(statement) == SQLITE_ROW else { continue }
            let seconds = sqlite3_column_int(statement, 0)
            let scheduled = serviceDay.addingTimeInterval(TimeInterval(seconds))
            let distance = abs(scheduled.timeIntervalSince(liveTime))
            let type = Int(sqlite3_column_int(statement, 1))
            if best == nil || distance < best!.distance { best = (scheduled, distance, type) }
        }

        return StibDepartureMetadata(scheduledTime: best?.date, mode: best.map { modeName($0.type) })
    }

    private func ensureDatabase() async throws {
        let databaseURL = baseDirectory.appendingPathComponent("gtfs.sqlite")
        if isReady { return }
        try fileManager.createDirectory(at: baseDirectory, withIntermediateDirectories: true)
        let updated = UserDefaults.standard.object(forKey: updateKey) as? Date
        if fileManager.fileExists(atPath: databaseURL.path),
           let updated, Date.now.timeIntervalSince(updated) < 20 * 60 * 60 {
            isReady = true
            return
        }

        do {
            try await downloadAndIndex(to: databaseURL)
            UserDefaults.standard.set(Date.now, forKey: updateKey)
            isReady = true
        } catch {
            if fileManager.fileExists(atPath: databaseURL.path) {
                isReady = true
                return
            }
            throw error
        }
    }

    private func downloadAndIndex(to destination: URL) async throws {
        guard !LocalSecrets.bmcAPIKey.isEmpty,
              let feedURL = URL(string: "https://api-management-discovery-production.azure-api.net/api/gtfs/feed/stibmivb/static") else {
            throw StibScheduleError.noFeed
        }
        var request = URLRequest(url: feedURL)
        request.timeoutInterval = 90
        request.setValue(LocalSecrets.bmcAPIKey, forHTTPHeaderField: "bmc-partner-key")
        request.setValue("application/zip", forHTTPHeaderField: "Accept")
        let (archiveURL, response) = try await URLSession.shared.download(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw StibScheduleError.noFeed
        }

        let workDirectory = baseDirectory.appendingPathComponent("import-\(UUID().uuidString)", isDirectory: true)
        try fileManager.createDirectory(at: workDirectory, withIntermediateDirectories: true)
        defer { try? fileManager.removeItem(at: workDirectory) }
        let requiredFiles = ["stops.txt", "routes.txt", "trips.txt", "stop_times.txt", "calendar.txt", "calendar_dates.txt"]
        let archive = try Archive(url: archiveURL, accessMode: .read)
        for file in requiredFiles {
            guard let entry = archive[file] else { throw StibScheduleError.invalidFeed }
            _ = try archive.extract(entry, to: workDirectory.appendingPathComponent(file))
        }

        let temporaryDatabase = baseDirectory.appendingPathComponent("gtfs-\(UUID().uuidString).sqlite")
        do {
            try importFeed(from: workDirectory, into: temporaryDatabase)
            if fileManager.fileExists(atPath: destination.path) {
                _ = try fileManager.replaceItemAt(destination, withItemAt: temporaryDatabase)
            } else {
                try fileManager.moveItem(at: temporaryDatabase, to: destination)
            }
        } catch {
            try? fileManager.removeItem(at: temporaryDatabase)
            throw error
        }
    }

    private func importFeed(from directory: URL, into databaseURL: URL) throws {
        let db = try openDatabase(databaseURL, create: true)
        defer { sqlite3_close(db) }
        try execute(db, "PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF; PRAGMA temp_store=MEMORY; BEGIN;")
        try execute(db, """
            CREATE TABLE stops(stop_id TEXT PRIMARY KEY, parent_station TEXT, stop_name TEXT, latitude REAL, longitude REAL);
            CREATE TABLE routes(route_id TEXT PRIMARY KEY, route_short_name TEXT, route_long_name TEXT, route_type INTEGER);
            CREATE TABLE trips(trip_id TEXT PRIMARY KEY, route_id TEXT, service_id TEXT, headsign TEXT);
            CREATE TABLE stop_times(trip_id TEXT, stop_id TEXT, stop_sequence INTEGER, arrival_time INTEGER, departure_time INTEGER);
            CREATE TABLE calendar(service_id TEXT PRIMARY KEY, monday INTEGER, tuesday INTEGER, wednesday INTEGER, thursday INTEGER, friday INTEGER, saturday INTEGER, sunday INTEGER, start_date TEXT, end_date TEXT);
            CREATE TABLE calendar_dates(service_id TEXT, date TEXT, exception_type INTEGER);
            """)
        do {
            try importStops(directory.appendingPathComponent("stops.txt"), db)
            try importRoutes(directory.appendingPathComponent("routes.txt"), db)
            try importTrips(directory.appendingPathComponent("trips.txt"), db)
            try importCalendar(directory.appendingPathComponent("calendar.txt"), db)
            try importCalendarDates(directory.appendingPathComponent("calendar_dates.txt"), db)
            try importStopTimes(directory.appendingPathComponent("stop_times.txt"), db)
            try execute(db, """
                CREATE INDEX idx_stop_times_stop_trip ON stop_times(stop_id, trip_id, stop_sequence);
                CREATE INDEX idx_stop_times_trip_sequence ON stop_times(trip_id, stop_sequence);
                CREATE INDEX idx_stop_times_parent_time ON stop_times(stop_id, departure_time);
                CREATE INDEX idx_stops_parent ON stops(parent_station);
                COMMIT;
                """)
        } catch {
            try? execute(db, "ROLLBACK;")
            throw error
        }
    }

    private func importStops(_ url: URL, _ db: OpaquePointer) throws {
        let statement = try prepare(db, "INSERT OR REPLACE INTO stops VALUES(?,?,?,?,?)")
        defer { sqlite3_finalize(statement) }
        try readCSV(url) { header, row in
            bind(header["stop_id"].flatMap { row[safe: $0] } ?? "", at: 1, to: statement)
            bind(header["parent_station"].flatMap { row[safe: $0] } ?? "", at: 2, to: statement)
            bind(header["stop_name"].flatMap { row[safe: $0] } ?? "", at: 3, to: statement)
            bindDouble(Double(header["stop_lat"].flatMap { row[safe: $0] } ?? "") ?? 0, at: 4, to: statement)
            bindDouble(Double(header["stop_lon"].flatMap { row[safe: $0] } ?? "") ?? 0, at: 5, to: statement)
            try stepAndReset(statement)
        }
    }

    private func importRoutes(_ url: URL, _ db: OpaquePointer) throws {
        let statement = try prepare(db, "INSERT OR REPLACE INTO routes VALUES(?,?,?,?)")
        defer { sqlite3_finalize(statement) }
        try readCSV(url) { header, row in
            bind(header["route_id"].flatMap { row[safe: $0] } ?? "", at: 1, to: statement)
            bind(header["route_short_name"].flatMap { row[safe: $0] } ?? "", at: 2, to: statement)
            bind(header["route_long_name"].flatMap { row[safe: $0] } ?? "", at: 3, to: statement)
            bindInt(Int(header["route_type"].flatMap { row[safe: $0] } ?? "") ?? 0, at: 4, to: statement)
            try stepAndReset(statement)
        }
    }

    private func importTrips(_ url: URL, _ db: OpaquePointer) throws {
        let statement = try prepare(db, "INSERT OR REPLACE INTO trips VALUES(?,?,?,?)")
        defer { sqlite3_finalize(statement) }
        try readCSV(url) { header, row in
            bind(header["trip_id"].flatMap { row[safe: $0] } ?? "", at: 1, to: statement)
            bind(header["route_id"].flatMap { row[safe: $0] } ?? "", at: 2, to: statement)
            bind(header["service_id"].flatMap { row[safe: $0] } ?? "", at: 3, to: statement)
            bind(header["trip_headsign"].flatMap { row[safe: $0] } ?? "", at: 4, to: statement)
            try stepAndReset(statement)
        }
    }

    private func importCalendar(_ url: URL, _ db: OpaquePointer) throws {
        let statement = try prepare(db, "INSERT OR REPLACE INTO calendar VALUES(?,?,?,?,?,?,?,?,?,?)")
        defer { sqlite3_finalize(statement) }
        try readCSV(url) { header, row in
            let columns = ["service_id", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "start_date", "end_date"]
            for (index, column) in columns.enumerated() {
                bind(header[column].flatMap { row[safe: $0] } ?? "", at: Int32(index + 1), to: statement)
            }
            try stepAndReset(statement)
        }
    }

    private func importCalendarDates(_ url: URL, _ db: OpaquePointer) throws {
        let statement = try prepare(db, "INSERT INTO calendar_dates VALUES(?,?,?)")
        defer { sqlite3_finalize(statement) }
        try readCSV(url) { header, row in
            bind(header["service_id"].flatMap { row[safe: $0] } ?? "", at: 1, to: statement)
            bind(header["date"].flatMap { row[safe: $0] } ?? "", at: 2, to: statement)
            bindInt(Int(header["exception_type"].flatMap { row[safe: $0] } ?? "") ?? 0, at: 3, to: statement)
            try stepAndReset(statement)
        }
    }

    private func importStopTimes(_ url: URL, _ db: OpaquePointer) throws {
        let statement = try prepare(db, "INSERT INTO stop_times VALUES(?,?,?,?,?)")
        defer { sqlite3_finalize(statement) }
        try readCSV(url) { header, row in
            bind(header["trip_id"].flatMap { row[safe: $0] } ?? "", at: 1, to: statement)
            bind(header["stop_id"].flatMap { row[safe: $0] } ?? "", at: 2, to: statement)
            bindInt(Int(header["stop_sequence"].flatMap { row[safe: $0] } ?? "") ?? 0, at: 3, to: statement)
            bindInt(Self.seconds(header["arrival_time"].flatMap { row[safe: $0] } ?? ""), at: 4, to: statement)
            bindInt(Self.seconds(header["departure_time"].flatMap { row[safe: $0] } ?? ""), at: 5, to: statement)
            try stepAndReset(statement)
        }
    }

    private func readCSV(_ url: URL, rowHandler: ([String: Int], [String]) throws -> Void) throws {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var buffer = Data()
        var header: [String: Int]?
        while true {
            let chunk = try handle.read(upToCount: 64 * 1024) ?? Data()
            if chunk.isEmpty { break }
            buffer.append(chunk)
            while let newline = buffer.firstIndex(of: 10) {
                let lineData = buffer.prefix(upTo: newline)
                buffer.removeSubrange(...newline)
                var line = String(decoding: lineData, as: UTF8.self).trimmingCharacters(in: .newlines)
                if line.last == "\r" { line.removeLast() }
                if line.isEmpty { continue }
                let values = Self.csvFields(line)
                if header == nil {
                    let cleanValues = values.enumerated().map { index, value in
                        index == 0 ? value.replacingOccurrences(of: "\u{feff}", with: "") : value
                    }
                    header = Dictionary(uniqueKeysWithValues: cleanValues.enumerated().map { ($0.element, $0.offset) })
                } else if let header { try rowHandler(header, values) }
            }
        }
        if !buffer.isEmpty {
            let values = Self.csvFields(String(decoding: buffer, as: UTF8.self).trimmingCharacters(in: .newlines))
            if header == nil { header = Dictionary(uniqueKeysWithValues: values.enumerated().map { ($0.element, $0.offset) }) }
            else if let header { try rowHandler(header, values) }
        }
    }

    private func directJourneys(_ db: OpaquePointer, originID: String, destinationID: String,
                                earliest: Int, latestArrival: Int) throws -> [RawJourney] {
        let sql = """
            SELECT t.route_id, r.route_short_name, t.headsign, a.stop_id, b.stop_id,
                   a.departure_time, b.arrival_time, a.stop_sequence, b.stop_sequence, t.trip_id
            FROM stop_times a
            JOIN stop_times b ON b.trip_id=a.trip_id AND b.stop_sequence>a.stop_sequence
            JOIN trips t ON t.trip_id=a.trip_id
            JOIN routes r ON r.route_id=t.route_id
            JOIN active_services act ON act.service_id=t.service_id
            WHERE a.stop_id=? AND b.stop_id=? AND a.departure_time>=? AND b.arrival_time<=?
            ORDER BY b.arrival_time DESC, a.departure_time DESC LIMIT 5
            """
        let statement = try prepare(db, sql)
        defer { sqlite3_finalize(statement) }
        bind(originID, at: 1, to: statement); bind(destinationID, at: 2, to: statement)
        bindInt(earliest, at: 3, to: statement); bindInt(latestArrival, at: 4, to: statement)
        var result: [RawJourney] = []
        while sqlite3_step(statement) == SQLITE_ROW {
            result.append(rawJourney(statement))
        }
        return result
    }

    private func transferJourneys(_ db: OpaquePointer, originID: String, destinationID: String,
                                  earliest: Int, latestArrival: Int) throws -> [RawTransferJourney] {
        let sql = """
            SELECT r1.route_id, r1.route_short_name, t1.headsign, a.stop_id, x.stop_id,
                   a.departure_time, x.arrival_time, a.stop_sequence, x.stop_sequence, t1.trip_id,
                   r2.route_id, r2.route_short_name, t2.headsign, y.stop_id, b.stop_id,
                   y.departure_time, b.arrival_time, y.stop_sequence, b.stop_sequence, t2.trip_id,
                   COALESCE(NULLIF(parent.stop_name,''), sx.stop_name)
            FROM stop_times a
            JOIN stop_times x ON x.trip_id=a.trip_id AND x.stop_sequence>a.stop_sequence
            JOIN stops sx ON sx.stop_id=x.stop_id
            JOIN stop_times y ON (y.stop_id=x.stop_id OR (sx.parent_station<>'' AND y.stop_id IN
                (SELECT stop_id FROM stops WHERE parent_station=sx.parent_station))) AND y.trip_id<>x.trip_id
            JOIN stop_times b ON b.trip_id=y.trip_id AND b.stop_sequence>y.stop_sequence
            JOIN trips t1 ON t1.trip_id=a.trip_id
            JOIN trips t2 ON t2.trip_id=y.trip_id
            JOIN routes r1 ON r1.route_id=t1.route_id
            JOIN routes r2 ON r2.route_id=t2.route_id
            JOIN active_services a1 ON a1.service_id=t1.service_id
            JOIN active_services a2 ON a2.service_id=t2.service_id
            JOIN stops sy ON sy.stop_id=y.stop_id
            LEFT JOIN stops parent ON parent.stop_id=sx.parent_station
            WHERE a.stop_id=? AND b.stop_id=? AND a.departure_time>=?
              AND y.departure_time>=x.arrival_time+CASE WHEN y.stop_id=x.stop_id THEN 180 ELSE 300 END
              AND b.arrival_time<=?
            ORDER BY b.arrival_time DESC, a.departure_time DESC LIMIT 8
            """
        let statement = try prepare(db, sql)
        defer { sqlite3_finalize(statement) }
        bind(originID, at: 1, to: statement); bind(destinationID, at: 2, to: statement)
        bindInt(earliest, at: 3, to: statement); bindInt(latestArrival, at: 4, to: statement)
        var result: [RawTransferJourney] = []
        while sqlite3_step(statement) == SQLITE_ROW {
            var first = rawJourney(statement, offset: 0)
            let second = rawJourney(statement, offset: 10)
            let transferName = columnText(statement, 20)
            first.transferName = transferName
            result.append(RawTransferJourney(first: first, second: second,
                transferStopID: first.destinationStopID, transferName: transferName))
        }
        return result
    }

    private func makeCandidate(_ db: OpaquePointer, raw: RawJourney, origin: StibStopChoice,
                               destination: StibStopChoice, serviceDay: Date,
                               transfer: RawTransferJourney?) -> StibJourneyCandidate {
        let firstIDs = tripStops(db, tripID: raw.tripID, from: raw.startSequence, through: raw.endSequence)
        let secondIDs = transfer.map { tripStops(db, tripID: $0.second.tripID,
            from: $0.second.startSequence, through: $0.second.endSequence) } ?? []
        let departure = serviceDay.addingTimeInterval(TimeInterval(raw.departureSeconds))
        let arrival = serviceDay.addingTimeInterval(TimeInterval(transfer?.second.arrivalSeconds ?? raw.arrivalSeconds))
        let serviceDayID = Int(serviceDay.timeIntervalSince1970)
        let legIdentity: String
        if let transfer {
            legIdentity = "x-\(raw.tripID)-\(raw.startSequence)-\(raw.endSequence)-\(transfer.second.tripID)-\(transfer.second.startSequence)-\(transfer.second.endSequence)-\(transfer.transferStopID)"
        } else {
            legIdentity = "d-\(raw.tripID)-\(raw.startSequence)-\(raw.endSequence)"
        }
        let id = "stib-\(serviceDayID)-\(origin.stop.id)-\(legIdentity)-\(destination.stop.id)"
        var journey = DeLijnJourney(id: id,
            line: raw.line, destination: transfer?.second.headsign ?? raw.headsign,
            lineDirection: raw.headsign.isEmpty ? raw.destinationName : raw.headsign,
            departure: departure, arrival: arrival, delayMinutes: 0, hasRealtimePrediction: false,
            transferStop: transfer?.transferName, transferStopID: transfer?.transferStopID,
            transferArrival: transfer.map { _ in serviceDay.addingTimeInterval(TimeInterval(raw.arrivalSeconds)) },
            secondLine: transfer?.second.line, secondLineDirection: transfer?.second.headsign,
            secondDeparture: transfer.map { serviceDay.addingTimeInterval(TimeInterval($0.second.departureSeconds)) },
            secondTransferStop: nil, secondTransferStopID: nil, secondTransferArrival: nil,
            thirdLine: nil, thirdLineDirection: nil, thirdDeparture: nil,
            firstLegStopIDs: firstIDs, secondLegStopIDs: secondIDs, thirdLegStopIDs: [],
            firstLegEntityID: "stib", secondLegEntityID: transfer == nil ? nil : "stib")
        journey.firstLegMode = modeName(routeType(db, routeID: raw.routeID))
        journey.secondLegMode = transfer.map { modeName(routeType(db, routeID: $0.second.routeID)) }
        journey.firstBoardStopID = raw.originStopID
        journey.firstBoardStopName = stopName(db, stopID: raw.originStopID)
        journey.secondBoardStopID = transfer?.second.originStopID
        journey.secondBoardStopName = transfer.flatMap { stopName(db, stopID: $0.second.originStopID) }
        return StibJourneyCandidate(id: id, journey: journey, origin: origin.stop,
            destination: destination.stop, originWalkMinutes: origin.walkMinutes,
            destinationWalkMinutes: destination.walkMinutes)
    }

    private func tripStops(_ db: OpaquePointer, tripID: String, from start: Int, through end: Int) -> [String] {
        guard let statement = try? prepare(db, "SELECT stop_id FROM stop_times WHERE trip_id=? AND stop_sequence>=? AND stop_sequence<=? ORDER BY stop_sequence") else { return [] }
        defer { sqlite3_finalize(statement) }
        bind(tripID, at: 1, to: statement); bindInt(start, at: 2, to: statement); bindInt(end, at: 3, to: statement)
        var result: [String] = []
        while sqlite3_step(statement) == SQLITE_ROW { result.append(columnText(statement, 0)) }
        return result
    }

    private func routeType(_ db: OpaquePointer, routeID: String) -> Int {
        guard let statement = try? prepare(db, "SELECT route_type FROM routes WHERE route_id=?") else { return 3 }
        defer { sqlite3_finalize(statement) }
        bind(routeID, at: 1, to: statement)
        return sqlite3_step(statement) == SQLITE_ROW ? Int(sqlite3_column_int(statement, 0)) : 3
    }

    private func modeName(_ type: Int) -> String {
        switch type {
        case 0, 900: return "TRAM"
        case 1, 400: return "SUBWAY"
        case 2, 100: return "RAIL"
        default: return "BUS"
        }
    }

    private func stopName(_ db: OpaquePointer, stopID: String) -> String? {
        guard let statement = try? prepare(db, "SELECT stop_name FROM stops WHERE stop_id=?") else { return nil }
        defer { sqlite3_finalize(statement) }
        bind(stopID, at: 1, to: statement)
        guard sqlite3_step(statement) == SQLITE_ROW else { return nil }
        return columnText(statement, 0)
    }

    private func activeServices(_ db: OpaquePointer, on date: Date) throws -> [String] {
        let formatted = Self.dateFormatter.string(from: date)
        let weekday = Self.brusselsCalendar.component(.weekday, from: date)
        let columns = ["", "sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]
        let weekdayColumn = columns[weekday]
        let statement = try prepare(db, "SELECT service_id FROM calendar WHERE start_date<=? AND end_date>=? AND \(weekdayColumn)=1")
        defer { sqlite3_finalize(statement) }
        bind(formatted, at: 1, to: statement); bind(formatted, at: 2, to: statement)
        var services = Set<String>()
        while sqlite3_step(statement) == SQLITE_ROW { services.insert(columnText(statement, 0)) }

        let exceptions = try prepare(db, "SELECT service_id, exception_type FROM calendar_dates WHERE date=?")
        defer { sqlite3_finalize(exceptions) }
        bind(formatted, at: 1, to: exceptions)
        while sqlite3_step(exceptions) == SQLITE_ROW {
            let service = columnText(exceptions, 0)
            if sqlite3_column_int(exceptions, 1) == 1 { services.insert(service) }
            else { services.remove(service) }
        }
        return Array(services)
    }

    private func setActiveServices(_ db: OpaquePointer, _ services: [String]) throws {
        try execute(db, "CREATE TEMP TABLE IF NOT EXISTS active_services(service_id TEXT PRIMARY KEY); DELETE FROM active_services;")
        let statement = try prepare(db, "INSERT OR IGNORE INTO active_services VALUES(?)")
        defer { sqlite3_finalize(statement) }
        for service in services { bind(service, at: 1, to: statement); try stepAndReset(statement) }
    }

    private func rawJourney(_ statement: OpaquePointer, offset: Int32 = 0) -> RawJourney {
        RawJourney(routeID: columnText(statement, offset), line: columnText(statement, offset + 1),
            headsign: columnText(statement, offset + 2), originStopID: columnText(statement, offset + 3),
            destinationStopID: columnText(statement, offset + 4), departureSeconds: Int(sqlite3_column_int(statement, offset + 5)),
            arrivalSeconds: Int(sqlite3_column_int(statement, offset + 6)), startSequence: Int(sqlite3_column_int(statement, offset + 7)),
            endSequence: Int(sqlite3_column_int(statement, offset + 8)), tripID: columnText(statement, offset + 9), destinationName: "")
    }

    private func openDatabase(_ url: URL, create: Bool) throws -> OpaquePointer {
        var database: OpaquePointer?
        let flags = SQLITE_OPEN_FULLMUTEX | (create ? SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE : SQLITE_OPEN_READONLY)
        guard sqlite3_open_v2(url.path, &database, flags, nil) == SQLITE_OK, let database else {
            let message = database.map { String(cString: sqlite3_errmsg($0)) } ?? "SQLite indisponible"
            if let database { sqlite3_close(database) }
            throw StibScheduleError.database(message)
        }
        return database
    }

    private func prepare(_ db: OpaquePointer, _ sql: String) throws -> OpaquePointer {
        var statement: OpaquePointer?
        guard sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK, let statement else {
            throw StibScheduleError.database(String(cString: sqlite3_errmsg(db)))
        }
        return statement
    }

    private func execute(_ db: OpaquePointer, _ sql: String) throws {
        var errorMessage: UnsafeMutablePointer<Int8>?
        guard sqlite3_exec(db, sql, nil, nil, &errorMessage) == SQLITE_OK else {
            let message = errorMessage.map { String(cString: $0) } ?? String(cString: sqlite3_errmsg(db))
            sqlite3_free(errorMessage)
            throw StibScheduleError.database(message)
        }
    }

    private func bind(_ value: String, at index: Int32, to statement: OpaquePointer) {
        sqlite3_bind_text(statement, index, value, -1, sqliteTransient)
    }
    private func bindInt(_ value: Int, at index: Int32, to statement: OpaquePointer) {
        sqlite3_bind_int(statement, index, Int32(clamping: value))
    }
    private func bindDouble(_ value: Double, at index: Int32, to statement: OpaquePointer) {
        sqlite3_bind_double(statement, index, value)
    }
    private func stepAndReset(_ statement: OpaquePointer) throws {
        guard sqlite3_step(statement) == SQLITE_DONE else {
            throw StibScheduleError.database("Écriture d’un horaire impossible")
        }
        sqlite3_reset(statement); sqlite3_clear_bindings(statement)
    }
    private func columnText(_ statement: OpaquePointer, _ index: Int32) -> String {
        guard let value = sqlite3_column_text(statement, index) else { return "" }
        return String(cString: value)
    }

    private static func csvFields(_ line: String) -> [String] {
        var fields: [String] = [], field = "", quoted = false
        var iterator = line.makeIterator()
        while let character = iterator.next() {
            if character == "\"" {
                if quoted, let next = iterator.next() {
                    if next == "\"" { field.append("\"") }
                    else { quoted = false; if next == "," { fields.append(field); field = "" } else { field.append(next) } }
                } else { quoted.toggle() }
            } else if character == ",", !quoted {
                fields.append(field); field = ""
            } else { field.append(character) }
        }
        fields.append(field)
        return fields
    }

    private static func seconds(_ value: String) -> Int {
        let pieces = value.split(separator: ":").compactMap { Int($0) }
        guard pieces.count == 3 else { return 0 }
        return pieces[0] * 3600 + pieces[1] * 60 + pieces[2]
    }
    private static var brusselsCalendar: Calendar = {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "Europe/Brussels")!
        return calendar
    }()
    private static var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "Europe/Brussels")
        formatter.dateFormat = "yyyyMMdd"
        return formatter
    }()
}

private struct RawJourney {
    let routeID: String
    let line: String
    let headsign: String
    let originStopID: String
    let destinationStopID: String
    let departureSeconds: Int
    let arrivalSeconds: Int
    let startSequence: Int
    let endSequence: Int
    let tripID: String
    let destinationName: String
    var transferName: String?
}

private struct RawTransferJourney {
    let first: RawJourney
    let second: RawJourney
    let transferStopID: String
    let transferName: String
}

private let sqliteTransient = unsafeBitCast(-1, to: sqlite3_destructor_type.self)

private extension Array {
    subscript(safe index: Index) -> Element? { indices.contains(index) ? self[index] : nil }
}
